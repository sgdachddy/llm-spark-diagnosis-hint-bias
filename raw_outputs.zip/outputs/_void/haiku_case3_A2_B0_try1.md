## 一、现象复述

- 作业 ais_port_events 昨天约 12 分钟跑完，今天在 join 阶段失败：多个 executor 先后退出，重试 4 次后终止。
- 报错是 `java.lang.OutOfMemoryError: Java heap space`，调用栈落在 `BroadcastExchange` 和 `HashedRelation` 构建上，也就是说广播表在构建哈希表时内存不够。同时还出现了 heartbeat timeout。
- 代码没有改，唯一的变化是上游把 `zone_attr` 替换成了昨天新生成的 `zone_attr_v2`。

几个关键读数彼此矛盾：

- 执行计划里，`zone_attr_v2` 被选为广播侧（BuildRight），EXPLAIN COST 给它的估算大小只有 8.2 MiB。这个数字低于 `autoBroadcastJoinThreshold=10MB`，所以优化器选择了 BroadcastHashJoin。
- 但 S3 上该表的实际存储是 6 个对象共 1.8 GiB，比估算值大两百多倍。DESCRIBE 输出里没有 Statistics 行，说明 8.2 MiB 很可能不是这张新表的当前统计，而是旧表或其他来源的残留。
- 失败前已完成的 61 个 task 负载很均匀：Input Size 约 118 到 131 MB，Spill 为 0，Duration 中位数 52 s。这里看到的是探测侧的数据，无法反映广播表本身的大小。
- Stage 4 的 GC Time 中位数为 14 s，约占 Duration 的 27%，最大值 22 s。失败前 executor 的 GC 压力已经偏高。

## 二、可能原因（按可能性从高到低）

**1. 广播表的实际体积远大于优化器估算，构建哈希表时 OOM。（可能性最高）**

依据：估算 8.2 MiB 与实际 1.8 GiB 相差约两个数量级，而广播与否的判断完全依赖这个估算值。旧表较小，所以昨天能正常运行。

验证（只读）：在 Spark UI 的 SQL 页面打开这次失败的查询，查看 BroadcastExchange 节点的 data size 指标，即实际广播出去的字节数。再用 `aws s3 ls --summarize --recursive` 统计旧表 `zone_attr` 的总大小做对比。如果 data size 远超 10 MB，而旧表明显更小，这个假设就成立。

**2. executor 内存余量不足以同时容纳广播哈希表和 8 个并发 task，GC 压力叠加心跳超时。**

依据：16 GB 堆在 `spark.memory.fraction=0.6` 下，统一内存约 9.4 GB。每个 executor 跑 8 个并发 task，还要在本地放一份广播数据。前面看到的 GC 占比已经约 27%，心跳超时和 OOM 两种报错都可能由长时间 GC 停顿引起。

验证（只读）：在 Spark UI 的 Executors 页查看失败前各 executor 的 Peak JVM Memory 和 GC Time 变化趋势，并检查 executor 的 stderr 日志中是否有长时间 GC 停顿的记录。同时确认 driver 日志里是否也有 OOM。附件 7 没有列出 `spark.driver.memory`，而广播表是先在 driver 上收集的，所以这一点需要单独核对。

**3. zone_attr_v2 的 zone_id 存在大量重复键，放大了广播哈希表的行数和体积。**

依据：新表替换了旧表。如果上游脚本没有对 zone_id 去重，同一个键的多行都会保存在哈希表中，既增大体积，也会放大 join 之后的行数。阶段 4 的汇总数据看不出这一点，所以排在第三位。

验证（只读）：分别对新旧两张表执行以下查询，比较总行数与去重键数：
`SELECT count(*), count(DISTINCT zone_id) FROM ocean.zone_attr_v2`
再查看重复键的分布：
`SELECT zone_id, count(*) AS c FROM ocean.zone_attr_v2 GROUP BY zone_id HAVING count(*) > 1 ORDER BY c DESC LIMIT 20`

## 三、补充说明

- 以上都是假设，目前证据还不足以定论。附件 1 的调用栈省略了约 280 行，无法确认最底层的触发点。
- 文档中 AQE 的 skewJoin 只针对 sort-merge 和 shuffled hash join，对广播 join 不生效。所以即使 AQE 已开启，它也不会拆分这里的广播表。
- 在验证结论出来之前，不建议先调大 executor 内存或修改 `autoBroadcastJoinThreshold`。这些改动可能掩盖真实原因。等确认了广播表的真实大小之后，再决定是更新表的统计信息，还是为这个 join 关闭广播，会更稳妥。
