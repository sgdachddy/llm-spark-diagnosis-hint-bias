## 结论先说

最可能的原因：**优化器认为 zone_attr_v2 只有约 8.2 MiB，于是选了广播 join；但这张表在 S3 上实际有 1.8 GiB（parquet 压缩后），广播构建哈希表时把内存撑爆了。** 作业代码没变，变的是表，所以是"表的体量变了 + 优化器的估算没跟上"，不是数据倾斜，也不是 executor 配置突然不够。

下面分开写：哪些是材料直接支持的，哪些是推断，哪些我现在还不能确定。

## 材料直接支持的部分

1. **plan 里走的是广播 join。** 附 3 显示 `BroadcastHashJoin Inner BuildRight`，右侧是 `BroadcastExchange` 加 `Scan parquet zone_attr_v2`。报错栈里 `HashedRelationBroadcastMode.transform`、`UnsafeHashedRelation.apply`、`BroadcastExchangeExec` 也在同一条路径上，说明 OOM 发生在构建广播哈希表的过程中。
2. **估算与实际严重不符。** 附 4 里优化器给出 `sizeInBytes=8.2 MiB`，低于 10MB 的 `autoBroadcastJoinThreshold`（附 7），所以被选为广播侧。而附 6 显示目录实际是 6 个对象、共 1.8 GiB，两者差了两个数量级以上。
3. **元数据里没有统计信息。** 附 5 的 DESCRIBE 输出没有 Statistics 行，是昨天 23:41 新建的 MANAGED 表，没有做过 `ANALYZE TABLE`。所以 8.2 MiB 不是来自登记过的真实统计，而是别的途径估出来的。
4. **不是倾斜，也不是普通 task 内存压力。** 附 2 里 61 个已完成 task 的输入大小是 118 到 131 MB，耗时 41 s 到 1.2 min，分布很均匀，spill 为 0。AQE 的 skewJoin 只处理 sort-merge / shuffled hash join，对广播 join 本来就不起作用，调它没有意义。

## 我的推断（未被材料证实）

- 1.8 GiB 是 parquet 压缩后的大小。表里有 `geom_wkt` 这种文本几何列，解压成 UnsafeRow 再放进哈希表，内存占用通常是磁盘大小的数倍，可能达到几个 GB 以上。广播表要在 driver 收集，再分发到每个 executor 各放一份，driver 或 executor 都有可能先撑爆。报错里同时出现 "heartbeat timed out" 和 "Java heap space"，符合 GC 长时间停顿后 executor 失联这个模式。
- 8.2 MiB 为什么会这么小，我不能确定。可能的方向有：估算时按被裁剪后的列比例折算，或者按行数和类型的默认宽度估算（对 WKT 这种变长字符串会严重偏小）。这需要你对照实际查询和 plan 才能定下来，我没有足够信息下结论。

## 我目前不知道、需要你补充的

- 旧表 zone_attr 的大小。如果它本来就是几 MB，说明上游脚本改变了内容（比如新加了几何列或明细），这是需要跟上游确认的根因。
- driver 的内存配置（附 7 里没有 `spark.driver.memory`）。
- 查询里是否显式写了 `broadcast()` 或 `/*+ BROADCAST */` 提示。如果有，下面第 1 步里改阈值是不起作用的。
- executor 9 自己的 stderr / GC 日志。driver 栈只能告诉我们在哪个阶段挂，看不出到底是 driver 还是 executor 的堆先满。

## 建议的处理步骤

**先确认（几分钟）**
1. 执行 `ANALYZE TABLE ocean.zone_attr_v2 COMPUTE STATISTICS;`，再跑一次 `EXPLAIN COST`。统计登记后，如果 sizeInBytes 变成接近 1.8 GiB，就验证了"估算失真"这个判断，并且优化器此后不会再选广播。
2. 对比 `aws s3 ls --summarize` 看旧 zone_attr 的大小，并问上游这次新表改了什么。

**让今天的作业先跑通**
3. 在查询里给 zone_attr_v2 一个 join 提示，如 `/*+ SHUFFLE_HASH(z) */` 或 `/*+ MERGE(z) */`，只影响这一个 join。临时调试也可以把 `spark.sql.autoBroadcastJoinThreshold` 设为 `-1`，但这会关掉整个作业里所有的广播，所以建议用提示。改成 shuffle 类 join 后，AQE 的 skewJoin 才会生效，同时要关注 shuffle 量变大带来的耗时增加，作业时间很可能比昨天的 12 分钟长。

**长期**
4. 如果下游事件统计用不到 `geom_wkt` 这类大列，在 join 之前先只选需要的列。这样表即使很大，实际广播的数据也会很小，可以继续用广播 join，是最省资源的做法。
5. 让上游脚本在生成表之后自动执行 `ANALYZE TABLE`，避免新表再次没有统计。

需要的话，你把 `explain` 全文、查询里读取 zone_attr_v2 的那一段，以及旧表大小发给我，我可以进一步确认 8.2 MiB 是怎么来的。
