# 结论

Stage 3 变慢的直接原因是 **join 键倾斜（数据倾斜）：400 个 task 里只有 1 个 task（task 287，落在 executor 7）拖了 45 分钟，其余 399 个都在 6~9 秒内完成**。这次变慢的触发条件很可能是新模板 `job_template_v3.conf` 里 **`spark.sql.adaptive.enabled=false`** 把 AQE 关掉了。Spark 4.0 默认是开启的，AQE 自带的倾斜 join 拆分（`spark.sql.adaptive.skewJoin.enabled`）因此没有生效。

## 证据链

1. **不是集群整体问题。** CPU 整体 12%、网络正常、GC 占 3%，说明大部分核都闲着，是在等一个 task。
2. **倾斜很明显。** 中位数 task 读 21 MB / 30 万条，最大的 task 读 8.4 GB / 1.2 亿条，约 400 倍。执行时间是 8 s 对 45 min。
3. **全部落在一个 task 上。** 附 3 中只有 executor 7 异常（9.2 GB shuffle read，96 GB 内存 spill，38 GB 磁盘 spill）。其余 9 个 executor 的数据量和耗时几乎一样，说明机器本身没问题。
4. **spill 是倾斜的后果，不是原因。** 日志里 task 287 一次次把约 4 GB 排序数据写盘（已 spill 12 次以上）。单个 task 要在 SortMergeJoin 前对 8.4 GB 数据排序，而 task 的 execution 内存只有一个 executor 内存的一小份。粗算：(64 GB − 300 MB) × 0.6 ≈ 38 GB，30 个并发 task 共享，每个 task 约 1.3 GB 上限，远小于 8.4 GB，所以必然 spill。
5. **执行计划确认了机制。** `hashpartitioning(h3_r7, 400)` 加 `SortMergeJoin`，同一个 `h3_r7` 值的所有行必然进同一个分区。有一个（或少数几个）热点格子，比如港口、锚地、航道口，或某个占位/默认值，就会把一个分区撑爆。
6. **配置对得上。** 附 5 里 AQE 被显式关闭。依据版本说明，AQE 开启时会自动拆分倾斜分区，现在这条保护没有了。

## 两点说明

- **推测执行没用，反而浪费资源。** 日志中 `287.1` 在 executor 3 上被启动，但它读的是同一份 8.4 GB 倾斜数据，不可能更快，最后因原 task 先完成被 kill。推测执行只能解决慢节点，解决不了数据倾斜。
- **"数据量 +4%"解释不了 9 倍的变慢。** 更合理的解释是热点格子一直存在，之前由 AQE（或旧模板）兜住了，换模板后失去保护。另一种可能是当天热点格子的数据恰好变多。这两种情况需要用下面的第 1、2 步区分。

## 建议操作（按优先级）

1. **先确认模板差异**：对比旧提交配置和 `job_template_v3.conf`，确认 AQE 是被模板显式关掉的，并问一下模板维护者为什么关（可能是为了别的作业）。
2. **恢复 AQE**：在本作业的提交参数里加 `--conf spark.sql.adaptive.enabled=true`（`skewJoin.enabled` 默认为 true，不必再设）。这是最小改动。同时 AQE 还会把 400 个只有约 20 MB 的小分区合并，有额外收益。不要共享模板整体改动，免得影响别的组员，建议作业级覆盖，并和模板维护者沟通。
3. **查热点键**，一条简单查询就够：
   `SELECT h3_r7, COUNT(*) c FROM ais_points GROUP BY h3_r7 ORDER BY c DESC LIMIT 20`
   如果头部是一个异常值（比如 0、-1 或无效编码），说明是脏数据或占位值，应在上游过滤或单独处理。如果是真实的港口格子，则属于正常的业务倾斜。
4. **看 `zone_attr` 的大小**。海区属性表通常不大。如果实际小于几百 MB，可以对它加 broadcast hint（`/*+ BROADCAST(zone_attr) */`），或调大 `spark.sql.autoBroadcastJoinThreshold`，直接改成广播 join，完全避开 shuffle 倾斜。现在计划里是 SortMergeJoin，说明优化器认为它大于 10 MB，或者缺统计信息，需要你确认。顺便检查 `zone_attr` 里同一个 `h3_r7` 有没有重复行，重复会让热点格子的 join 结果放大。
5. **AQE 不够用时的备选**：对热点键做加盐（salting），把热点格子的 AIS 一侧打散到多个分区，海区表对应复制多份。

## 不建议做的事

- **加内存或加 executor**：集群 CPU 只用了 12%，瓶颈是一个 task，加资源没有用。
- **增大 `shuffle.partitions`**：同一个键的数据仍然在同一个分区里，热点不会被拆开。
- **只调 `memory.fraction`**：只能略微减少 spill，8.4 GB 的单分区仍然很慢。

## 验证方法

修改后重跑，在 Spark UI 的 Stage 3 看：Max 和 Median 的 Duration、Shuffle Read 应基本接近（AQE 会把倾斜分区拆成多个子 task），Spill 应为 0 或很小，Stage 3 回到几分钟，整个作业回到约 15 分钟。SQL 页的计划里应出现 `AQEShuffleRead` 带 `skewed` 标记，或变成 BroadcastHashJoin。

## 我不确定的地方

- 热点键具体是什么，目前只能从分布推断，需要第 3 步的查询确认。
- 附 4 的执行计划没有出现 `AdaptiveSparkPlan` 节点，与 AQE 关闭一致，但这是节选，不能完全排除别的因素。
- 如果恢复 AQE 后仍然慢，把新的 Stage 3 指标和计划再发给我，我继续看。
