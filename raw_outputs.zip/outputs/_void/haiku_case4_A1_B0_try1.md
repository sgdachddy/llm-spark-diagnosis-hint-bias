## 结论

这次变慢的主因是 executor 内存从 16g 降到 4g。每个 task 可用的执行内存不够，排序阶段大量溢写（spill），GC 占比升高，最后 YARN 因物理内存超限杀掉 container 并触发重跑。输入数据只增加 2%，不足以解释耗时从约 1.1 min 涨到约 3.4 min（Stage 2 中位数）。数据倾斜也不是主因。

## 依据

1. **每个 task 的内存预算下降了约 4 倍。** 按 unified memory 的估算公式，每个 task 的执行内存约为 (堆内存 - 300MB) × spark.memory.fraction(0.6) ÷ 并发 task 数（4 核即 4 个）。
   - 16g：(16384 - 300) × 0.6 ÷ 4 ≈ 2.4 GB/task
   - 4g：(4096 - 300) × 0.6 ÷ 4 ≈ 0.57 GB/task

   上周 Spill 为 0，与 2.4 GB 的预算吻合。本周 Spill(Memory) 中位数为 1.4 GB，远超 0.57 GB，因此频繁溢写。这是量级估算，但方向很明确。

2. **不是数据倾斜。** Duration 从 2.6 min 到 4.5 min，Shuffle Read Size 从 168 MB 到 197 MB，分布都比较均匀，而且所有 executor 的 spill 量接近。如果是倾斜，应该只有少数 task 的数据量和耗时远高于中位数。

3. **GC 是内存紧张的症状。** GC 中位数 39 s 占 3.4 min 左右，与集群整体 GC 占比 19% 一致。堆内空间不足，对象频繁回收。

4. **YARN 杀容器是 overhead 不够。** 容器上限 = 4g + 800m ≈ 4.8 GB，日志显示实际用到 4.9 GB。堆外部分（排序缓冲、网络等）超出了 800m 的预留。

5. **AQE 与广播阈值不是问题来源。** 这个 Stage 的计划是 Sort → Window，没有 join，所以 skewJoin 不起作用。spark.sql.adaptive.enabled 本身就是默认 true。

6. **CPU 83% 需要单独看。** 这个数字说明集群比较忙。如果同一时段还有其他作业在跑，会进一步拖慢速度，但 Stage 级别的 spill 与 GC 数据指向的是内存配置。

## 建议（按优先级）

1. **恢复 executor 内存，或让每个 task 的内存翻倍。**
   - 最直接的做法是把 spark.executor.memory 调回 16g。如果成本压力大，可以折中到 8g，每个 task 约 1.2 GB。
   - 若想保持 4g，可以把 spark.executor.cores 从 4 改为 2，并把 instances 翻倍到 32，使并发数保持 64，每个 task 约 1.1 GB。注意这样总内存会翻倍。

2. **调大 memoryOverhead。** 把 spark.executor.memoryOverhead 从 800m 提高到至少 1g，给 4.9 GB 这类超限留出余量。

3. **增加 shuffle 分区数。** 把 spark.sql.shuffle.partitions 从 600 提高到 1200 左右。按现在的数据量估算，总 shuffle 约 600 × 181 MB ≈ 108 GB，分区翻倍后每个 task 数据量减半，spill 会明显减少。它不能完全替代内存，但能降低压力。

4. **核对成本口径。** 4g 配置下总 vcore 时间约为原来的 2.9 倍（58 min / 20 min），如果按 vCore-hours 计费，省下的钱可能被重跑和耗时抵消。如果按内存时间计费，4g 反而可能更省。建议先确认计费方式。

## 验证方法

用一次试跑对比，例如 spark.executor.memory=8g、memoryOverhead=1g、shuffle.partitions=1200。重点看 Stage 2 的 Spill (Memory) 是否接近 0，GC 占比是否回到 5% 以下，以及是否还有 executor 被 YARN 杀掉。

## 需要你确认的信息

- 集群计费是按 vCore 还是按内存计算？
- 同一时段是否还有其他作业在跑（CPU 83%）？
- 16g 是否是模板里为这个作业专门设定的，还是通用默认值？
