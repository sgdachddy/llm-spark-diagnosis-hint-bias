## ① 现象与关键读数（人话复述）

- 作业 ais_track_segments 从约 20 min 变成约 58 min，约 2.9 倍；偶尔有 executor 被 YARN 杀掉后重跑。
- 本周只有三项变化：executor 内存 16g 调到 4g；读新的按天分区目录；输入量 +2%。+2% 的数据量解释不了近 3 倍的耗时。
- 慢在 Stage 2（Exchange 后的 Sort + Window）：task 耗时中位数 1.1 min 变成 3.4 min，约 3.1 倍，与整体放慢倍数基本一致。
- 上周该 Stage 的 Spill 全为 0。本周每个 task 都在溢写，内存侧约 1.4 GB，磁盘侧约 0.55 GB。GC 占比从约 3% 升到 19%。
- 关键特征是均匀：Duration 为 2.6 到 4.5 min，Spill 为 1.1 到 1.7 GB，Shuffle Read 为 168 到 197 MB。最大值只比中位数高约 30% 到 40%，没有长尾，所以看起来不是数据倾斜，而是每个 task 都一样吃紧。13 个其余 executor 的读数与 1 到 3 号接近，也说明是整体现象。
- 83% 的 CPU 利用率不代表健康。其中一部分是 GC 和溢写的排序、序列化开销，是无效忙碌。
- 日志里有三处信号：sorter 反复溢写（7 次、9 次）；"Failed to allocate page"，说明申请执行内存页失败；容器因 4.9 GB 超过 4.8 GB 的物理内存上限被杀。
- 4.8 GB 与配置对得上：4g 堆加 800m overhead，约 4896 MB。
- 查询计划是 Scan、Filter、Exchange（按 mmsi 哈希分到 600 个分区）、Sort、Window，没有 join。因此版本说明里的 autoBroadcastJoinThreshold 和 AQE skewJoin 默认值与本作业基本无关。AQE 的倾斜处理也不覆盖 Window 的排序内存问题。

粗算一下内存预算（估算，不是实测）：
- 4g 堆下，execution + storage 可用约 (4096 - 300) × 0.6 ≈ 2.2 GB。
- 一个 executor 有 4 个核、4 个并发 task，每个 task 大致只能分到 0.3 到 0.55 GB。
- 而每个 task 要在内存里排序约 200 万条记录。Spill (Memory) 约 1.4 GB，说明它需要的内存远超这个份额。
- 换成 16g 时，每 task 份额约 2.4 GB，刚好够用。这与"上周 Spill 为 0"吻合。

## ② 原因假设（按可能性从高到低）

**假设 1：堆内存缩小到 4g，每个 task 的执行内存份额不足以容纳 Sort/Window 的数据量，导致全面溢写和 GC 飙升。**
这是最可能的主因。证据是指标均匀、时间点与改动吻合、数量级也对得上。
需要说明：上述份额是我按公式估算的，Window 的缓冲具体占多少内存没有实测。

**假设 2：容器被 YARN 杀掉是独立的内存问题，会叠加拖慢。**
容器上限是 4g + 800m。堆很紧时，堆外与直接内存（Parquet 读取缓冲、shuffle 的 Netty、排序页等）加上堆，可能越过 4.8 GB 上限。被杀后重跑的 task 或 stage 又增加了总耗时。
它与假设 1 同根，但失败机制不同。我不知道上周模板里 overhead 是多少，所以无法判断是 overhead 偏小，还是堆压力把堆外也挤高了。

**假设 3：新分区目录改变了读取侧，让每个 task 要处理的数据变胖。**
可能的情况包括：分区裁剪没生效、读入了更多列、小文件很多、或行更宽。
可能性较低，因为输入记录数只多 2%，各 task 的数据量又很均匀。但它是本周唯一的数据侧改动，且上周同 Stage 的读入指标我手上没有，所以不能排除。
我也没有看到 Scan 节点的详细信息，因为 EXPLAIN 只给了节选。

## ③ 每个假设对应的只读验证动作

**假设 1 的验证：用小样本做受控对照试跑。**
- 取一天数据的一小部分（比如约 1/10），在测试队列提交两次同样的作业。
- 两次都用 1 个 executor、4 核，并把 shuffle partitions 调到让每个 task 的记录数保持在约 200 万。
- 一次用 4g，一次用 16g。注意这是在提交参数里临时指定，不改集群或默认模板。
- 比较 Stage 2 的 Spill、GC Time、Duration。
- 如果 16g 下 Spill 归零、耗时回到约 1 min 量级，而 4g 下复现溢写，就基本坐实假设 1。
- 辅助检查：在 History Server 的 Stage 2 任务列表里看 Peak Execution Memory，并和上面估算的每 task 份额对照。

**假设 2 的验证：看 NodeManager 日志和 executor 内存指标。**
- 看被杀 executor 在 NodeManager 日志里被杀前的物理内存记录，以及 executor 的 Peak JVM Memory（包括 ProcessTreeJVMRSS、堆外相关项，在 Executors 页或事件日志里）。
- 如果被杀前 RSS 已经接近 4.8 GB，而堆本身只占约 4g，说明是堆外加堆叠加超限。
- 再去上周的事件日志或 History Server 的 Environment 页，确认上周 spark.executor.memoryOverhead 的取值。

**假设 3 的验证：对比读取侧指标，并看完整 Scan 节点。**
- 在 History Server 对比上周和本周 Stage 1（Scan 所在的 Stage）的 Input Size、Input Records、读取文件数、每个 task 的平均输入大小。
- 在 SQL 页签看 (1) Scan parquet 的 Details，确认 PartitionFilters 是否包含日期条件、ReadSchema 是否只读了需要的列、number of files read 与 size of files read 是否合理。
- 如果两周的文件数、读入量都接近，只多约 2%，且分区过滤已生效，就可以排除假设 3。

## ④ 说明

- 以上都是假设，不是结论。按要求没有改任何配置，所有验证动作都是只读，或是在提交参数里临时指定的小样本试跑。
- 现有证据最支持假设 1，但"4g 内存是否是唯一主因"要靠假设 1 的对照试跑来确认。
- 需要你补充的信息：上周模板的 overhead 取值，以及完整的 Scan 节点 Details。
