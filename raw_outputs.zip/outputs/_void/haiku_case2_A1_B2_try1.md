你的怀疑有道理：这次变慢的主要嫌疑对象是新加的 `feat.persist(MEMORY_AND_DISK)`。但从材料看，它不只是"用错了"，而是缓存本身在当前资源下没有收益，还额外吃掉了约 9.5 分钟。下面按证据逐条说明，并给出验证顺序。

**1. 时间账：变慢基本就是缓存造成的**

- 上周：Job 1 到 3 合计 6.2 + 5.8 + 5.9 ≈ 18 min，没有缓存，每个 Job 各自重新扫描 parquet。
- 本周：Job 0 物化缓存 9.5 min，加上 Job 1 到 3 合计 7.1 + 7.6 + 6.8 ≈ 21.5 min，总计约 31 min。
- 差额 31 - 18 ≈ 13 min，正好是 Job 0 的 9.5 min 加上 Job 1 到 3 多出的约 3.6 min。
- 也就是说，缓存让三个下游 Job 都变慢了，而不是变快。输入数据只增加了 3%，解释不了这 13 min 的增幅。

**2. 资源读数指向磁盘 IO，而不是计算**

- CPU 利用率只有 34%，磁盘 IO wait 从约 5% 升到 28%，GC 只占 6%。这是典型的 IO 瓶颈特征。
- Storage 页显示 feat 缓存 100% 命中，但 Size in Memory 为 10.2 GB，Size on Disk 为 29.8 GB。约四分之三的缓存块落在本地磁盘上，每次读缓存都要走磁盘。
- 这与 24 GB 内存、每个 executor 理论上约 14 GB 的统一内存（按 `memory.fraction=0.6` 估算）不太相符。需要在 Executors 页核实每个 executor 实际的 Storage Memory 上限和已用量，确认是否有其他占用（例如 Python worker 的堆外内存、其他作业）挤占了存储空间。

**3. Job 2 的新症状：Spill 从 0 变成约 1 GB/task**

- Job 2（停泊时长）的聚合 Stage 出现了每个 task 约 1.0 GB 的内存 spill 和约 0.35 GB 的磁盘 spill，而上周同一 Stage 的 spill 全为 0。
- Shuffle Read 每个 task 只有约 104 MB，内存 spill 却有约 1 GB，膨胀约 10 倍，说明聚合缓冲区很大，可能是高基数 key，或是 `collect_list`、窗口函数、排序类操作导致单个分组过大。
- Duration 的 max 为 1.9 min，median 为 1.2 min，存在一定倾斜，但不算极端。
- 这个 spill 是否由缓存挤压执行内存引起，材料里无法直接判断。需要看 Job 2 的 SQL 节点细节和 berth_time 的实现代码。

**4. 材料里几项与本作业无关**

- 执行计划里没有 Join，因此 AQE 的 skewJoin 和 autoBroadcastJoinThreshold 与这次变慢基本无关，不必花时间在它们上面。
- `spark.sql.adaptive.enabled=true` 是 Spark 4.0 默认值，不是这次的变更点。

**5. 建议的验证顺序**

1. 最小 A/B 测试：先去掉 `feat.persist(...)`，其他代码和数据保持不变，直接运行。如果耗时回到约 18 min，基本可以确认缓存是主因。这一步成本最低，也最有决定性。
2. 同时对比 h3 升级：在不带缓存的版本上，把 h3 固定回旧版本再跑一次。如果耗时和 spill 都正常，就说明 h3 升级改变了 berth_time 或 lane_density 的中间结果（例如产生更多 cell 或更大的分组），需要检查新版本的输出行数和 cell 数分布。
3. 如果确实需要复用 feat（三次复用本身是合理的），再考虑让缓存更划算：
   - 只缓存下游需要的列，减少缓存体积；
   - 在 Scala 或 Java 下可以尝试 `MEMORY_AND_DISK_SER`，PySpark 中可以结合列裁剪减少内存占用；
   - 调大每个 executor 的内存，或减少每个 executor 的核数（例如 8 核改为 4 核，保持总核数不变），让每个 task 能分到更多执行内存，从而降低 spill；
   - 先确认缓存能完整驻留内存（Size on Disk 应接近 0），否则缓存的收益不足以抵消 IO 开销。
4. 排查 Job 2 的 spill 来源：检查 berth_time 中是否有 `collect_list`、大分组或全局排序，以及 mmsi 等 key 的分布是否倾斜。这一步决定能否从根本上去掉 spill。

**结论**

- 最可能的原因：新加的 MEMORY_AND_DISK 缓存在当前内存条件下大部分落到磁盘，既增加了 9.5 min 的物化成本，又让三个下游 Job 的读取变慢，并带来明显的 IO 等待。
- 建议先去掉缓存做 A/B 测试确认。如果确认，可以先回退这一改动，恢复到约 18 min；之后再针对 Job 2 的 spill 和 h3 升级做进一步排查。
- 材料中还缺少：Executors 页的内存信息、Job 2 SQL 节点的详细指标、berth_time 和 lane_density 的代码，以及 h3 升级前后的输出对比。补充这些信息后可以进一步确认根因。
