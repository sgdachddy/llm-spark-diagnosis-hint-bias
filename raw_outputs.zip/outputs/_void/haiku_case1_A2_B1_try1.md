## 一、现象（人话复述）

Stage 3 共 400 个 task，绝大多数只跑 6 到 9 秒，但有 1 个 task 跑了 45 分钟，整个 stage 被它拖住。集群 CPU 整体只有 12%，说明大部分核在空等，问题不在算力总量。

关键读数：

- 中位数 task 的 shuffle 读取量是 21 MB，最大的那个是 8.4 GB，相差约 400 倍；记录数也差不多 400 倍（中位 30 万条，最大 1.2 亿条）。
- 溢写只集中在 executor 7 上：内存溢写 96 GB、磁盘溢写 38 GB；其余 9 个 executor 的溢写基本为 0。
- GC 只占 task 时间的 3%，中位 task 的溢写全部为 0。
- 模板里 `spark.sql.adaptive.enabled=false`，计划中的 Exchange 是静态的 400 个分区。
- 输入数据只增加了 4%，这不足以解释耗时从 5 分钟变成 45 分钟。

据此，现有读数不支持"全局内存不够"：总体内存和 GC 都正常。内存压力只集中在那一个超大分区上。

## 二、可能原因（按可能性从高到低，均为假设，尚未证实）

**假设 1：按 h3_r7 的热点键数据倾斜。** 某些格子的船位点特别密集（例如港口或繁忙航道），按 h3_r7 做 hash 分区后，这些键全部落进同一个分区，体量约 8.4 GB，由单个 task 处理；其余 399 个分区很小。"一个 task 极慢、其余全部秒级、CPU 利用率低"的形态与此吻合。也可能是昨天这些热点格子的数据量还没这么集中。

- 验证动作：在 Spark UI 的 Stage 3 中找到那个 45 分钟的 task，记下它的 shuffle 读取量和记录数。再对一天的分区做只读聚合，例如 `SELECT h3_r7, COUNT(*) FROM ais_points WHERE <同一过滤条件> GROUP BY h3_r7 ORDER BY 2 DESC LIMIT 20`，对比昨天与今天头部键占总行数的比例。如果少数几个键占去了绝大部分行数，即可支持该假设。

**假设 2：模板 v3 关闭了 AQE，倾斜没有被处理。** Spark 4.0 默认开启 AQE，其中的 `spark.sql.adaptive.skewJoin.enabled` 默认也为 true，开启时会把倾斜分区拆开再与另一侧配对。本次配置把 `spark.sql.adaptive.enabled` 显式设为 false，EXPLAIN 输出顶部也没有 AdaptiveSparkPlan 包装。这可能是"改用新模板"与"耗时突增"之间的关联：模板并没有直接造成内存不足，而是关掉了处理倾斜的机制。此外，`spark.speculation=true` 对这类大分区帮助有限，日志里的投机副本同样要处理整个大分区，最终也被 kill 了。

- 验证动作：用 `diff` 对比 job_template_v3.conf 与上一版模板，确认 adaptive 与 skewJoin 相关配置的前后取值。然后在单个 SQL 会话内临时执行 `SET spark.sql.adaptive.enabled=true`，只对一天的小样本做 EXPLAIN，观察计划顶部是否出现 AdaptiveSparkPlan 以及倾斜拆分节点。这一步只影响该会话，不修改集群或模板。

**假设 3：每个 executor 的并发过高，导致单个 task 可用内存过小。** 每个 executor 有 30 个核共享 64 GB 堆内存。按 (64 GB − 300 MB) × 0.6 估算，统一内存约 38 GB，30 个并发 task 平分后，每个 task 大约只有 1.3 GB 量级（Spark 对单个 task 的执行内存在 1/2N 到 1/N 之间浮动，实际可能更少）。对 8.4 GB 的分区做排序时，只能反复溢写，日志中同一线程已溢写 12 次、每次约 4 GB。若成立，"内存不够"指的是单 task 的内存份额太小，而不是总量不够。

- 验证动作：在 Spark UI 的 Executors 页面查看 executor 7 的执行内存使用峰值，并统计其日志中 "spilling" 的出现次数。然后在一天的小样本上做一次临时试跑，把 `spark.executor.cores` 降到 8 左右，观察同一分区的溢写是否明显减少。这只是试跑，不改正式作业的提交参数。

## 三、补充观察与注意事项

- 本次执行计划用的是 SortMergeJoin，而不是 BroadcastHashJoin。如果 zone_attr 的实际大小能放进内存，显式广播它可以直接绕开这次 shuffle 倾斜。需要先确认 zone_attr 的真实体积，再决定是否值得这样做。
- 日志节选中没有标明那个 45 分钟的 task 是否就是分区 287，需要在 Spark UI 中确认。
- 在完成上述验证之前，建议不要修改集群配置或模板。
