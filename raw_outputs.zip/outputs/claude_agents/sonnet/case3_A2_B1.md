## ① 现象和关键读数（人话版）

- 作业没改、数据量级没明显变，只有 `zone_attr` 换成了昨晚 23:41 新生成的 `zone_attr_v2`，今天就在 join 阶段连续 OOM，重试 4 次后终止。昨天约 12 分钟能跑完。
- 报错栈停在 `BroadcastExchangeExec -> HashedRelationBroadcastMode.transform -> UnsafeHashedRelation`，也就是在构建广播 join 的哈希表时堆内存溢出。所以出问题的是"广播这一步"，不是后面的聚合。
- 计划里 `BroadcastHashJoin BuildRight`，被广播的就是 `zone_attr_v2`。优化器认为它只有 8.2 MiB，低于 10MB 阈值，所以选了广播。
- 但存储目录里它实际是 6 个文件、1.8 GiB（Parquet 压缩后的大小，解压并建哈希表后在内存里通常更大）。估计值和实际值差了约 200 倍。
- 表元数据里没有 Statistics 行，说明这个 8.2 MiB 不是 `ANALYZE TABLE` 算出来的。它从哪来的，目前材料里看不出来。
- 已完成的 61 个 task 里，输入量很均匀（118-131 MB），没有 spill，耗时也集中（中位 52 s，最大 1.2 min）。这些数据看不出数据倾斜，也看不出普通 task 在大量落盘。
- 一个小观察：GC 中位数 14 s、占耗时约 27%，对健康作业来说偏高，说明堆本来就比较紧。
- 还有一个材料里没解决的矛盾：`BroadcastExchangeExec` 构建哈希表通常发生在 driver 端，而报错写的是 executor 9 丢失。到底是哪个 JVM 溢出，现在还不能确定。另外配置里没出现 `spark.driver.memory`，如果没单独设置，就是默认值（1g）。

所以"内存不够"在表面上是对的，但更像是结果。更值得先查的是：为什么今天一个实际 1.8 GiB 的表被当成 8.2 MiB 去广播。

## ② 原因假设（按可能性从高到低）

**假设 1：表大小估计错误，导致优化器把一个实际很大的表广播了。**
`zone_attr_v2` 没有可靠统计，8.2 MiB 的估计远小于实际。优化器据此选了广播，把 1.8 GiB（内存里可能更大，`geom_wkt` 这类长字符串列尤其占空间）的表塞进哈希表，堆被撑爆。这也能解释"昨天正常"：旧表 `zone_attr` 大概率有正确统计或本来就小，而 v2 是新生成的，把表体积改大了或把统计信息丢了。
这一条和所有现有证据最吻合，但还没有被直接证实。

**假设 2：OOM 实际发生在 driver 端（构建广播哈希表时），executor 丢失是连带结果。**
构建 `HashedRelation` 是在 driver 上做的，而配置里没看到 driver 内存设置（可能是默认 1g）。如果是这样，加大 executor 内存没有任何作用，该看的是 driver。它和假设 1 不冲突：假设 1 解释"为什么广播了大表"，假设 2 解释"哪台机器先扛不住"。

**假设 3：executor 堆本身压力过大（即你原来的判断）。**
8 个并发 task 共享 16 GB 堆，GC 占比已经约 27%，再叠加一份大的广播变量，可能把 executor 推到 OOM 或心跳超时。可能性排在最后，因为已完成的 task 没有 spill、输入均匀，而且 executor 配置和昨天一样，唯一变化是表。

## ③ 每个假设的验证动作（只读）

**验证假设 1：对比新旧表的真实规模，并看失败查询里广播节点的实际大小。**
- 在只读会话里对 `zone_attr_v2` 和 `zone_attr` 各跑一条：
  `SELECT count(*), count(DISTINCT zone_id), sum(length(geom_wkt)), avg(length(geom_wkt)) FROM ...`
  看行数、`zone_id` 是否重复、`geom_wkt` 总体积，据此估算内存中的大小，并和 8.2 MiB 对比。
- 同时在 Spark UI 的 SQL / DataFrame 页，找到失败的这次查询，看 `BroadcastExchange` 节点的 data size 和 time to build 指标（如果失败导致指标缺失，就看昨天成功那次）。
- 判断标准：如果真实规模远超 10MB，假设 1 成立。再顺带查 `zone_attr_v2` 的上游脚本是怎么生成它的（比如是否新加了列、是否写出方式变了）。

**验证假设 2：确认 OOM 到底发生在 driver 还是 executor。**
- 在 Spark UI 的 Environment 页查看实际生效的 `spark.driver.memory`。
- 在 driver 日志里搜 `OutOfMemoryError`，看出现的线程名和时间点；同时看 executor 9 的 stderr，确认它是自己 OOM，还是只是心跳超时。
- 判断标准：如果 driver 日志里有 OOM 且出现在广播构建阶段，假设 2 成立；如果只有 executor 端报错，则假设 2 不成立。

**验证假设 3：看 executor 层面的内存和 GC 情况。**
- 在 Spark UI 的 Executors 页，对比各 executor 的 GC time / task time 占比和峰值 JVM 内存（如果开启了相关指标），重点看 executor 9 和其他 executor 的差别。
- 再对比昨天成功那次作业的同一页面（如果还保留历史记录）。
- 判断标准：如果昨天 GC 占比也同样高、今天只有个别 executor 异常，假设 3 的分量就低；如果所有 executor 都比昨天明显更差，则说明整体堆压力在上升。

## ④ 说明

- 以上都只是假设，没有下结论。目前最该先做的是验证动作里的第一项，成本低，也最有可能一次排除或确认主因。
- 我没有建议任何配置或集群改动。等验证结果出来后，再根据哪个假设成立来讨论怎么处理。
- 还有一处需要你补充：8.2 MiB 这个数字的来源。如果你能提供 `zone_attr`（旧表）的 `EXPLAIN COST` 和 `DESCRIBE EXTENDED` 输出，对比起来会更容易判断统计信息是什么时候出问题的。
