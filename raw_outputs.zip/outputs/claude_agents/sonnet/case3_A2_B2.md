你的怀疑方向有依据：执行计划确认 zone_attr_v2 确实被广播了。但"被广播"和"广播导致失败"之间还差一步证据，下面按你的要求分步来。

## ① 现象和关键读数（人话版）

- **事实**：作业代码没变，昨天约 12 分钟跑完，今天在 join 阶段（Stage 4）失败。唯一已知的变化是上游昨晚（Nov 17 23:41 JST）生成了新表 zone_attr_v2，替换了 zone_attr。
- **失败方式**：多个 executor 先后退出，原因是心跳超时 / `Java heap space`。Task 37 重试 4 次后整个作业终止。栈里出现了 `HashedRelation` 和 `BroadcastExchangeExec`，也就是和广播哈希表构建相关的调用链。
- **计划确认**：`BroadcastHashJoin BuildRight`，右侧 `BroadcastExchange` 下面扫的就是 zone_attr_v2。所以"这张表被广播了"是已确认的，不是猜测。
- **最关键的矛盾**：
  - 优化器估算这张表只有 **8.2 MiB**，低于 10MB 的广播阈值，所以选了广播。
  - 但 S3 上实际有 **1.8 GiB**（6 个对象），大约是估算值的 220 倍。
  - `DESCRIBE EXTENDED` 里没有 Statistics 行，说明元数据里没有这张表的统计。所以 8.2 MiB 是从哪里来的，目前没有解释，我也不打算猜。
- **Stage 4 已完成的 61 个 task**：
  - 输入大小很均匀（118–131 MB），没有 spill。
  - GC 时间 9–22 秒，占 task 时长的两成到三成，说明即使成功的 task 堆内存压力也不小。
  - 这 61 个是"活下来的"。失败的 task 不在这份统计里，所以从中看不出失败 task 是否更大或更倾斜。

## ② 原因假设（按可能性从高到低）

**假设 1：表的真实大小远超 8.2 MiB，估算值有误，导致一张约 GB 级的表被广播，executor 堆内存被撑爆。**
这是最强的假设。现有证据都指向它：唯一的变化是新表；计划里广播了它；估算和实际差了两个数量级；栈是 OOM 加哈希表构建。另外要注意，parquet 压缩后的 1.8 GiB 在内存里展开成哈希表通常会更大。每个 executor 都要存一份，同时还有 8 个并发 task，堆就容易被挤爆，GC 拉长后表现为心跳超时。
待查：8.2 MiB 的来源。可能是表属性里残留的旧统计，也可能是文件列表缓存过期，两者我都只是列出可能，没有证据。

**假设 2：OOM 发生在 driver 端，即 driver 在构建广播哈希表时内存不足。**
排第二的理由有两点：
- 栈里的 `BroadcastExchangeExec` 和 `HashedRelationBroadcastMode.transform` 一般是 driver 构建广播哈希表时的调用链，与"executor 9 丢失"不完全对得上，需要确认 OOM 到底出在哪个 JVM。
- 你给的配置里没有 `spark.driver.memory`，不知道 driver 内存是多少。

不利的一点：Stage 4 已有 61 个 task 完成，说明广播至少在部分重试里是构建成功的。所以这条排在假设 1 之后，不能排除。

**假设 3：问题不在新表，而在 ais_points 一侧（今天的数据量或倾斜变了）。**
可能性最低，但它是一个有用的对照，用来避免我们都先入为主地认定是广播。已完成 task 的输入很均匀，不支持倾斜，但如前所述，失败的 task 不在统计里，所以不能完全排除。

## ③ 验证动作（全部只读）

| 假设 | 验证动作 | 怎么判断 |
|---|---|---|
| 1 | 在 Spark UI 的 SQL 页签里打开今天失败的那个查询，找到 `BroadcastExchange` 节点，看 "data size" 和 "number of output rows"。如果该节点因 OOM 没有生成指标，退一步用一条只读查询：`SELECT count(*), sum(length(geom_wkt)), sum(length(attrs)) FROM ocean.zone_attr_v2`。 | 实际 data size 达到数百 MB 到 GB 级，远超 10MB，假设 1 成立。如果实际只有约 8 MB，假设 1 被推翻，那 S3 上的 1.8 GiB 就需要另外解释（例如目录里混有旧文件）。 |
| 2 | 打开 driver 日志，查看完整 OOM 栈里的线程名和主机。再看 Executors 页签里 driver 一行的内存使用，并确认作业实际的 `spark.driver.memory`。 | 线程名是 `broadcast-exchange-*` 且主机是 driver，则假设 2 成立。主机是 executor 9，则不成立。 |
| 3 | 在 History Server 里对比昨天和今天作业的 ais_points 扫描量和输入分区数，再看今天失败 task 的 Input Size。 | 两天数据量接近、失败 task 的输入与成功的相近，假设 3 基本排除。如果今天数据量明显更大，则需要重新排序。 |

补充一个小检查：你贴的 `AdaptiveSparkPlan` 是不是最终计划（`isFinalPlan=true`）。我没有把握 AQE 是否会在运行时改变这个 join 的策略，这需要你确认。

## ④ 说明

- 我没有修改任何配置，也没有给出结论。上面三条都是待验证的假设，需要你按验证动作取回读数之后再判断。
- 如果你方便补充这几项，可以缩小范围：完整 OOM 栈的线程名和主机、`spark.driver.memory` 的实际值，以及 BroadcastExchange 节点的 data size。
