我先按你的要求来：复述现象，列出假设，每个假设配一个只读验证动作。我不修改任何配置，也不下最终结论。

## ① 现象与关键读数复述

- 作业 `ais_track_segments` 从约 20 min 变成约 58 min，偶尔有 executor 被 YARN 杀掉后重跑。
- 本周有三项改动：executor 内存 16g 调到 4g，读取新的按天分区目录，输入数据量 +2%。
- 变慢集中在 Stage 2（排序和切分）：
  - task 耗时中位数从 1.1 min 升到 3.4 min。
  - 上周 Spill 全为 0，本周每个 task 内存溢写约 1.4 GB、磁盘溢写约 0.55 GB。
  - GC 占 task 时间从约 3% 升到 19%，与 Stage 2 中位数吻合（39 s / 204 s ≈ 19%）。
- 数据不倾斜：
  - 600 个 task 的耗时是 2.6~4.5 min，Max 只有中位数的约 1.3 倍。
  - Shuffle Read 是 168~197 MB，记录数是 190~221 万，分布很均匀。
  - 各 executor 的 Spill 读数也几乎一致（约 51~54 GB 内存溢写），说明是"所有 task 一起变慢"，不是"少数 task 拖后腿"。
- 被杀的日志显示容器物理内存用到 4.9 GB，上限 4.8 GB。这个上限正好是 `executor.memory` 4g 加 `memoryOverhead` 800m。
- 网络正常，CPU 83% 偏忙，但很可能是花在 GC 和溢写的 I/O、序列化上，不是在做有效计算。

补充一个对不上的地方：Stage 2 有 600 个 task，并行槽位是 16×4=64 个，约 9.4 波。Stage 2 单项的增量大约是 9.4 × (3.4−1.1) ≈ 22 min，而总增量约 38 min。剩下约 16 min 目前没有证据解释，可能在 Stage 1 扫描、被杀 executor 的重跑，或者别的 Stage。下面的验证动作里我会把这部分一起查。

## ② 原因假设（按可能性从高到低）

### 假设 1（最可能）：executor 堆内存 16g 降到 4g，每个并发 task 能用的执行内存小于排序所需，引发大量溢写和 GC

粗算依据：

- 统一内存池约为 (4096 − 300) MB × 0.6 ≈ 2.28 GB，由 4 个并发 task 共享，每个 task 约 570 MB 上限（storage 基本不占用时 execution 可借用，但 4 核同时满载仍约此量级）。
- 上周 16g 时的对应值约为 (16384 − 300) × 0.6 / 4 ≈ 2.4 GB。
- 本周每个 task 要在内存里排 190~221 万条记录，Spill (Memory) 约 1.4 GB，超过 570 MB，必然溢写。上周 2.4 GB 装得下，所以溢写为 0。
- 日志里的 `spilling sort data ... (7 times so far)` 和 `Failed to allocate a page` 与此一致。
- Spill 和 GC 在所有 task、所有 executor 上均匀出现，与"全局内存配置缩水"的形态吻合。

**验证动作（只读）：**

1. 打开 History Server 上上周同一作业的应用，在 Environment 页确认 `spark.executor.memory` 是否确为 16g（这也是对"上周基线"的核实）。
2. 对比该应用 Stage 2 的 Spill、GC 和 Duration，确认上周的 Spill 为 0。
3. 在本周应用的 Executors 页看 Peak JVM Memory 里的 OnHeap Execution Memory 峰值，确认是否贴近约 2.2 GB 的池上限。
4. 若要更强的证据，可用同一份输入的一个小样本（例如 1 个分区目录）在**单独的测试应用**里分别以 16g 和 4g 试跑，只比较 Spill 和 GC。这是只读输入，不改集群、不改正式作业。

### 假设 2：新分区目录导致读入的行更宽、列更多或过滤没下推，使每条记录在内存中的体积变大

依据：

- 你说数据内容不变，但目录结构变了，Scan 的行为不一定不变，比如列裁剪、分区过滤或文件切分可能不同。
- 本周每个 task 的 Shuffle Read 约 181 MB，对应内存排序数据约 1.4 GB，膨胀约 7.7 倍，比我印象中的典型值略高。
- 这条假设只能解释"每条记录更重"，解释不了"上周 16g 时一点都不溢写"，所以单独成因的可能性低于假设 1。它更可能是与假设 1 叠加的放大因素。
- 另外，EXPLAIN 里 Filter 在 Scan 之上，需要确认分区过滤有没有生效。

**验证动作（只读）：**
对比上周和本周同一作业的 `EXPLAIN FORMATTED`，看 Scan 节点的 `ReadSchema`（读了哪些列）、`PartitionFilters` 和 `PushedFilters`、读入文件数。同时对比两周 Stage 1 的 Shuffle Write 总量和记录数，看每条记录的平均字节数有没有变。

### 假设 3：memoryOverhead 800m 对 4 核并发偏紧，是被 YARN 杀掉并重跑的原因，属于放大因素而不是慢的主因

依据：

- 被杀的日志是 4.9 GB 用到 4.8 GB 上限，只有 executor 3 出现过，其余 15 个 executor 没被杀。
- 堆被 GC 压在上限附近，堆外部分（线程栈、netty 缓冲、Parquet 读取等）超过 800m 时就会触发杀进程。
- 它能解释"偶尔重跑"，但解释不了全体 task 变慢，所以只排第三。
- 被杀重跑可能贡献了前面提到的那部分未解释的耗时。

**验证动作（只读）：**
统计本周 NodeManager 日志里 `Container killed by YARN for exceeding physical memory limits` 的次数和涉及的 executor；在 Spark UI 的 Stage 2 页面看失败 task 和重试数量，以及 Executors 页的 Peak OffHeap 和 ProcessTree 内存指标，估算重跑占用的时间。

## ③ 已基本排除的方向（依据读数）

- **数据倾斜或 AQE 倾斜处理：** task 之间非常均匀，且 `skewJoin` 只作用于 join，本作业是 Exchange + Window，不涉及。
- **数据量 +2%：** 量级上解释不了耗时增长到近 3 倍，也解释不了 Spill 从 0 变成每个 task 都有。
- **网络：** 读数正常，Shuffle Read 的大小分布也很均匀。
- **广播阈值 `autoBroadcastJoinThreshold`：** 本作业没有 join，无关。

## ④ 说明与限制

- 以上都是基于你贴的读数做的推断，"每 task 约 570 MB"这个粗算忽略了 execution 与 storage 的动态借用和任务间公平分配的细节，只用来判断量级。
- 目前证据最支持假设 1，但我不把它当作结论。按上面第 1 条先核实上周基线，再看小样本对比，才能确认。
- 我没有修改任何配置，也没有给出调参建议。等验证结果出来，再讨论要不要调整。
