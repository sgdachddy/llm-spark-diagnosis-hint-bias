## 结论

**这不是数据倾斜，是 executor 内存从 16g 降到 4g 导致的内存不足。** 每个 task 的可用执行内存装不下它要排序的那份数据，所以大量 spill、GC 升高，最后偶尔触发 YARN 杀进程。你提供的读数里没有一项支持倾斜。

## 为什么不是倾斜

倾斜的特征是少数 task 的数据量和耗时远大于其他 task。你的 Stage 2 摘要（600 个 task）显示：

- Shuffle Read Size：Min 168 MB、Median 181 MB、Max 197 MB，Max/Median 约 1.09。
- Shuffle Read Records：Min 190 万、Median 203 万、Max 221 万，同样很均匀。
- Duration：Min 2.6 min、Median 3.4 min、Max 4.5 min，Max/Median 约 1.3。
- Spill 和 GC Time 也是全体 task 一起偏高：Spill(Memory) 最小就有 1.1 GB。
- 按 executor 聚合（附 3）：每个 executor 的 Task Time、Spill 读数几乎相同。

这是所有 task 一起变慢。如果是倾斜，应该看到 Max 比 Median 大几倍到几十倍，并且少数 executor 拖在后面。

另外，你材料里提到的 AQE 倾斜处理（`spark.sql.adaptive.skewJoin.enabled`）只作用于 join，而这个作业的物理计划是 Exchange → Sort → Window，没有 join，所以它与本问题无关。`autoBroadcastJoinThreshold` 同理无关。

## 证据链

1. **Spill 从 0 变成 1.4 GB（Median）**。上周同一 Stage 的 Spill 全部为 0，说明上周数据装得下，本周装不下。
2. **GC 占比从约 3% 升到 19%**。堆太小，对象频繁回收，典型的内存压力表现。
3. **日志（附 5）**：`UnsafeExternalSorter` 反复 spill（已 7 次、9 次），`TaskMemoryManager` 报 "Failed to allocate a page"，这是 task 拿不到执行内存的直接信号。
4. **被 YARN 杀掉（附 5）**："4.9 GB of 4.8 GB physical memory used"。容器上限是 4g 堆加 800m overhead，约 4.8 GB，刚好超出。
5. **CPU 83% 不代表高效**。这部分 CPU 大量花在 GC 和 spill 的序列化、读写磁盘上，不是有效计算。

## 内存估算（按配置推算，属于估算）

- `spark.executor.memory=4g`，`spark.memory.fraction=0.6`：统一内存约 (4096 − 300) × 0.6 ≈ 2.2 GB。
- 每个 executor 4 核，4 个 task 同时跑，每个 task 的执行内存约 0.55 GB 量级。
- 每个 task 要对约 200 万条记录（shuffle 压缩后 181 MB，反序列化后体积会大得多）做排序和窗口计算。Spill(Memory) 达到 1.4 GB，说明它实际需要的内存远超 0.55 GB。

16g 时同样的 4 核，每个 task 可用约 4 倍以上的执行内存，所以上周不 spill。

## 为什么"本周才出现"

三项改动里，真正相关的只有第一项：

- **executor 内存 16g → 4g**：主因，时间点和症状完全吻合。
- **输入 +2%**：量级太小，不可能让 Spill 从 0 变成 1.4 GB、耗时变成近 3 倍。
- **分区目录变化（数据内容不变）**：不影响 Stage 2 的数据分布。不过我没有看到 Stage 1 的指标，如果想排除，可以顺手看一下 Stage 1 的 task 数和输入大小有没有异常（比如小文件变多）。

## 建议（按推荐顺序）

1. **最直接：把 executor 内存恢复到 16g**（至少 8–12g），overhead 按比例保留。先恢复，确认耗时回到约 20 min、Spill 回到 0，就能验证上述判断。
2. **如果必须保持 4g 以控制成本**：
   - 增大 `spark.sql.shuffle.partitions`，例如 600 → 2400（约 4 倍），让每个 task 的数据降到约 45 MB 压缩量，使其落在 0.55 GB 的执行内存之内。AQE 默认会合并过小分区，可能把它再合并回去，需要确认 `spark.sql.adaptive.coalescePartitions` 的行为，必要时调整目标分区大小。
   - 或者把 `spark.executor.cores` 降到 2，让每个 task 的内存翻倍，代价是并行槽位减半。
   - 把 `spark.executor.memoryOverhead` 适当调高（例如 1g 以上），降低被 YARN 杀的概率。
3. **算一下成本账**：作业从 20 min 变成 58 min，还有重跑，executor 占用资源的总时长大约是原来的 3 倍，很可能比原来更贵，省下的内存成本未必能抵消。

## 需要说明的限制

- 内存的 per-task 数字是我按默认的统一内存公式推算的，不是实测值，具体数字以 Spark UI 为准。
- 我只看到了 Stage 2 的指标；如果你想彻底排除倾斜，也可以按 mmsi 统计一下记录数的分布，但从 Stage 2 这组读数看，各分区已经很均衡了。
