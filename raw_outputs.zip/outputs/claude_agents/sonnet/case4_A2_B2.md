## ① 现象和关键读数（人话版）

- 作业 `ais_track_segments` 从约 20 min 变成约 58 min，偶尔有 executor 被 YARN 杀掉后重跑。
- 本周最明确的改动是 executor 内存从 16g 降到 4g。每个 executor 有 4 核，4 个 task 共用这 4g。
- Stage 2（排序+切分航段）是最突出的变化：
  - 上周没有任何 spill，Duration 中位数 1.1 min。本周每个 task 都有 spill，内存侧约 1.4 GB、落盘约 0.55 GB，Duration 中位数 3.4 min。
  - GC 占 task 时间从约 3% 涨到 19%。
  - 日志里 `UnsafeExternalSorter` 反复把排序数据溢写到磁盘，`TaskMemoryManager` 申请内存页失败；最后一条是 YARN 因物理内存超限杀容器：4.9 GB 用了 / 4.8 GB 上限。4.8 GB 正好等于 4g 堆加 800m overhead。
- 不像数据倾斜：600 个 task 的 Shuffle Read 在 168–197 MB 之间，记录数在 190–221 万之间，最大值只比中位数高约 9%。Duration 也只在 2.6–4.5 min。16 个 executor 的 Task Time、Spill 读数几乎一样（2.2–2.4 h，spill 约 51–54 GB）。所有 task 都是一起变慢，而不是少数几个拖后腿。
- 网络正常。CPU 83% 的读数不能直接说明"计算量变大"，因为 19% 的 task 时间花在了 GC 上，而且 spill 的序列化和 IO 也占 CPU。
- +2% 的数据量不足以解释：Stage 2 的 spill 从 0 变成每个 task 1.4 GB，不是 2% 的增长能做到的。

我的粗算（估算，不是实测）：每个 executor 的统一内存池约 (4096 - 300) × 0.6 ≈ 2.3 GB，4 个 task 并发，每个 task 平均约 570 MB 可用。而 Spill (Memory) 显示每个 task 要排序的数据反序列化后约 1.4 GB，大于这个份额，所以必然溢写。上周 16g 时同样算法每个 task 约 2.4 GB，大于 1.4 GB，所以 spill 为 0。这个口径与现象吻合，但它是推算，需要下面的验证来确认。

另一个要注意的点：按波次粗算，600 个 task 跑在 64 个并行槽位上约 9.4 轮，Stage 2 中位数从 1.1 min 到 3.4 min，大约多出 22 min。总耗时多了约 38 min，所以 Stage 2 只解释了其中的一大半，剩下约 16 min 还没有着落（可能是其他 stage、被杀后重跑、或读取新分区目录带来的开销）。

## ② 原因假设（按可能性从高到低）

**假设 1（最可能）：executor 内存从 16g 降到 4g，导致每个 task 分到的执行内存小于排序所需，引发 spill、GC 飙升并拖慢 Stage 2。**
依据：时间点吻合，上周 0 spill、本周全员 spill；spill 在所有 task 和所有 executor 上均匀出现，符合"整体配置不足"而不是"个别分区过大"；GC 从 3% 到 19%；日志中的页分配失败和多次 spill 与此一致。

**假设 2：堆外/overhead 余量不足，是被 YARN 杀掉重跑的直接原因，并额外增加耗时。**
依据：被杀时 4.9 GB / 4.8 GB。overhead 800m 与 4g 堆是配套缩小后的值，4 个并发 task 加上 Parquet 读取、shuffle 缓冲等非堆开销后容易超限。它和假设 1 相关但不完全相同：假设 1 解释"为什么慢"，假设 2 解释"为什么偶尔被杀"。它能解释上面那 16 min 里的一部分（重跑），但不确定占多少。

**假设 3（可能性较低，但值得排除）：读取新分区目录改变了扫描阶段（Stage 1）的开销，或者改变了进入 Stage 2 的数据形态。**
依据：用户说数据内容不变，这点我无法从材料里核实。目录结构变化可能影响文件列表、小文件数量、分区裁剪是否生效等，这些主要影响 Scan 阶段，不会直接造成 Stage 2 的 spill，但可能解释总时长里 Stage 2 之外那部分缺口。

已排除或不相关的项：数据倾斜（读数很均匀）；AQE 的 skewJoin 与广播阈值（执行计划里没有 Join，只有 Exchange、Sort、Window）；网络（正常）。

## ③ 每个假设对应的只读验证动作

**验证假设 1：**
- 在 History Server 打开上周和本周两次运行的 Environment 页，核对 `spark.executor.memory`、`memoryOverhead`、`memory.fraction`，确认唯一差异确实是 16g 对 4g。
- 在本周 Stage 2 的 Task 明细里看 "Peak Execution Memory" 和 Spill 列，对照上面约 570 MB 的每 task 份额估算，看是否吻合。
- 如需小样本试跑：取一天分区的约 1/10 数据，用同一份代码在测试队列各跑一次（`--conf` 仅对这次提交生效，4g 对 16g），不改集群默认模板。对比 spill、GC 和 Stage 2 耗时。试跑会占用资源，请先和运维确认队列。

**验证假设 2：**
- 在 YARN 的 NodeManager 日志里数本周和上周 "Container killed ... physical memory" 出现的次数和时间，看是否集中在 Stage 2 运行期间。
- 在 Spark UI 的 Executors 页展开 Peak Memory Metrics（如 ProcessTreeJVMRSSMemory、JVMOffHeapMemory），看被杀 executor（例如 executor 3）的峰值与 4.8 GB 上限的差距。

**验证假设 3：**
- 在 History Server 对比上周和本周的各 Stage 耗时，特别是 Stage 1（Scan）和 Stage 2 之外所有阶段的耗时总和，看缺的那约 16 min 在哪里。
- 在 SQL 页看 Scan parquet 节点：读取的文件数、分区过滤（PartitionFilters）是否生效、扫描耗时，与上周对比。

## ④ 说明

- 我没有修改任何配置，也没有下结论：目前证据最支持假设 1，但"最支持"不等于已确认，请以上述验证结果为准。
- 内存份额的估算按"4 个 task 同时运行、storage 内存基本未占用"来算，实际会有出入。
- 官方默认值我只引用了你材料里摘要的内容，没有另外去核对 Spark 4.0 的官方文档页面。
