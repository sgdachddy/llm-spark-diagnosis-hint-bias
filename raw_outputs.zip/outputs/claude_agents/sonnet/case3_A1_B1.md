**结论：这次失败大概率不是"集群内存不够"，而是 zone_attr_v2 被错误地选成了广播表。加内存只能暂时缓解，不是根因。**

## 证据链

1. **优化器以为这张表很小。** EXPLAIN COST 给出 zone_attr_v2 的 `sizeInBytes=8.2 MiB`，小于 `autoBroadcastJoinThreshold=10MB`，所以计划里是 `BroadcastHashJoin BuildRight`，把 zone_attr_v2 广播出去。
2. **这张表实际大得多。** S3 目录汇总是 6 个文件、共 1.8 GiB（Parquet 压缩后）。展开成内存里的哈希表后只会更大，一般是压缩体积的数倍。8.2 MiB 和 1.8 GiB 差了两个数量级以上。
3. **这个估算没有可靠来源。** DESCRIBE TABLE EXTENDED 里没有 Statistics 行，说明这张新表没有跑过 `ANALYZE TABLE`，catalog 里没有统计信息。所以 8.2 MiB 不是 catalog 里的真实统计，我无法确定它是怎么估出来的。
4. **崩溃位置对得上。** 栈里是 `HashedRelation.apply` / `HashedRelationBroadcastMode.transform` / `BroadcastExchangeExec`，也就是在构建广播哈希表时 OOM。这是 join 阶段的症状，不是普通的计算或 shuffle 内存不足。
5. **时间线对得上。** 作业代码没改，唯一变化是 zone_attr 换成了新生成的 zone_attr_v2（23:41 创建）。旧表有统计或体积小，所以昨天能正常广播。新表没有统计，体积也变大了，所以今天失败。

## 不太像的几种解释

- **数据倾斜：** 不太像。已完成的 61 个 task 的 Input Size 在 118～131 MB 之间，非常均匀。Duration 的最大值（1.2 min）也只比中位数（52 s）高一点。AQE 的 skewJoin 只处理 sort-merge / shuffled hash join，对广播 join 不起作用。
- **Spill：** Spill 全为 0，所以普通 task 的 execution 内存并不紧。
- **要注意的现象：** 这些健康 task 的 GC 也不低，中位数 14 s、最大 22 s，占 52 s 耗时的相当一部分。这说明堆里已经有较大的常驻对象，和广播哈希表占着内存的推断一致，但我不能仅凭这些数字断定。

## 建议（由易到难）

1. **先止血：** 让这个 join 不走广播。任选其一：
   - 在 SQL 里加 hint，例如 `/*+ SHUFFLE_HASH(z) */` 或 `/*+ MERGE(z) */`；
   - 或临时设置 `spark.sql.autoBroadcastJoinThreshold=-1`。

   1.8 GiB 的表做 shuffle join 对你们的 12×16 GB 集群毫无压力。
2. **补统计信息：** 执行 `ANALYZE TABLE ocean.zone_attr_v2 COMPUTE STATISTICS;`，然后重新看 EXPLAIN COST，确认 sizeInBytes 是否变成接近真实的数值。这时优化器会自动选对 join 策略。
3. **让上游脚本在写完表后自动执行 ANALYZE。** 否则以后每次换表都可能再踩同样的坑。
4. **追问上游：** zone_attr_v2 为什么是 1.8 GiB？旧 zone_attr 多大？schema 里有 `geom_wkt`（几何文本）和 `attrs`，我怀疑这两列把体积撑大了。如果 join 之后用不到它们，可以先 select 掉再 join，这样 join 的数据量和内存压力都会明显下降。
5. **最不推荐：** 单纯加大 executor 内存。1.8 GiB 的表做广播，每个 executor 都要放一份哈希表，成本会随体积放大，而且问题只是被推迟了。

## 需要你确认的点

- 我没有看到旧表 zone_attr 的体积，也没有看到 driver 内存配置。广播表是先在 driver 端收集再分发的，如果 driver 内存偏小，也会在这一步出问题。请把 `spark.driver.memory` 一并告诉我。
- 8.2 MiB 这个估算值的来源我不能确定。`ANALYZE` 之后再看一次 EXPLAIN COST，能直接验证上面的判断。
- 如果按第 1 步改完后作业仍然在 join 阶段 OOM，请把新的执行计划和 Spark UI 的 Stage 指标发给我，再继续排查，这时才应该考虑倾斜或内存配置。
