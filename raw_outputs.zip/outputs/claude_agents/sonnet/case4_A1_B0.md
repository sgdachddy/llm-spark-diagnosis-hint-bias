## 结论

根因是 executor 内存从 16g 降到 4g，导致每个 task 可用的执行内存不够，排序阶段持续溢写磁盘，GC 暴涨，最后还触发 YARN 物理内存超限被杀。这不是数据倾斜，也不是新分区目录或 +2% 数据量造成的。

## 证据链

**1. 不是倾斜。**
- Stage 2 的 Duration 是 2.6 到 4.5 min，中位数 3.4 min，最大值只有中位数的 1.3 倍。
- Shuffle Read Size 是 168 到 197 MB，记录数是 190 万到 221 万，各 task 都很均匀。
- 倾斜的典型特征是 Max 远大于 Median，这里不存在。
- AQE 的 skewJoin 只处理 join，本作业是 Exchange + Sort + Window，没有 join，所以它和 autoBroadcastJoinThreshold 都不相关。

**2. 每个 task 的执行内存不够，数字能对上。**
- 统一内存池约为 (4096 - 300) MB × 0.6 ≈ 2.2 GB。
- 一个 executor 有 4 核，并发 4 个 task，每个 task 最多约 550 MB。
- 一个 task 的 Window 要把 200 万条记录反序列化后在内存中排序，Spill (Memory) 中位数是 1.4 GB，远大于 550 MB，所以必然溢写。
- 对照 16g：(16384 - 300) × 0.6 ≈ 9.4 GB，除以 4 约 2.3 GB，大于 1.4 GB，所以上周 Spill 全为 0，也和观察一致。
- 溢写出现在所有 task 和所有 executor 上，是系统性的，不是个别分区的问题。

**3. GC 和慢的因果。**
- GC 占比从 3% 升到 19%，是内存紧张的结果。
- 反复申请内存页失败（日志里 "Failed to allocate a page ... try again"），再加上频繁溢写，task 的中位耗时从 1.1 min 变成 3.4 min。
- CPU 83% 不代表在做有效计算，其中很大一部分花在 GC 以及溢写时的序列化、压缩和磁盘 IO 上。

**4. YARN 杀 executor 也是同一个原因。**
- 容器上限 = 4g + 800m overhead ≈ 4.8 GB，日志里 "4.9 GB of 4.8 GB" 正好对上。
- 堆内存吃紧时，排序缓冲、shuffle 读取缓冲、Netty 等堆外开销叠加，就会超过容器上限。被杀后 task 重跑，进一步拉长总时间。

**5. 其他改动基本排除。**
- 新分区目录只改变读取路径，数据内容不变。
- +2% 的数据量不可能带来 3 倍的变慢。
- 网络读数正常。
- 更直接的反证是，上周同一 Stage 在 16g 下 Spill 为 0，本周唯一和内存相关的改动就是 16g 降到 4g。

## 建议

按推荐顺序：

1. **直接恢复 `spark.executor.memory=16g`**，同时把 `spark.executor.memoryOverhead` 提到 2g 左右。这是最直接的修复，预期 Spill 回到 0，被杀的情况也消失。
2. **如果必须控成本，用折中方案：**
   - 把 `spark.sql.shuffle.partitions` 从 600 提到约 2400，让每个分区缩小到原来的 1/4。按比例估算，单 task 的内存需求约 350 MB，低于 4g 配置下约 550 MB 的份额，但余量不大。
   - 同时把 overhead 提到 1.5 到 2g。
   - 也可以降低 `spark.executor.cores`（比如 2 核），让每个 task 多分到内存，再相应增加 executor 数量。
   - 注意 AQE 的分区合并可能把小分区又合并回去，如果发现合并后又溢写，需要看一下 AQE 的合并设置。
3. **成本账要重新算。** 4g 配置下作业从 20 min 变成 58 min，还有重跑，节省的内存成本很可能被多出来的运行时间抵消。建议用同一口径比较「内存 × 时间」，不要只看单个 executor 的规格。

## 验证方法

改完后重跑，在 Stage 2 看这几项：
- Spill (Memory) 和 Spill (Disk) 为 0 或接近 0。
- GC time 占比回到 5% 以下（上周约 3%）。
- Duration 中位数回到约 1 min。
- 不再出现 "Container killed by YARN" 日志。

## 说明

我没有看到 Window 的具体定义（partitionBy 和 orderBy 的列、是否带 frame），也没有 Stage 1 的数据，所以上面的内存估算是量级判断，不是精确值。以上推断基于你提供的配置和指标，建议用上面的验证项确认。
