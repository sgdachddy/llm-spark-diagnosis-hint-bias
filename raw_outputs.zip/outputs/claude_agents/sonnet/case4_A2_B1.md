先说一句：你的材料里 Stage 2 各 task 的读数很均匀，不太像数据倾斜。下面按你要求的四步来写，所有验证动作都只读，不修改集群或配置，也不直接下结论。

## ① 现象与关键读数（人话版）

- 作业 `ais_track_segments` 从约 20 min 变成约 58 min，偶尔有 executor 被 YARN 杀掉后重跑。
- 本周变化：executor 内存从 16g 降到 4g，读新的按天分区目录（内容不变），输入量 +2%。
- Stage 2（Window 排序切分）共 600 个 task，各 task 之间差别很小：
  - Duration：中位数 3.4 min，最大 4.5 min，最大值约为中位数的 1.3 倍。
  - Shuffle Read 大小和记录数：最大值只比中位数高约 9%（197 MB 对 181 MB，221 万对 203 万条）。
  - 所有 task 都在 spill：内存里 1.1 到 1.7 GB，落盘 0.4 到 0.7 GB。上周同一 Stage 的 spill 全是 0，Duration 中位数 1.1 min。
- 3 个 executor 的读数几乎一样（Task Time 约 2.2 到 2.4 h，spill 约 51 到 54 GB），你说其余 13 个相近。可见是整个集群一起变慢，不是个别 executor 被拖累。
- GC 占比从约 3% 升到 19%，CPU 利用率 83%，网络正常。这说明 CPU 在忙 GC 和反复溢写，不在做有效计算。
- 日志里 `UnsafeExternalSorter` 反复 spill（同一线程已溢写 7 次、9 次），还有 `Failed to allocate a page`。YARN 杀容器时读数是 4.9 GB 对 4.8 GB 上限，而上限正好是 `4g + 800m overhead`。
- 配置里 `spark.executor.memory=4g`，4 核，`spark.memory.fraction=0.6`。

一个粗算：(4096 MB − 300 MB) × 0.6 ≈ 2.2 GB 是统一内存。4 个 task 并发时，每个 task 的 execution 内存大约在 0.28 到 0.57 GB 之间。日志里每次溢写约 400 MB，量级吻合。Spill (Memory) 平均每个 task 1.4 GB，远大于这个份额。如果是 16g，同样的算法每个 task 约 2.4 GB（上限份额），装得下 1.4 GB，对应上周 spill 为 0。这个粗算依赖"上周是 16g、其余配置没变"这一前提，需要验证。

另外，你贴的官方默认值摘要里的 `skewJoin`、`autoBroadcastJoinThreshold` 都是针对 join 的。EXPLAIN 里是 `Exchange → Sort → Window`，没有 join，所以这两项和本作业基本无关，AQE 的倾斜 join 处理在这里不会起作用。

## ② 原因假设（按可能性从高到低）

**假设 1（最可能）：executor 内存从 16g 降到 4g，每个 task 分到的 execution 内存不够，导致全面 spill、GC 飙升，并在高峰时撑破容器上限被 YARN 杀掉。**
证据：所有 task 都 spill 且数量级一致；GC 从 3% 升到 19%；内存调整正好发生在本周；spill 日志和 YARN 杀容器日志与 4g + 800m 的上限吻合；上周同一 Stage 没有 spill。

**假设 2（可能性中等）：新的分区目录让 Scan 读到的数据形态变了（读了更多列、分区或谓词没有下推、文件更小更碎），使每条记录进入 Window 排序时更"宽"，进一步放大内存压力。**
证据：目录结构变了，且 EXPLAIN 里 `Filter` 在 `Scan` 之上，节选里看不出分区过滤和列裁剪是否生效。局限：输入量只增 2%，这一项单独很难解释 3 倍的耗时，更可能是叠加在假设 1 上的放大因素。

**假设 3（可能性最低）：存在少数超大 mmsi（轨迹点特别多的船）造成的数据倾斜。**
证据：目前不支持。若有热点船，应该能看到少数 task 的 Shuffle Read 和 Duration 远高于中位数，而现在最大值只比中位数高 9% 到 30%。只有一个情况需要排除：Window 按 mmsi 分区时，单个 mmsi 的全部行必须在同一个 task 内排序，所以单船数据量极端时才会出问题，而你的读数里没有这种迹象。

## ③ 每个假设对应的只读验证动作

**假设 1：**
对比上周和本周同一作业的 Spark History Server 页面。看 Environment 标签里的 `spark.executor.memory`、`memoryOverhead` 是否确实是 16g 对 4g，其余配置有无变化。再看 Stage 2 的 Summary Metrics 里 Spill 列是否从 0 变成现在的量级。同时核对本周所有 Stage 的 Spill 和 GC，确认不只是 Stage 2。这一步只读历史数据，不动任何配置。如果想进一步确认，可以在独立的测试会话里用小样本（比如一天里的一部分 mmsi）按 16g 试跑一次，看 spill 是否消失。这只是一次性试跑，不改线上模板和集群默认值。

**假设 2：**
用 `EXPLAIN FORMATTED` 对比两周的 Scan 节点，重点看 `PartitionFilters`、`PushedFilters` 和 `ReadSchema`（读了哪些列）。再在 Spark UI 的 SQL 页签里对比 Scan 节点的 "number of files read"、"size of files read"、"number of partitions read"。如果本周读的分区数、文件数或列数明显多于上周，就支持这个假设。

**假设 3：**
在 Spark UI 里把 Stage 2 的 task 列表按 Shuffle Read Records 降序排，看前 10 个是否明显离群。同时对某一天的数据做一个只读的小查询，例如 `SELECT mmsi, COUNT(*) c FROM ais_points WHERE <某一天> GROUP BY mmsi ORDER BY c DESC LIMIT 20`，看最大几个 mmsi 的点数与中位数的差距。如果头部 mmsi 只比中位数高几倍而不是几百倍，倾斜就可以基本排除。

## ④ 当前不下结论

以上只是按可能性排序的假设。目前读数最支持假设 1，但要等上面的对比结果出来再确认。在验证完成之前，我不会建议你改任何配置、调分区数或加盐。如果验证后确认，再讨论是恢复内存、调整并发核数、调大 shuffle 分区，还是其他办法，那时再逐项评估。
