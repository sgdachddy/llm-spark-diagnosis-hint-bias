先说结论：**最可能的原因是优化器把 zone_attr_v2 当成约 8 MB 的小表做了广播，而它实际约 1.8 GiB。** 广播时构建哈希表撑爆了 executor 堆内存。这是我根据材料做的推断，下面有一处数据矛盾需要你核实。

## 依据

1. 报错栈走的是 `BroadcastExchangeExec → HashedRelationBroadcastMode.transform → UnsafeHashedRelation`，最终是 `OutOfMemoryError: Java heap space`。这是构建广播哈希表时内存不足，不是普通的 shuffle 或聚合 OOM。
2. 物理计划是 `BroadcastHashJoin BuildRight`，广播的是 zone_attr_v2。EXPLAIN COST 里它的估算大小是 8.2 MiB，低于 10MB 的阈值，所以被选中广播。
3. 但存储目录显示 zone_attr_v2 共 6 个文件、1.8 GiB，和 8.2 MiB 差了两个数量级。
4. 这张表是昨晚新生成的，表属性里没有 Statistics 行，也就是没有执行过 `ANALYZE TABLE`。作业代码没改，唯一变化就是这张表，所以它是首要怀疑对象。
5. Parquet 是压缩格式。1.8 GiB 的文件解压后，尤其是 `geom_wkt` 这种长文本列，再变成哈希表，在内存里会比磁盘上大得多。每个 executor 都要装下这份广播数据，所以多个 executor 先后挂掉，重试 4 次也无济于事。

## 需要你核实的矛盾

DESCRIBE 里没有 Statistics，EXPLAIN COST 却给出了 8.2 MiB，而目录实际是 1.8 GiB，这三者互相对不上。按常理，没有统计信息时 Spark 会按文件实际大小估算，不该出现 8.2 MiB。

可能的原因：EXPLAIN 是在表被重写之前或另一个环境下抓的，统计信息过期，或者 S3 目录里混有不属于该表的文件。你可以确认以下几点：

- 失败那次运行里，Spark UI 的 SQL 页上 BroadcastExchange 显示的 `data size` 是多少。这个数字最能说明问题。
- 在失败的同一个环境里重新执行一次 `EXPLAIN COST`，看估算值是否还是 8.2 MiB。
- `SELECT count(*), sum(length(geom_wkt)) FROM ocean.zone_attr_v2`，并与旧的 zone_attr 对比，看 v2 是不是新增了大字段，或者行数暴增。

如果这几项显示广播数据确实很大，上面的结论就成立。如果 8.2 MiB 反而是真实大小，我的判断就要重新考虑。

## 不太像的原因

- **数据倾斜**：已完成的 61 个 task，输入量 118 到 131 MB，耗时 41 秒到 1.2 分钟，分布很均匀，也没有 spill。
- **内存配置偏小**：昨天同样配置能跑，问题出在广播数据量上，调大内存只是治标。
- **shuffle 分区数、`spark.memory.fraction`**：这个失败发生在广播构建阶段，这些参数帮不上忙。

## 建议

**先让作业恢复运行**，任选其一：

- 提交时设 `spark.sql.autoBroadcastJoinThreshold=-1`，关闭广播。这个 join 会改走 shuffle join，AQE 开着的话，运行期如果发现某一侧确实很小，还可以自动转回广播。
- 或者在 SQL 里对 zone_attr_v2 那一侧加 `/*+ MERGE(...) */` 或 `/*+ SHUFFLE_HASH(...) */` 提示，只影响这一个 join。
- 如果统计作业只需要 `zone_id` 和少量属性，就在 join 前先只选这几列，不要带 `geom_wkt`。这样数据量会大幅下降，广播也许就没问题了。

**再解决根因：**

- 对 zone_attr_v2 执行 `ANALYZE TABLE ocean.zone_attr_v2 COMPUTE STATISTICS`，让优化器拿到准确的大小。
- 让上游生成脚本在写完表之后自动执行这一步，以后换表就不会再发生同类问题。
- 和上游确认 v2 为什么比旧表大这么多，是不是新增了几何字段，这是否是预期内的变化。

如果你把 BroadcastExchange 的 data size，以及 zone_attr 和 zone_attr_v2 的行数、列定义贴给我，我可以进一步确认结论。
