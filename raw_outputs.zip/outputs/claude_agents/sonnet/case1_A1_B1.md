**结论：不是内存不够，是数据倾斜。** 而且新模板里 `spark.sql.adaptive.enabled=false` 把 Spark 自带的倾斜处理关掉了，这很可能就是"昨天正常、今天变慢"的原因。加内存治标不治本，不建议先动内存。

## 证据

1. **只有 1 个 task 慢，其余 399 个都正常。**
   - Stage 3 的 task 耗时，中位数 8 s，最大 45 min。
   - 这 400 个 task 在 300 核上基本一轮就跑完，整个 stage 的时长就是那一个 task 的时长（附 2）。

2. **那个 task 的数据量是别人的约 400 倍。**
   - Shuffle Read Size：中位数 21 MB，最大 8.4 GB，约 400 倍。
   - Shuffle Read Records：中位数 30 万，最大 1.2 亿，同样约 400 倍。
   - 数据量和记录数同比例偏大，说明是某个 key 的数据特别多，不是单条记录特别大。

3. **溢写只发生在 executor 7 的那一个 task 上。**
   - 附 3 里其他 9 个 executor 的 Shuffle Read 都在 0.82~0.86 GB，几乎没有溢写。
   - executor 7 一个 executor 就读了 9.2 GB，溢写 96 GB（内存）/ 38 GB（磁盘）。
   - 日志里 task 287 反复把约 4 GB 排序数据写到磁盘（附 6）。
   - 这是 task 287 的数据量太大，在 Sort 阶段放不下造成的，不是集群内存配置整体不足。

4. **集群整体很空闲。**
   - CPU 利用率 12%，GC 占 3%，网络正常（现象与附 1）。
   - 内存吃紧的集群 GC 会很高，这里不是这种表现。
   - 299 个核在等 1 个核。

5. **推测执行（speculation）没有用。**
   - 日志里 task 287 在 executor 3 起了备份 task，最后被杀掉（附 6）。
   - 备份 task 拿到的是同一份倾斜数据，不会更快。
   - 推测执行只对"机器慢"有用，对"数据多"没用。

## 为什么是现在出问题

- 执行计划是 `SortMergeJoin`，按 `h3_r7` 做 `hashpartitioning(h3_r7, 400)`（附 4）。同一个 `h3_r7` 值的所有点必然落到同一个分区，如果有一个格子的点特别多，就会形成上面那个 8.4 GB 的分区。
- Spark 4.0 默认 `spark.sql.adaptive.enabled=true`，同时 `spark.sql.adaptive.skewJoin.enabled=true`，会自动把倾斜分区拆开并行处理（版本说明书）。
- 你这次生效的配置里是 `spark.sql.adaptive.enabled=false`（附 5），来自新版模板 `job_template_v3.conf`。倾斜拆分因此没有生效。
- 数据量只涨了 4%，不足以解释 9 倍的变慢。更合理的解释是：这个热点格子一直存在，只是以前有 AQE 兜底，现在没了。

**需要说明的一点：** "以前是靠 AQE 兜底"是我根据默认值和你说的改动做的推断。你给的材料里没有旧版配置，所以不能 100% 确认。建议拿旧的提交配置和 `job_template_v3.conf` 对比一下，看 AQE 是不是这次才被关掉的，也顺便看看还有没有别的差异。

## 建议的处理

1. **先打开 AQE（最小改动，首选）。**
   - 在模板或提交参数里设 `spark.sql.adaptive.enabled=true`。
   - `spark.sql.adaptive.skewJoin.enabled` 默认就是 true，不用另设。
   - 重跑后在 Spark UI 的 SQL 页面看计划，确认出现 AQE 相关的节点，并且 Stage 3 的 task 耗时分布变平：最大值不再是几十分钟，Shuffle Read 最大值不再比中位数大两个数量级。

2. **确认热点到底是什么 key。**
   - 对 `ais_points` 按 `h3_r7` 做一次 `count(*)` 分组，看前几名。
   - 如果是某个港口、锚地、或者 `0`/空值这类占位值（比如定位失败时填的默认格子），可以考虑在 join 前过滤掉或单独处理。
   - 这一步能告诉你倾斜是业务上真实存在的，还是数据质量问题。

3. **如果 `zone_attr` 其实很小，可以改成广播 join。**
   - 当前计划没有广播，说明优化器估算它大于 `autoBroadcastJoinThreshold`（默认 10 MB），或者缺统计信息。
   - 如果它实际不大，可以用 `BROADCAST(zone_attr)` 提示，这样 `ais_points` 完全不需要按 `h3_r7` shuffle，也就没有倾斜了。
   - 我不知道 `zone_attr` 的实际大小，所以这条需要你先确认；太大的表广播会让 driver 和 executor 内存吃紧。

4. **不建议的做法。**
   - 不建议单纯加大 executor 内存：即使 task 287 不再溢写，它仍然要一个核独自处理 1.2 亿条，依然是整个 stage 的瓶颈，只是从 45 min 变成可能十几分钟。
   - 推测执行可以保留，也可以关掉，对这个问题没有影响。

## 还需要你确认的

- 旧配置里 AQE 是不是开着的（用来验证上面的推断）。
- `h3_r7` 的 top key 分布，以及 `zone_attr` 的大小。

把这两项发给我，我可以帮你判断是用 AQE 就够了，还是需要同时做过滤或广播。
