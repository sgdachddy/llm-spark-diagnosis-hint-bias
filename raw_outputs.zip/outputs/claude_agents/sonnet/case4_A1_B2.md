## 结论

你的判断对：这次变慢就是 executor 内存不够，直接原因是本周把 `spark.executor.memory` 从 16g 调到了 4g。数据倾斜、AQE、网络、新分区目录和 +2% 的数据量，都不是主因。

## 证据

1. 症状和内存不足完全吻合。
   - Stage 2 的 Spill 从上周的全部为 0 变成每个 task 约 1.4 GB（内存）/ 0.55 GB（磁盘）。
   - GC 占比从 3% 升到 19%。
   - 附 5 的日志里有多次 `spilling sort data to disk`、`Failed to allocate a page`，最后是 YARN 因物理内存超限杀掉容器。
2. 容器上限能对上。日志写 "4.9 GB of 4.8 GB"，正好是 `4g + 800m overhead`。executor 3 被杀一次，说明堆外加堆内已经顶到了容器上限。
3. 内存预算算得出来。
   - 4g 堆的 execution + storage 池约为 (4096 − 300) × 0.6 ≈ 2.2 GB。
   - 4 核共享这个池，每个 task 大约只能分到 0.55 GB，最低保底约 0.28 GB。
   - 而每个 task 排序所需的内存实测约 1.4–1.7 GB（Spill Memory 就是这个量级），装不下，只能反复溢写。
   - 16g 时同样算法，每个 task 约 2.4 GB，刚好够用，所以上周 Spill 为 0。
4. 数字自洽。每个 executor 的 Spill (Memory) 约 52 GB，约等于 600 个 task × 1.4 GB ÷ 16 个 executor，和 Stage 2 的汇总一致。
5. 耗时放大比例对得上。Stage 2 的 Median 从 1.1 min 变成 3.4 min（约 3.1 倍），整体从 20 min 变成 58 min（约 2.9 倍）。慢的主要就是这一个 Stage。

## 已排除的方向

- **数据倾斜：不是。** Duration 的 Max/Median 约 1.3，Shuffle Read 的 Max/Median 约 1.09，所有 task 都在溢写，各 executor 读数相近。倾斜的特征是少数 task 极慢、极大，这里看不到。所以去调 AQE skew 相关参数没有意义。另外这个作业是 Exchange + Sort + Window，没有 join，`skewJoin` 和 `autoBroadcastJoinThreshold` 这两项文档摘要都与本作业无关。
- **网络：** 读数正常。
- **CPU 83%：** 这不代表有效计算，是 GC 和反复排序溢写在占 CPU，不是 CPU 瓶颈。
- **新分区目录：** 数据内容没变，Shuffle Read 也很均匀。如果目录结构带来小文件问题，应该表现在 Stage 1 的扫描上，而不是 Stage 2 的溢写上。你没有给我 Stage 1 的数据，所以这一点我没法完全排除，但它解释不了 Stage 2 的变化。
- **数据量 +2%：** 最多带来 2% 的变化，解释不了 3 倍。

## 建议

1. **首选：把 executor 内存恢复到 16g**，overhead 也按比例放大（比如 1.5–1.6g，而不是 800m）。这是改动前确认过的状态。
2. **想省成本：** 折中可以试 12g。按上面的算法，每个 task 约 1.8 GB，勉强覆盖 1.7 GB 的最大值，余量不大。8g 估算每个 task 约 1.2 GB，仍会溢写，不建议。
3. **不改内存的备选：** 把 `spark.sql.shuffle.partitions` 从 600 提到 2000 左右，让每个 task 的数据量降到约 400 MB 内存占用；或者把 `executor.cores` 降到 2，每个 task 的内存翻倍。这两种办法都有代价（task 变多、并行度降低），在 4g 下 GC 压力也未必能完全消除。
4. **验证方法：** 改完重跑后看 Stage 2 的 Spill 是否回到 0、GC 占比是否回到 5% 以内、Median 是否回到 1 min 左右。如果 Spill 没清零，就继续加内存或加分区。

## 需要说明的限制

上面的每 task 内存预算是估算，没有算 Window 缓冲和 Java 对象开销的细节，具体数值请以重跑结果为准。另外 4g 省下来的成本，实际是用作业变慢三倍、偶发重跑换来的，核算时需要把运行时长也算进去。
