结论先说：你的判断基本成立，zone_attr_v2 确实被广播了，而且这次失败大概率就是广播这张表导致的 OOM。但有一处材料互相矛盾（优化器估算 8.2 MiB，磁盘上却有 1.8 GiB），这是真正的根因，需要你再确认一步。

## 证据链

1. **执行计划**：附 3 里是 `BroadcastHashJoin Inner BuildRight`，build 侧是 `BroadcastExchange` 加 `Scan parquet zone_attr_v2`。zone_attr_v2 确实走了广播。
2. **报错栈**：栈里是 `HashedRelationBroadcastMode.transform`、`UnsafeHashedRelation.apply`、`BroadcastExchangeExec`，错误是 `OutOfMemoryError: Java heap space`。也就是在构建广播哈希表时堆内存耗尽。"heartbeat timed out"是 OOM 后 GC 打满的伴随现象，不是独立原因。
3. **为什么会被选中广播**：附 4 里优化器估算 `sizeInBytes=8.2 MiB`，低于 `autoBroadcastJoinThreshold=10MB`，所以被选为广播。
4. **估算与实际不符**：附 6 显示目录实际 6 个文件、共 1.8 GiB，是估算值的约 225 倍。附 5 的 DESCRIBE 里没有 Statistics 行，说明没有可靠的统计信息。
5. **昨天正常、今天失败**：表是昨天新生成并替换的，作业代码和配置没动，差异只在这张表上。

## 可以排除的方向

- **数据倾斜**：附 2 里已完成 task 的 Input 为 118 到 131 MB，很均匀，Duration 中位数 52 s、最大 1.2 min，没有 Spill。不是 stage 4 里 task 倾斜。`skewJoin` 只作用于 sort-merge 或 shuffled hash join，对广播 join 无关。
- **shuffle 分区数、executor 数量**：12 个 executor、每个 16 GB，常规 task 本身负载不大，不是资源配得太小。

不过 GC 时间占了 task 时长的 25% 以上（中位数 14 s / 52 s），说明堆压力确实已经很高。

## 需要你确认的疑点（我没法从材料里判断）

8.2 MiB 和 1.8 GiB 到底哪个对，决定了根因，我看有三种可能：

- **统计信息过期或错误**：表是上游脚本重新生成的，catalog 或缓存里可能残留旧估算。可以执行 `REFRESH TABLE ocean.zone_attr_v2`，再重新跑 `EXPLAIN COST` 看数值是否变化。附 5 是节选，也请看一下完整输出和 Table Properties 里有没有 `spark.sql.statistics.totalSize` 之类的字段。
- **目录里混有非数据文件**：`aws s3 ls --recursive` 会把目录下所有对象都算上，包括失败写入遗留的临时文件或旧版本文件。请列出这 6 个对象的名称和大小，确认 1.8 GiB 是不是都是有效 parquet 数据。
- **数据确实就是 1.8 GiB**：那这张表比旧的 zone_attr 大了很多（我不知道旧表多大，你可以对比一下）。`geom_wkt` 这种文本几何列在内存里的哈希表远大于磁盘上的压缩体积，广播到 16 GB 堆里再加上执行内存的占比限制（`spark.memory.fraction=0.6`），OOM 是合理的。另外 8.2 MiB 恰好是 1.8 GiB 的一个很不吻合的数，不太像是同一份数据的不同度量，更像是估算源出了问题。

另外，我没有看到 driver 内存的配置（附 7 只有 executor 的）。广播表是先在 driver 端收集并构建的，你说栈是 driver 端的，那也需要确认 `spark.driver.memory` 是否够用。

## 建议处理

**先止血（让作业今天能跑完）**，任选其一：

- 针对这个作业设置 `spark.sql.autoBroadcastJoinThreshold=-1`，禁用广播，让 join 走 sort-merge。这是文档里明确支持的做法。
- 或者在 SQL 里对这个 join 加 hint，比如 `/*+ MERGE(zone_attr_v2) */` 或 `SHUFFLE_HASH`，只影响这一处，不影响其他作业。

我更倾向用 hint，影响面更小。关闭广播后 join 会产生 shuffle，耗时可能比昨天的 12 分钟长一些，这是正常代价。

**再治本**：

1. 用 `ANALYZE TABLE ocean.zone_attr_v2 COMPUTE STATISTICS` 补上准确的统计信息，让优化器不再低估。
2. 让上游生成脚本在写完表后自动做这一步，或者至少保证每次替换表后做 `REFRESH TABLE`。
3. 看一下 join 实际用到 zone_attr_v2 的哪些列。如果 `geom_wkt` 和 `attrs` 不是统计进出港事件必需的，在 join 前先 select 需要的列，build 侧会小很多，也可能让广播重新变得安全。
4. 和上游确认这张表为什么变大了，是新增了数据还是列的内容变了。

## 怎么验证我的判断

- 打开 Spark UI 的 SQL 页，找到失败查询里的 BroadcastExchange 节点，看 "data size" 这类指标。如果它是 GB 级，就直接坐实了。
- 或者做对照实验：只加 `autoBroadcastJoinThreshold=-1` 重跑，如果作业恢复正常，说明广播就是原因；如果仍然失败，那就要回头查别的方向，我这边需要看到新的报错。
