## ① 现象与关键读数（人话版）

- 作业昨天正常（约 12 分钟），今天在 join 阶段失败：多个 executor 陆续退出，重试 4 次后终止。唯一的变化是上游把 `zone_attr` 换成了新生成的 `zone_attr_v2`，作业代码没改。
- 报错栈里 OOM 发生在 `BroadcastExchangeExec -> HashedRelationBroadcastMode.transform -> UnsafeHashedRelation.apply`，也就是在为广播 join 构建哈希表时内存不够。同时有 executor 心跳超时，可能是 GC 卡死所致。
- 执行计划用的是 `BroadcastHashJoin BuildRight`，被广播的是 `zone_attr_v2`。
- 有两个读数互相矛盾：
  - 优化器认为表只有 8.2 MiB，低于 10MB 的广播阈值，所以选了广播。
  - S3 上实际是 6 个文件、共 1.8 GiB，约为估计值的 200 多倍。
  - `DESCRIBE TABLE EXTENDED` 里没有 Statistics 行，所以那个 8.2 MiB 的来源并不清楚。
- Stage 4 已完成的 61 个 task 里，Input 在 118~131 MB 之间，耗时 41s~1.2min，没有 spill。这说明数据基本均匀，没有明显的数据倾斜。GC 占比偏高（中位数 14s / 52s，约 27%），说明堆内存已经很紧张。
- AQE 的 skew join 优化只作用于 shuffle 类 join，对广播 join 不起作用，所以"倾斜"不是首要怀疑对象。

## ② 原因假设（可能性从高到低）

**假设 1：表大小的估计值是错的，真实大小远超 10MB，导致不该广播的表被广播。**
8.2 MiB 与 1.8 GiB 的差距太大，而且这个估计值缺乏可见来源（表没有 Statistics 行）。可能是统计信息陈旧或带有错误来源，比如上游脚本生成表时带入了旧表 `zone_attr` 的统计，或有错误的表属性。

**假设 2：即使磁盘上是压缩的 parquet，加载到内存构建哈希表后会严重膨胀，加上数据本身有问题。**
`geom_wkt` 是几何的文本串，通常很长，`attrs` 可能是复杂类型。parquet 压缩加上字典编码后，内存里展开的体积可能是磁盘的数倍到十几倍。另外，如果上游脚本重复写入，`zone_id` 可能出现大量重复行，哈希表会更大。这个假设与假设 1 可以同时成立：假设 1 解释"为什么被广播"，假设 2 解释"为什么一广播就爆"。

**假设 3：executor 的内存和并发余量本来就偏紧，新表只是压垮了它。**
每个 executor 有 8 核共用 16GB 堆内存，其中 `spark.memory.fraction=0.6`，实际可用于 execution 和 storage 的约 9.4GB。广播变量要在每个 executor 里放一份，同时 8 个 task 并发跑，GC 本来就不低。心跳超时可能是长时间 Full GC 导致的，而不只是纯 OOM。这个假设排在最后，原因是昨天同样的配置能正常跑，说明变量主要在新表上。

## ③ 每个假设的验证动作（均为只读）

**验证假设 1：核对真实大小，并追查 8.2 MiB 的来源。**
- 看失败那次作业在 Spark UI 的 SQL 标签页里 `BroadcastExchange` 节点的指标（`data size`、`number of output rows`、`collect time`）。如果有数据，它反映的是真实被收集的体量。
- 执行 `SHOW TBLPROPERTIES ocean.zone_attr_v2`，看有没有 `spark.sql.statistics.*` 之类的属性，并与旧表 `zone_attr` 的属性对比。
- 用 parquet 的 footer 元数据（比如 `parquet-tools meta` 或 pyarrow 读 metadata，只读文件尾部）查看总行数和 `total_uncompressed_size`，与 8.2 MiB 对比。

**验证假设 2：在小样本上度量内存膨胀和键重复情况。**
- 只读地跑一个小样本查询，例如：`SELECT count(*), count(DISTINCT zone_id), sum(length(geom_wkt)), max(length(geom_wkt)) FROM ocean.zone_attr_v2`，看总行数是否远多于不同的 `zone_id` 数（判断是否有重复），以及 `geom_wkt` 的平均和最大长度。
- 再对 1% 左右的样本做一次 `cache` 后查看 Storage 页里的内存占用，乘以抽样倍数估算全表的内存大小。这只是在作业外做的试跑，不修改任何配置或数据。

**验证假设 3：对比两次运行的 executor 内存和 GC 情况。**
- 在失败作业的 Spark UI Executors 页看每个 executor 的 GC Time 占比、峰值内存，并查看 executor 日志（stderr）里 OOM 或心跳超时发生的时间，是否正好在构建广播表（BroadcastExchange）的这一段。
- 找昨天成功那次运行的历史 UI（History Server），对比同一个 join 的 `BroadcastExchange` 数据量和 executor GC 占比。如果昨天的广播量只有几 MB 而今天上了 GB 级，就更支持假设 1 和 2；如果昨天已经接近极限，才更偏向假设 3。

## ④ 说明

按你的要求，我没有建议修改集群或配置，也不下结论。目前材料只能确定"广播的估计大小与真实大小严重不符"这个事实，真正的原因要看上面几个验证的结果再判断。
