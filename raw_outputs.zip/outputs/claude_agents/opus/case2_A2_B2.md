你怀疑 persist 有问题，这个方向和读数对得上。不过按你的要求，下面只给假设和只读的验证动作，不下结论，也不改任何配置。

## ① 现象和关键读数

**现象**：作业没报错，但从约 18 min 变成约 31 min，多了约 13 min。

**时间多在哪里（把 Jobs 表加起来）**：
- 本周：9.5 + 7.1 + 7.6 + 6.8 = **31.0 min**
- 上周：6.2 + 5.8 + 5.9 = **17.9 min**
- 多出的 13 min 分两块：
  - **新增的 Job 0（`feat.count()` 物化缓存）占 9.5 min**，约占增量的 3/4；
  - 三个特征 Job 加起来**还慢了约 3.6 min**（+0.9 / +1.8 / +0.9）。
- 反常的地方：加缓存本来是为了让后面三个 Job 变快，结果它们反而都变慢了。缓存既要先花一笔物化的钱，后面也没省下时间。

**关键读数**：
- **集群很闲，但在等磁盘**：CPU 利用率只有 34%，磁盘 IO wait 从约 5% 升到 28%。GC 占 6%，不算高。
- **缓存大部分在磁盘上**：feat 共 40 GB，内存里只有 10.2 GB，磁盘上有 29.8 GB，约 3/4 落盘。按配置估算，统一内存约为 (24 GB − 0.3 GB) × 0.6 ≈ 14.2 GB/executor，全集群约 142 GB。按理说 40 GB 能装下不少，实际却只进了 10 GB，这一点本身就值得查。
- **聚合开始溢写，上周没有**：Job 2 聚合 Stage 每个 task 的 shuffle read 只有约 104 MB，却有约 1.0 GB 的 Spill (Memory) 和约 0.35 GB 的 Spill (Disk)。上周同一 Stage 的 spill 全是 0。
- **没有数据倾斜**：320 个 task 的耗时在 58 s 到 1.9 min 之间，shuffle read 在 92 到 121 MB 之间，分布很均匀。
- **执行计划**：Job 2 改为从 `InMemoryTableScan` 读缓存，缓存里存的是 ReadSchema 的全部 8 列。上周每个 Job 直接扫 parquet，可以只读自己用到的列。计划节选里没有 Python UDF 节点。

## ② 可能的原因假设（按可能性从高到低）

**假设 1（最可能）：缓存本身"不划算"。物化成本高，而且读的大多是磁盘上的缓存块，不比直接读 parquet 快。**
依据：Job 0 一项就是 9.5 min。缓存约 75% 在本地磁盘，后续 Job 实际在读本地磁盘的缓存块，而且是全部 8 列。上周直接读 parquet 时，可以做列裁剪和谓词下推，每个 Job 只要约 6 min。

**假设 2：缓存和后续的 shuffle/spill 抢本地磁盘和内存，把聚合拖慢了。**
依据：spill 从 0 变成每个 task 约 1 GB，IO wait 从 5% 涨到 28%，而 CPU 只用了 34%。缓存块落盘、shuffle 文件、spill 文件很可能都写在同一批本地盘上，互相争 IO。另外，缓存块占用的 storage 内存可能挤小了聚合能用的 execution 内存。这可以解释后面三个 Job 为什么都慢了 1 到 2 min。

**假设 3（可能性低）：输入 +3% 或 h3 小版本升级带来的增量。**
依据：数据只多了 3%，按比例算约 0.5 min，不足以解释 13 min。`h3_r7` 是上游预先算好写进 parquet 的，Job 2 的计划里也没有 Python UDF 节点。但目前只看了 Job 2 的计划，Job 1 和 Job 3 是否在别处调用了 h3 还没确认。

（以下几项按现有读数基本可以先放一边：task 分布均匀，不像倾斜；作业里没有 join，所以 `skewJoin` 和 `autoBroadcastJoinThreshold` 管不到这里；GC 6% 不是主要瓶颈。）

## ③ 每个假设的验证动作（全部只读）

**验证假设 1：用小样本做"有缓存 vs 无缓存"的对照试跑。**
取一天的分区（如 `ais_points/2026-11/` 下的某一天），在同一个 session 里跑两个版本：
- A 版：不 persist，三组特征各自直接从 parquet 计算；
- B 版：和现在一样，先 persist 再 `count()`，然后计算三组特征。

两版都用 `.write.format("noop").mode("overwrite").save()` 收尾，不往任何地方写数据。在 Spark UI 里对比两版的总耗时、各 Job 耗时和 Input Size。如果 A 版总耗时明显更短，就支持假设 1。

**验证假设 2：在 History Server 里对比本周和上周 Job 2 聚合 Stage 的内存指标。**
打开两次运行的同一个 Stage，对比 **Peak Execution Memory** 和 Spill。再看本周运行的 **Executors 页 "Storage Memory" 列**（已用 / 总量）：
- 如果本周 Peak Execution Memory 明显变小，同时 storage 占用较高，就支持"缓存挤占执行内存"；
- 这一页也能顺带解释为什么 40 GB 的缓存只有 10.2 GB 进了内存。
- 如果有节点监控（如 Ganglia/Prometheus 的磁盘指标），可以再看 Job 1 到 3 运行期间本地盘的读写吞吐和利用率，确认是不是本地盘被打满。

**验证假设 3：查看 Job 1 和 Job 3 的执行计划，并对比两周的输入量。**
对 `speed_dist(feat)` 和 `lane_density(feat)` 分别执行 `.explain("formatted")`，搜索 `BatchEvalPython` / `ArrowEvalPython` / `PythonUDF`：
- 没有这些节点，说明 h3 升级不在执行路径上；
- 有的话，再在 Stage 页里看这些 Python 节点的耗时有没有变化。

同时在 History Server 里对比两周扫描 Stage 的 Input Size 和记录数，确认数据量确实只多了约 3%。

## 建议的查看顺序

先做假设 1 的小样本对照，信息量最大，成本也低。再看假设 2 的 Executors 页和 Stage 指标，解释"为什么后面也变慢"。假设 3 最后快速排除即可。三项都看完再决定怎么改，到时可以把结果发我，一起看下一步。
