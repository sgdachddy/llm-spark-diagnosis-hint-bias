你的判断基本对：Stage 3 确实存在严重的数据倾斜。但它很可能不是"今天突然出现"的，今天变慢的直接原因更可能是新模板 `job_template_v3.conf` 把 AQE 关掉了（`spark.sql.adaptive.enabled=false`）。以前 AQE 会在运行时自动拆开倾斜分区，现在这层保护没了。

下面分三部分讲：证据、原因链条、怎么修和怎么验证。

---

## 一、倾斜的证据（很明确）

**1. 400 个 task 里只有 1 个异常**
- Duration：中位数 8 s，最大值 45 min，约 340 倍
- Shuffle Read：中位数 21 MB，最大值 8.4 GB，约 400 倍
- Records：中位数 30 万，最大值 1.2 亿，约 400 倍
- Spill 只出现在 Max 这一列（内存 96 GB、磁盘 38 GB），其余分位全是 0

**2. 慢的只在 executor 7 的一个 task 上**
附 3 里 executor 7 是「45 min ×1 + 16 s ×39」，其他 9 个 executor 都是 16–18 s ×40。所以不是某台机器坏了，而是 task 287 分到的数据太多。

**3. 集群读数正好对得上**
- CPU 整体 12%：300 核里其余任务早就跑完了，剩下一个 task 在单核上排序、spill。
- 网络正常、GC 只占 3%：说明瓶颈不在网络也不在 GC，而是单个分区太大，导致反复 spill 到磁盘（日志里 Thread 112 至少 spill 了 12 次，每次约 4 GB）。

**4. 倾斜 key 就是 join key `h3_r7`**
附 4 显示左表按 `hashpartitioning(h3_r7, 400)` 重分区后做 SortMergeJoin，所以是某一个（或少数几个）`h3_r7` 值的记录量远超其他格子，全被哈希到了 partition 287。

---

## 二、为什么"昨天 5 min，今天 45 min"

输入数据只多了 4%，解释不了 9 倍的变慢。真正变的是配置：

| 配置 | 官方默认（Spark 4.0） | 本次生效 |
|---|---|---|
| `spark.sql.adaptive.enabled` | true | **false** |
| `spark.sql.adaptive.skewJoin.enabled` | true（依赖 AQE） | 实际失效 |

AQE 开启时，`skewJoin` 会在运行时发现这种"远大于中位数"的分区（8.4 GB 对 21 MB，远超默认阈值），把它拆成多个子分区并行 join。这样即使数据本来就倾斜，也只是多几个 task，几分钟就跑完。新模板把 AQE 关了，这个热点分区只能由一个 task 硬扛。

所以更准确的说法是：**数据倾斜一直都在，以前被 AQE 掩盖了；换了模板后 AQE 关闭，倾斜就暴露出来了。**

（这个推断要靠昨天的运行记录确认，见第四部分。）

**另外两个加重因素：**

- **单 task 内存太少。** 每个 executor 64 GB、30 核，统一内存约 (64 GB − 300 MB) × 0.6 ≈ 38 GB，30 个 task 分下来每个只有 1 GB 多一点。8.4 GB 的 shuffle 数据在内存里展开后要大得多，所以疯狂 spill。
- **speculation 在这里帮不上忙，还浪费资源。** 日志里给 task 287 起了一个推测副本（287.1，跑在 executor 3），但副本处理的是同一份 8.4 GB 数据，不会更快，最后被 kill 掉。推测执行只适合"慢节点"，不适合"数据倾斜"。

---

## 三、怎么修（按优先级）

### 1. 立刻止血：在提交参数里把 AQE 打开
```
--conf spark.sql.adaptive.enabled=true
--conf spark.sql.adaptive.skewJoin.enabled=true
```
这样大概率就能回到原来约 15 min 的水平。同时建议跟课题组说一声，v3 模板里的 `adaptive.enabled=false` 可能也在拖慢别人的作业，最好确认一下当初为什么要关它。

### 2. 查清楚热点 key 是什么
```sql
SELECT h3_r7, count(*) AS n
FROM ais_points
WHERE <当天分区>
GROUP BY h3_r7
ORDER BY n DESC
LIMIT 20;
```
重点看：
- **是不是 NULL、0 或某个默认值？** 这是最常见的原因：坐标缺失或解析失败的点被编码成同一个"占位格子"。如果是这样，应该在 join 前过滤掉或单独处理，而不是调参。
- **如果是真实热点**（比如某个大港口、锚地所在的格子），那就是业务上真实的倾斜，需要靠下面的方法处理。

### 3. 考虑把 zone_attr 广播出去
海区属性表按 h3_r7 一个格子一行，通常不会太大。如果它的大小在几十到几百 MB 量级，直接广播可以完全避免 shuffle 和倾斜：
```python
from pyspark.sql.functions import broadcast
ais.join(broadcast(zone_attr), "h3_r7")
```
或者把 `spark.sql.autoBroadcastJoinThreshold` 调大到略高于 zone_attr 的实际大小。注意 executor 内存要放得下它。现在计划里两边都走了 Exchange + Sort，说明优化器估算它超过了默认的 10 MB。

### 4. 如果热点是真实的且 AQE 拆分不够：手动加盐
对热点 key 在左表加随机后缀（如 0–N），右表对应行复制 N 份，join 后再去掉盐。一般有了第 1 步或第 3 步就用不到这一步。

### 5. 顺手调整
- 对这个作业可以关掉 `spark.speculation`，或者至少别指望它解决倾斜。
- 每个 executor 30 核偏多。考虑改成更多、更小的 executor（比如 5 核/个），每个 task 分到的内存更均衡，GC 也更好控制。这不是本次的主因，可以之后再做。

---

## 四、建议你先确认的几件事

1. **昨天那次跑用的是不是旧模板、AQE 是否开启？** 在 Spark History Server 的 Environment 页可以看到。昨天的物理计划顶层如果是 `AdaptiveSparkPlan isFinalPlan=true`，Stage 3 的 task 数也多于 400（倾斜分区被拆开了），就基本坐实了。
2. **昨天的热点格子是不是同一个？** 如果昨天的 Max Shuffle Read 也明显偏大，说明倾斜早就存在；如果昨天很均匀，说明今天的数据本身也有变化（比如某个格子突然多了大量点），需要回到第 2 步查数据源。
3. **改完后重跑，看 Stage 3 的 Summary Metrics**：Max Duration 应该降到和中位数同一量级，Spill 应该接近 0。

如果你方便的话，把热点 key 查询的结果和昨天作业的 Environment / 物理计划贴过来，我可以帮你判断该用哪种方案收尾。
