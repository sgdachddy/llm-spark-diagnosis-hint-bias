## 结论

这是一次典型的 **join key 数据倾斜**，不是资源不够，也不是数据量涨了 4% 导致的。直接原因很可能是新版模板 `job_template_v3.conf` 里写了 **`spark.sql.adaptive.enabled=false`**，把 Spark 4.0 默认开启的 AQE（连同它的倾斜 join 自动拆分）关掉了。于是一个热点 `h3_r7` 格子的数据全部落进同一个 task，这个 task 单独跑了 45 分钟。

---

## 证据

**1. 慢的只有一个 task，其余 399 个都正常**
- Duration：中位数 8 s，75 分位 9 s，**最大值 45 min**。Stage 3 用时 45 min，基本就是这一个 task 的用时。
- Shuffle Read：中位数 21 MB，**最大值 8.4 GB**，约 400 倍。
- Records：中位数 30 万，**最大值 1.2 亿**。粗算一下，399 个正常 task 合计约 1.2 亿条，所以这一个分区装了**整个 stage 约一半的数据**。
- Spill 只出现在这个 task 上（内存 96 GB、磁盘 38 GB）。日志里 task 287.0 反复往磁盘溢写 4 GB 的排序数据（至少 12 次）。

**2. 集群资源基本闲着**
- CPU 整体利用率只有 12%：后面 40 多分钟里，300 个核里大约只有 1 个在干活。
- GC 3%、网络正常，可以排除内存配置、GC 和网络问题。
- 按 executor 汇总看，只有 executor 7 异常，其它 9 个都在 16–18 s × 40 个 task。所以不是某台机器坏了，而是 executor 7 正好分到了那个热点分区。

**3. 执行计划证实了这一点**
- `Exchange hashpartitioning(h3_r7, 400)` + `SortMergeJoin`：相同 `h3_r7` 的行一定会进同一个分区。热点格子没法被拆开，只能由一个 task 先排序（内存放不下就溢写）再做 join。

**4. 配置里关键的一项被改了**
- 附 5：`spark.sql.adaptive.enabled=false`
- 官方默认值：`true`（自 3.2.0 起），并且 `spark.sql.adaptive.skewJoin.enabled=true` 会在 AQE 开启时**自动拆分 sort-merge join 里倾斜的分区**。
- 这个分区（8.4 GB）远远超过 AQE 判定倾斜的条件（默认要求超过中位数 5 倍且超过 256 MB）。如果 AQE 开着，它本来会被自动拆成多个子 task 并行处理。

**5. 推测执行帮不上忙**
- `spark.speculation=true` 在 executor 3 上启动了 287.1，但数据还是同一份 8.4 GB，备份 task 一样慢，最后被杀掉。推测执行只能解决慢节点问题，解决不了数据倾斜。

**6. 数据 +4% 不是原因**
- 4% 的增量解释不了单个 task 从秒级变成 45 分钟。

---

## 建议处理步骤

### 立即修复（改配置就行，不用改代码）
在提交参数里覆盖模板（或者直接修正模板）：
```
spark.sql.adaptive.enabled=true
spark.sql.adaptive.skewJoin.enabled=true
```
可选：倾斜仍未完全消除时，可把判定阈值调低：
```
spark.sql.adaptive.skewJoin.skewedPartitionFactor=5        # 默认 5
spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes=256m  # 默认 256MB
```
AQE 开启后还会自动合并小分区，并且可能在运行时根据实际大小把 join 改成 broadcast，这对本作业也有好处。

重跑之后到 Spark UI 里确认两点：SQL 计划中 SortMergeJoin 带上了 `isSkew=true` / 出现 `AQEShuffleRead`（skewed 标记）；Stage 3 的 Max Duration 回到秒级或分钟级。

### 顺带检查一下：热点格子本身是不是正常数据
一个 r7 格子占了全天约一半的船位点，这不太正常，即便是大港口也很少到这个程度。建议跑一下：
```sql
SELECT h3_r7, count(*) AS n FROM ais_points WHERE <当天分区> GROUP BY h3_r7 ORDER BY n DESC LIMIT 20;
SELECT h3_r7, count(*) AS n FROM zone_attr GROUP BY h3_r7 HAVING n > 1 ORDER BY n DESC LIMIT 20;
```
- 如果 `ais_points` 里的热点是 `0`、`-1` 或者某个固定值（经纬度缺失/为 0 时编码出来的默认格子，比如 (0,0) 附近），说明这是**脏数据**。应该在 Filter 阶段剔除或单独处理，不要拿去 join。
- 如果 `zone_attr` 里同一个 `h3_r7` 有多行，inner join 会把数据成倍放大，需要先去重。
- 如果确实是真实的热点（某个港口或锚地），开 AQE 一般就够了。

### 进一步优化（可选）
- **广播 zone_attr**：海区属性表通常不大。如果它压缩后只有几十到几百 MB，可以用 `broadcast(zone_attr)` hint，或者调大 `spark.sql.autoBroadcastJoinThreshold`。这样就完全没有 shuffle 了，倾斜问题也一起没了。广播前先确认表的大小和 executor 内存是否扛得住。
- **加盐（salting）**：如果因为某些原因必须关闭 AQE，可以给热点 key 加随机后缀，把它拆到多个分区，小表那边对应复制 N 份。
- **推测执行**：对这个作业来说用处不大，反而多占资源，可以考虑关掉。

### 关于模板
建议告诉课题组维护 `job_template_v3.conf` 的同学：模板里硬编码 `spark.sql.adaptive.enabled=false`，会让所有用这个模板的作业失去 AQE 的倾斜处理和分区合并。除非有特别的理由，应该删掉这一行，用回默认值。还有一点要核对：昨天那次运行是不是也用了 v3 模板。如果昨天还是旧模板、今天才换成 v3，那"昨天 5 分钟、今天 45 分钟"的差别就完全对上了。
