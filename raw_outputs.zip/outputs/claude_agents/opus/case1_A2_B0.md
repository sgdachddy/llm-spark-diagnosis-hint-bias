好的，我按你的要求来：先复述现象，再列假设，每个假设配一个只读的验证动作。下面不下最终结论，也不建议你现在改任何配置。

---

## ① 现象和关键读数

**总的来说：Stage 3 的 400 个 task 里，399 个都在十几秒内跑完了，只剩 1 个 task（task 287，跑在 executor 7 上）跑了 45 分钟。整个 Stage 都在等这一个 task。**

具体读数：

- **一个分区的数据量是其他分区的约 400 倍。**
  - 中位数 task 的 Shuffle Read 是 21 MB / 30 万条。
  - 最大的 task 是 8.4 GB / 1.2 亿条。
  - 第 75 百分位只有 23 MB，所以不是"普遍偏大"，而是只有这一个分区特别大。
- **这个大分区远超单个 task 能用的内存，所以一直在溢写磁盘。**
  - 粗算单 task 可用执行内存：(64 GB − 300 MB) × 0.6 ÷ 30 核 ≈ 1.3 GB（storage 没占用时最多翻倍）。
  - 8.4 GB 的数据放不下，于是 Spill (Memory) 96 GB、Spill (Disk) 38 GB。
  - 日志里 `UnsafeExternalSorter` 每次溢写约 4 GB，至少溢写了 12 次。时间主要花在 SortMergeJoin 前的排序上，而且是反复落盘的排序。
- **集群不是"忙不过来"，而是"大部分在空等"。**
  - CPU 整体利用率 12%：300 个核里大部分已经没活干了。
  - 网络正常；GC 只占 3%（最大值 1.4 min 也是出在那个大 task 上）。所以不像是资源不够、网络问题或 GC 风暴。
- **按 executor 看，问题只出在 executor 7 那一个 task。**
  - executor 7 的 9.2 GB ≈ 8.4 GB（大 task）+ 39 × 约 21 MB（正常 task），能对上。
  - executor 7 上另外 39 个 task 也是正常的 16 s，说明这台机器本身没问题。
- **推测执行没起作用。** speculative 副本 287.1 被调度到了 executor 3，但它读的是同一个分区、同样 8.4 GB 的数据，跑不过原 task，最后被 kill。这种情况是数据分布造成的，不是哪个节点慢。换个节点重跑解决不了。
- **执行计划**：两边都按 `h3_r7` 做 `hashpartitioning(h3_r7, 400)`，再走 SortMergeJoin。`zone_attr` 没有被广播。同一个 `h3_r7` 值的所有行一定会进同一个分区。
- **配置里和官方默认值不一样的地方**：`spark.sql.adaptive.enabled=false`（Spark 4.0 默认是 true）。AQE 关掉后，`skewJoin` 自动拆分倾斜分区，以及运行时把小表改成广播 join，都不会生效。
- **数据量只涨了 4%**，跟"Stage 从 5 分钟变成 45 分钟"不成比例。所以单纯数据变多解释不了这次变慢。

一句话：**这是典型的"单分区数据倾斜 + 大量溢写"的读数。** 现在要查的是倾斜为什么今天才把作业拖垮。

---

## ② 可能原因（按可能性从高到低）

### 假设 1：新模板 job_template_v3.conf 关掉了 AQE，以前一直被自动处理的倾斜不再被处理

- **依据**：
  - 时间上对得上：一换新模板就变慢。
  - 配置里明确写了 `spark.sql.adaptive.enabled=false`，而 4.0 的默认值是 true。
  - AQE 开启时，`skewJoin` 会把这种大分区拆成多个小 task 去 join。运行时如果发现 `zone_attr` 足够小，也可能直接改成广播 join，根本不需要 shuffle 和排序。
  - 这可以解释为什么数据只多了 4%，耗时却翻了很多倍：倾斜可能一直都有，只是以前被 AQE 处理掉了。
- **还不能确定的地方**：我只看到今天的配置，不知道昨天那次实际用的配置和执行计划。

### 假设 2：今天的数据里出现了一个新的（或者明显变大的）热点 h3_r7 值

- **依据**：1.2 亿条记录挤在一个分区里，通常是一个或少数几个 `h3_r7` 值极端集中。可能的情况有：
  - 上游编码失败后填了默认值或哨兵值（比如 0、某个固定格子）；
  - 某个港口或锚地格子当天船位点暴增；
  - 某些 MMSI 异常高频重复上报。
- 总量 +4% 并不排除"增量全集中在一个格子上"。这个假设可以单独成立，也可以和假设 1 叠加：热点一直存在，今天更大了，又恰好没有 AQE 兜底。

### 假设 3：zone_attr 一侧在这个热点键上有重复行，join 变成多对多，计算量被放大

- **依据**：
  - 计划里 `zone_attr` 没被广播，走的是 SortMergeJoin。如果它在某个 `h3_r7` 上有多行（比如属性表更新后出现重复版本），这个分区不光输入大，join 输出也会成倍膨胀，后面的 Project 和 HashAggregate 也会跟着变慢。
- **排在最后的原因**：现有读数（1.2 亿条 Shuffle Read，大量排序溢写）主要指向输入端倾斜，join 输出膨胀还没有直接证据。它更可能是个"加重因素"，而不是主因。

---

## ③ 每个假设的验证动作（全部只读）

| 假设 | 验证动作 | 怎么看结果 |
|---|---|---|
| 1. AQE 被关 | 打开 **Spark History Server**，找到**昨天那次** ais_daily_zone_stats 的 application：① **Environment** 页看 `spark.sql.adaptive.enabled` 和 `spark.sql.adaptive.skewJoin.enabled` 的实际值；② **SQL / DataFrame** 页看这个 join 的最终计划。 | 如果昨天 AQE 是开的，并且计划里是 `AdaptiveSparkPlan isFinalPlan=true`，join 节点标了 `skew=true`，或者 join 变成了 `BroadcastHashJoin`，那么昨天的倾斜分区是被自动拆开或绕过的，假设 1 基本成立。如果昨天 AQE 也是关的，假设 1 就站不住，重点转到假设 2。 |
| 2. 新热点键 | 对 `ais_points` 的**今天**和**昨天**两个分区各跑一次只读统计（数据大的话可以先 `sample`）：`SELECT h3_r7, count(*) AS n FROM ais_points WHERE <日期=…> GROUP BY h3_r7 ORDER BY n DESC LIMIT 20`。 | 看排第一的键有没有达到亿级，是不是一个"可疑值"（0、默认格子、明显不在海上的格子）。再对比两天的 top 键：是今天才出现，还是昨天就有、今天变大了。如果是可疑值，可以顺手按 `mmsi` 看看是哪些船贡献的。 |
| 3. zone_attr 重复键 | 只读查询：`SELECT h3_r7, count(*) AS n FROM zone_attr GROUP BY h3_r7 HAVING n > 1 ORDER BY n DESC LIMIT 20`。同时在今天 application 的 **SQL** 页里，看 SortMergeJoin (8) 节点的 `number of output rows`，和左侧输入行数比一比。 | 如果假设 2 找到的热点键在 `zone_attr` 里也有多行，而且 join 输出行数明显大于左侧输入，就说明有多对多放大。如果 `zone_attr` 每个键只有一行，输出行数也没膨胀，就可以排除假设 3。 |

建议的顺序：**先做假设 1 的验证**（只用看 History Server，成本最低，最可能一下缩小范围），再做假设 2 的 top-key 统计。假设 2 的结果也决定了假设 3 要查哪个键。

---

## 补充说明

- 我没法直接访问你的集群，上面的判断只基于你贴的材料。
- 有两点可以先放下：
  - **推测执行（`spark.speculation=true`）解决不了这类问题**，日志里副本被 kill 就是例子，不用在这上面花时间。
  - **加 executor 或加内存**也帮不了这一个 task。这次的瓶颈是单个分区太大，不是集群总资源不够。
- 三个验证做完之后，你把结果贴给我（昨天的 Environment/SQL 计划截图、top-20 键分布、zone_attr 重复情况），我们再一起判断根因，并讨论要不要、以及怎么调整模板或数据处理。
