## ① 现象和关键读数

**现象**：作业没有报错，但耗时从约 18 min 变成约 31 min，多了约 13 min（+72%）。本周有三处改动：给 `feat` 加了 `persist`、h3 库升级了一个小版本、数据量多了 3%。

**多出来的 13 min 分布在哪里**（附 3）：
- **Job 0（`feat.count()` 物化缓存）是本周新增的，用了 9.5 min**，占增量的大头。
- Job 1–3 加了缓存，本来应该变快，实际**三个都变慢了**，合计 21.5 min，上周是 17.9 min，多了约 3.6 min。
- 上周每个 Job 都要自己扫一遍 parquet，也只用 6 min 左右。也就是说，扫 parquet 原本不算贵，从目前数据看缓存没有省下时间。

**资源读数**（附 1）：
- CPU 利用率只有 34%，不像是算力不够。
- **磁盘 IO wait 28%，上周约 5%**，涨了 5 倍多，是变化最大的读数。
- GC 占 6%，不算高。

**缓存状态**（附 2）：
- `feat` 全部 320 个分区都缓存了，但**只有 10.2 GB 在内存里，29.8 GB 落到了磁盘**，大约 3/4 在磁盘上。
- 这一点和配置对不上，需要核实。按默认参数估算，每个 executor 的统一内存约为 (24 GB − 300 MB) × 0.6 ≈ 14 GB，10 个合计约 140 GB；其中 storage 受保护、不会被驱逐的部分约 70 GB。40 GB 的缓存理论上应该大部分放得进内存，实际却大量落盘。

**聚合 Stage**（附 4，Job 2）：
- **上周 Spill 全为 0，本周每个 task 都有溢写**：内存侧中位数 1.0 GB，磁盘侧中位数 0.35 GB。可每个 task 的 shuffle read 只有约 100 MB。
- 各 task 的读量（92–121 MB）和耗时（58 s – 1.9 min）都很均匀，**看不出数据倾斜**。

**执行计划**（附 5）：
- Job 2 读的是 `InMemoryTableScan`，没有在读 parquet。
- 计划里只有 HashAggregate → Exchange → HashAggregate，**没有 Join**，也**没有 Python UDF 节点**（BatchEvalPython / ArrowEvalPython）。
- 所以说明书里列的 `skewJoin`、`autoBroadcastJoinThreshold` 这两项默认值和这个 Stage 关系不大。

---

## ② 可能的原因假设（按可能性从高到低）

### 假设 1（可能性最高）：persist 本身的开销没被摊回来，而且缓存大部分落在磁盘上
- 物化缓存多花了 9.5 min（Job 0）。
- 后续 3 个 Job 读缓存时，约 30 GB 要从本地磁盘读回来，而且读了 3 遍。
- 这可能比上周直接扫 parquet 还慢：上周扫 parquet 时有列裁剪和谓词下推。
- 磁盘读还会和 shuffle 写、spill 争抢同一块本地盘，这和 IO wait 从 5% 涨到 28% 的现象一致。

### 假设 2：缓存占用了 executor 内存，聚合可用的 execution 内存变少，导致 spill
- 上周没有缓存，统一内存基本都能给聚合用。本周有一部分被 storage 占了，每个 executor 上 8 个并发 task 分到的执行内存可能变少，聚合开始溢写。
- 证据：只读约 100 MB 的 task 就溢写了约 1 GB（内存侧）。上周同一 Stage 溢写为 0。
- 溢写也会增加磁盘 IO，可以解释 Job 1–3 各慢了 1–2 min。
- 数据量 +3% 单独解释不了 +72% 的耗时，但如果上周的内存已经接近临界点，它可能是叠加因素之一。
- 附 2 里"内存明明够、缓存却大量落盘"的矛盾，也说明实际可用内存可能比按配置估算的少，需要核实。

### 假设 3（可能性较低）：h3 库升级让某个 Job 里的 Python 逻辑变慢
- 代码注释说 `h3_r7` 由上游预先算好，Job 2 的计划里也没有 Python UDF 节点。
- 而且 Job 1–3 都只慢了相近的 1–2 min，不像是某一个 Job 单独出了问题。
- 再加上 CPU 利用率只有 34%，这条可能性偏低。但 `lane_density` 或 `speed_dist` 里是否调用了 h3 还没确认，暂时保留。

---

## ③ 每个假设对应的验证动作（都是只读操作）

**验证假设 1**：在 Spark UI 的 Storage 页点开 `feat`，看每个分区存在哪个 executor、是在 Memory 还是 Disk 上。再把 Job 1–3 第一个 Stage（InMemoryTableScan + 局部聚合）的 task 耗时分布和上周对应 Stage（读 parquet 的那个）对比。
- 如果主要是这个读取 Stage 变慢了，而且慢的 task 集中在缓存分区落盘的 executor 上，就支持假设 1。

**验证假设 2**：在 Job 2 聚合 Stage 运行期间（或者用事件日志回放），看 Executors 页每个 executor 的 "Storage Memory" 已用 / 总量。同时在 Stage 页打开 "Peak Execution Memory" 这一列，和上周同一 Stage 对比。
- 如果 storage 已用量明显，而且本周 Peak Execution Memory 明显低于上周、开始碰到上限，就支持假设 2。
- 同时可以核实总量是否真的约 14 GB/executor，用来解释附 2 里的矛盾。

**验证假设 3**：对 Job 1 和 Job 3（`speed_dist`、`lane_density`）也跑一次 `EXPLAIN FORMATTED`，检查有没有 `BatchEvalPython` / `ArrowEvalPython` 节点。再用 `pip show h3` 对比新旧版本，并翻一下 executor 日志里有没有 Python worker 相关的警告。
- 如果没有 Python 节点，h3 升级基本可以排除。

---

如果上面三项看完还拿不准，可以加一个小样本试跑作为补充：用一天的数据，在你自己的会话里分别跑"带 persist"和"不带 persist"两个版本，对比总耗时和 spill。这样不会动集群配置。

目前这些都还是假设。等你把上面的读数发给我，我们再一起判断。
