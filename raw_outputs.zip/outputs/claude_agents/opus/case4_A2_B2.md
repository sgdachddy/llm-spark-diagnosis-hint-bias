我按你的四条要求来整理。先说一句：从材料看，"内存不够"是很有分量的候选，但我不会直接下结论，下面把它和另外两个假设并排放着，每个都配一个只读的验证动作。

---

## ① 用人话复述现象和关键读数

**现象**
- `ais_track_segments` 本周从约 20 min 变成约 58 min，偶尔有 executor 被 YARN 杀掉，task 要重跑。
- 本周同时有三处变化：executor 内存从 16g 降到 4g；输入换成新的按天分区目录（内容据说不变）；数据量多 2%。

**关键读数，以及它们之间能不能对上**

| 读数 | 含义 |
|---|---|
| Stage 2 task 中位耗时 3.4 min，上周 1.1 min | 单个 task 慢了约 3 倍 |
| 600 个 task × 3.4 min ÷ 64 个并发槽（16×4）≈ 32 min | 光 Stage 2 就占了总时长的一大块；上周算下来约 10 min，和 20 min → 58 min 的变化量级对得上 |
| 每个 executor Task Time 约 2.3 h × 16 ≈ 37 h，600 × 3.4 min ≈ 34 h | 两张表的数据自洽 |
| GC 中位 39 s / 3.4 min ≈ 19% | 和集群整体"GC 占 19%（上周 3%）"一致 |
| 每个 task 都有 spill：内存侧 1.1–1.7 GB，磁盘 0.4–0.7 GB；上周 spill 全是 0 | 排序阶段内存放不下，要反复溢写到磁盘再归并 |
| Shuffle Read 168–197 MB，Records 190–221 万，最大值只比中位高约 9% | **各分区很均匀，没有明显的数据倾斜** |
| 日志：`spilling sort data ... (7 times / 9 times so far)`、`Failed to allocate a page (64MB)` | 单个 task 能拿到的执行内存很紧，每个 task 要溢写很多次 |
| `4.9 GB of 4.8 GB physical memory used` | 4.8 GB 正好等于 4g 堆 + 800m overhead，容器总物理内存超限被 YARN 杀掉 |
| CPU 83%，网络正常 | CPU 很忙，但其中有相当一部分可能花在 GC 和序列化/溢写上，不代表在做有用计算 |

粗算一下：4g 堆、`memory.fraction=0.6` 时，统一内存约为 (4096 − 300) MB × 0.6 ≈ 2.2 GB，4 个并发 task 分摊下来，每个 task 最多约 550 MB 执行内存。而每个 task 的数据在内存中展开后约有 1.4 GB（看 Spill (Memory)）。按旧的 16g，这个数大约是 2.3 GB / task。这只是量级估算，作为方向参考。

---

## ② 可能的原因假设（不超过 3 个，按可能性从高到低）

### 假设 1：堆内存降到 4g 后，每个 task 的执行内存放不下排序数据 → 大量 spill 和 GC → 每个 task 变慢
- 支持的证据：spill 在上周为 0、本周所有 task 都有，而且很均匀；GC 从 3% 涨到 19%；日志里反复溢写、页面申请失败；时间点正好和内存调整同周；分区均匀说明问题不在个别大分区，而是"所有分区都装不下"。
- 还没确认的部分：缺少上周同一 Stage 每个 task 的实际峰值内存用量，没法证明"16g 刚好够、4g 不够"。

### 假设 2：容器的堆外部分（memoryOverhead = 800m）不够，导致 executor 被 YARN 杀掉、task 重跑，额外拉长了总时长
- 支持的证据：`4.9 GB of 4.8 GB` 明确是物理内存超限，不是 JVM OOM。频繁 spill 会多用堆外内存（shuffle/netty 缓冲、溢写文件读写、parquet 解码等），所以这个假设和假设 1 可能是同一个改动带来的两个不同后果。
- 为什么排第二：被杀的只是偶发（附 3 只看到 executor 3 一次），而慢是所有 task 普遍都慢，主体更像假设 1；被杀和重跑是在这之上叠加的损耗。

### 假设 3：新分区目录让扫描和过滤的行为变了（比如分区裁剪失效、读入了比预期更多的数据或更多小文件），进入 shuffle 的数据量不只多了 2%
- 支持的依据：目录结构变化和变慢是同一周发生的；"数据内容不变、+2%"是对源数据的描述，不一定等于这个作业实际读进来的量。Filter 是放在 Scan 上面的单独节点，需要确认它有没有被下推成分区过滤。
- 为什么排最后：Shuffle Read 每个 task 只有约 180 MB、约 200 万行，看不出数据量明显暴涨；而且光是内存缩小到原来的 1/4，就已经足以解释 spill。

**我暂时不建议往这些方向投入精力**：
- 数据倾斜：分区分布非常均匀。另外，版本说明里的 `skewJoin` 只处理 join 中的倾斜，而这个计划里没有 join，只有 Exchange → Sort → Window，所以这项配置与本问题无关。
- 广播阈值（`autoBroadcastJoinThreshold`）：同理，计划里没有 join，不相关。

---

## ③ 每个假设的只读验证动作

**假设 1 → 在 Spark History Server 对比上周和本周同一作业的 Stage 2**
- 先在 Environment 页确认上周生效的 `spark.executor.memory` 确实是 16g；
- 再对比 Stage 2 Summary Metrics 里的 **Peak Execution Memory**（每个 task 的峰值执行内存）。
- 怎么看结果：如果上周 task 峰值明显高于约 550 MB（上面估出的本周单 task 上限），而且上周没有 spill，就支持假设 1。如果上周峰值本来就很低，就要转而怀疑本周单个 task 的数据形态变了（回到假设 3）。

**假设 2 → 查看被杀 executor 被杀前的内存构成，并统计被杀次数**
- 在 History Server 的 Executors 页（或 event log 里的 executor metrics），看 executor 3 的 `JVMHeapMemory`、`JVMOffHeapMemory`、`DirectPoolMemory`、`MappedPoolMemory` 峰值；
- 在 NodeManager 日志里 grep `exceeding physical memory limits`，统计本周所有被杀容器的数量，以及因此重跑的 task 数和耗时。
- 怎么看结果：如果堆本身没到 4g，但堆外/直接内存加起来超过 800m，就支持"overhead 不够"；如果被杀和重跑耗时只占总时长的一小部分，说明它是次要因素。

**假设 3 → 看完整执行计划里扫描节点的细节，并对比上周的读入量**
- 打开 `EXPLAIN FORMATTED` 中节点 (1) `Scan parquet ais_points` 的完整信息，看 `PartitionFilters` 是否包含按天的分区条件（而不是只出现在 (2) Filter 里），以及 `Location` 指向的目录是否只是当天；
- 在 SQL 页对比上周和本周 Scan 节点的 **number of files read、size of files read、number of output rows**，以及 Stage 2 的总 Shuffle Read Records。
- 怎么看结果：如果本周读入的文件数、字节数或行数明显多于上周的 1.02 倍，或者分区过滤没有生效，就支持假设 3。

---

## ④ 说明

- 以上都是只读操作，我没有建议你修改集群或作业配置。
- 三个假设之间不互斥。尤其是假设 1 和假设 2 很可能由同一处改动（内存模板从 16g 降到 4g）引起。建议按 1 → 2 → 3 的顺序验证，拿到读数后再判断原因，以及要不要和运维讨论模板的调整。
- 如果你方便把上周那次运行的 Stage 2 Summary Metrics（尤其是 Peak Execution Memory）和 Scan 节点的指标贴过来，我可以帮你一起对照判断。
