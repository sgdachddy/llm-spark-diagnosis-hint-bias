你看到的 OOM 是真实存在的。不过从这些材料看，内存未必是根因，更像是"一张不该被广播的大表被广播了"。下面按你的要求，先复述现象，再列假设。目前都还是假设，需要验证。

---

## ① 现象和关键读数

**发生了什么**
- 作业 `ais_port_events` 昨天正常跑完，大约 12 分钟。今天在 Stage 4（join 阶段）失败：Task 37 连续失败 4 次，executor 一个接一个退出，作业因此终止。
- 两天之间只有一个变化：维表从 `zone_attr` 换成了上游昨晚 23:41 新生成的 `zone_attr_v2`。作业代码没有动。

**报错栈说明了什么（附 1、附 3）**
- OOM 发生在 `BroadcastExchangeExec → HashedRelationBroadcastMode.transform → UnsafeHashedRelation.apply`，也就是**构建广播哈希表**的时候，不在普通的 shuffle 或聚合里。
- 物理计划印证了这一点：`BroadcastHashJoin Inner BuildRight`，被广播的一侧（build side）是 `zone_attr_v2`。

**最值得注意的一组数字：大小对不上（附 4、5、6、7）**
| 来源 | zone_attr_v2 的大小 |
|---|---|
| 优化器估算（EXPLAIN COST） | **8.2 MiB** |
| S3 实际文件（6 个对象） | **1.8 GiB**（parquet 压缩后的大小，解压进内存后通常还会更大） |
| 广播阈值 | 10 MB |

- 优化器以为这张表只有 8.2 MiB，低于 10 MB 的阈值，所以选了广播。实际大小约是估算值的 **225 倍**。
- 还有一处矛盾：`DESCRIBE TABLE EXTENDED` 里**没有 Statistics 行**，可 EXPLAIN COST 给出了 8.2 MiB。这个估算从哪来，目前说不清楚，后面需要查。

**Stage 4 已完成的 61 个 task（附 2）**
- 每个 task 的输入很均匀，在 118–131 MB 之间，耗时 41 s 到 1.2 min，**没有明显的数据倾斜**。
- Spill 全部为 0。
- GC 时间偏高：中位数 14 s，占 task 耗时（52 s）的四分之一以上。说明堆内存确实很紧张，和"每个 executor 都装着一份很大的广播表"的情况吻合。
- 另外，`skewJoin` 自动拆分只对 sort-merge 和 shuffled hash join 生效，对 broadcast join 不起作用，所以这次 AQE 也帮不上忙。

---

## ② 可能的原因假设（按可能性从高到低）

### 假设 1：zone_attr_v2 的大小估算严重偏小，导致 1.8 GiB 的表被当成小表广播（可能性最高）
新表可能带着不准确的统计信息，例如上游脚本写入时留下的表属性，或者先写了小数据再覆盖。优化器据此误判成 8.2 MiB 并选择广播。广播表在 driver 和每个 executor 上都要完整构建一份哈希表，16 GB 的堆扣掉执行内存后放不下，于是 OOM。
如果是这种情况，单纯加内存可能只是暂时掩盖问题。

### 假设 2：zone_attr_v2 的内容和旧表不同，行数膨胀、出现重复 zone_id，或某些列特别宽
新表由新脚本生成。可能 `zone_id` 不再唯一（同一个港区出现多行，join 结果会成倍放大），也可能 `geom_wkt`、`attrs` 这类列变得很大，比如几何精度更高、属性更多。这会同时加重广播和下游 join 的内存压力。这个假设和假设 1 可以同时成立。

### 假设 3：与维表无关，是 executor 的内存余量本来就不够（可能性最低）
例如今天 `ais_points` 的数据量明显增长，原来就偏紧的内存被压垮了。从现有读数看，这个假设的支持比较弱：各 task 输入均匀、没有 spill，报错栈也明确指向广播构建。但在排除之前，还不宜完全放弃它。

---

## ③ 每个假设对应的验证动作（都是只读操作）

**验证假设 1：查清 8.2 MiB 这个估算的来源，再和广播的实际大小对比**
- 执行 `SHOW TBLPROPERTIES ocean.zone_attr_v2;`，看里面有没有 `spark.sql.statistics.totalSize`、`numRows` 之类的属性，以及数值是不是约 8.2 MiB。（`DESCRIBE` 的输出是节选，统计信息有可能存在表属性里，只是没显示出来。）
- 同时到 Spark History Server → 失败作业的 **SQL / DataFrame 标签页** → 找到 `BroadcastExchange (4)` 节点，看 "data size" 和 "number of output rows" 的实际值，与 8.2 MiB 对比。
- 判断标准：如果表属性里的旧值约为 8.2 MiB，而 BroadcastExchange 的实际数据量达到 GB 级，假设 1 基本成立。

**验证假设 2：比较新旧维表的形状**
- 跑一条只读查询，新旧两张表各跑一次：
  ```sql
  SELECT COUNT(*)                     AS n_rows,
         COUNT(DISTINCT zone_id)      AS n_zone,
         AVG(LENGTH(geom_wkt))        AS avg_geom_len,
         MAX(LENGTH(geom_wkt))        AS max_geom_len
  FROM ocean.zone_attr_v2;   -- 再对 ocean.zone_attr 跑一次
  ```
- 判断标准：如果 `n_rows` 明显大于 `n_zone`（zone_id 有重复），或者行数、几何字段长度比旧表大出一个数量级，假设 2 成立。

**验证假设 3：比较今天和昨天作业的输入量与内存指标**
- 在 History Server 里打开昨天那次成功的运行，对比 Stage 4 的 Input Size 总量、task 数、GC Time 中位数，以及 Executors 页面上的峰值内存。
- 判断标准：如果 `ais_points` 一侧的输入总量和昨天差不多（比如增长不到 20%），只有 build side 的大小变了，假设 3 基本可以排除。

---

**说明**：上面三个动作都不会修改集群、表或配置。建议先做假设 1 的验证，它最快，也最能区分"内存真的不够"和"计划选错了"这两种情况。拿到结果后，我们再一起看下一步怎么处理。
