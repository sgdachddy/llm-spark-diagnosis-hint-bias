先说结论：**很可能是 zone_attr_v2 被优化器错估成"小表"(8.2 MiB)，按广播 join 处理。可它实际在存储上有 1.8 GiB，构建广播哈希表时把 executor 堆内存撑爆了。**这不是数据倾斜，也不是 executor 内存配得太小。

## 证据链

1. **OOM 出在构建广播表的环节，不在 join 计算本身。**
   栈顶依次是 `UnsafeHashedRelation$.apply` → `HashedRelationBroadcastMode.transform` → `BroadcastExchangeExec`。这一段做的事是把右表整张读进内存，建成哈希表后广播出去。

2. **执行计划确实选了广播。**
   附 3 里是 `BroadcastHashJoin Inner BuildRight`，被广播的一侧(build side)是 `zone_attr_v2`。

3. **优化器估计的大小和实际大小差了两百多倍。**
   - 附 4：优化器估算 `sizeInBytes=8.2 MiB`，小于 `autoBroadcastJoinThreshold=10MB`，所以按规则会走广播。
   - 附 6：目录实际有 **1.8 GiB**(6 个对象)，而且这是压缩后的 Parquet。读进内存解压、反序列化，尤其 `geom_wkt` 这种大字符串列，再加上哈希表本身的开销，内存占用通常会是文件大小的好几倍。
   - 附 5：表上**没有 Statistics**。这张表是昨天新生成的，没有跑过 `ANALYZE`，所以 8.2 MiB 不是来自可靠统计，来源本身就可疑(见下面"需要确认的点"第 1 条)。

4. **和"昨天正常、今天失败、代码没改"对得上。**
   唯一的变量是把 zone_attr 换成了 zone_attr_v2。旧表很可能确实是小表，广播没问题；新表实际变大了，估算却仍然落在阈值以下。

5. **排除数据倾斜。**
   附 2 里 61 个已完成 task 的 Input Size 是 118–131 MB，Duration 是 41 s–1.2 min，分布很均匀，没有长尾 task。另外 `skewJoin.enabled` 只对 sort-merge join 和 shuffled hash join 生效，管不到广播 join，所以这里帮不上忙，也不是问题所在。
   GC Time 中位数 14 s，占 task 时长约 27%，偏高，说明堆内存已经很紧张，这和"大广播表常驻内存"是一致的。

6. **为什么加内存不是正解。**
   16 GB 的 executor，扣掉 300 MB 预留后，按 `memory.fraction=0.6` 算，execution 加 storage 一共约 9.4 GB，同时还要分给 8 个并发 task。一张 1.8 GiB 压缩数据展开后的哈希表，很可能放不下，就算勉强放下也会让 GC 很重。driver 端同样要先收集这张表。

## 建议的处理步骤

### 立即止血(让今天的作业先跑通)

二选一即可：

- **只针对这个 join 关掉广播**(推荐，影响面最小)，在 SQL 里加 hint：
  ```sql
  SELECT /*+ MERGE(z) */ ...
  FROM ais_points p JOIN ocean.zone_attr_v2 z ON p.zone_id = z.zone_id
  ```
  DataFrame 写法：`ais.join(zone.hint("merge"), "zone_id")`。
- **作业级关闭自动广播**：`--conf spark.sql.autoBroadcastJoinThreshold=-1`。

这样会改走 sort-merge join，按 zone_id shuffle 后分区处理，不需要把整张表塞进单个 executor。AQE 开着，如果运行时发现某一侧真的很小，还是可以动态转成广播。

### 修正统计信息(根治错估)

```sql
ANALYZE TABLE ocean.zone_attr_v2 COMPUTE STATISTICS;
-- 可选：给 join 键补列统计
ANALYZE TABLE ocean.zone_attr_v2 COMPUTE STATISTICS FOR COLUMNS zone_id;
```

跑完再看 `DESCRIBE TABLE EXTENDED` 里有没有 Statistics 行，再跑一次 `EXPLAIN COST`，确认估算已经接近真实值、计划不再是 BroadcastHashJoin。建议让上游脚本以后每次生成表之后都自动执行 ANALYZE。

## 需要确认的点(很重要，可能另有问题)

1. **8.2 MiB 是怎么来的？**
   正常情况下，没有统计信息的 Parquet 表，Spark 会按文件总大小去估算，不太会离 1.8 GiB 这么远。建议核对：
   - 是否存在会话里缓存的旧元数据或文件列表。可以先 `REFRESH TABLE ocean.zone_attr_v2` 再看 `EXPLAIN COST`。
   - 6 个对象里是否混入了**不属于表数据的文件**，比如 `_temporary`、上游失败重跑留下的重复文件、旧版本残留。可以用 `aws s3 ls --recursive` 看每个文件的路径和大小。
2. **zone_attr_v2 本身合不合理？**
   港区属性表到 1.8 GiB 偏大。请和旧表 zone_attr 对比行数、`count(DISTINCT zone_id)` 和文件大小：
   - 如果 **zone_id 有重复**，即使改成 sort-merge join 能跑完，join 结果也会膨胀，进出港事件会被**重复计数**。这是比 OOM 更隐蔽的结果错误。
   - 如果 `geom_wkt` 精度或顶点数比旧表多很多，要确认这是不是上游有意的改动。
3. **对比计划**：如果方便，可以拿昨天的作业(用旧 zone_attr)的 EXPLAIN 对比一下，确认昨天也是广播，只是表小。

## 建议优先级

1. 加 `MERGE` hint 或者把阈值设为 `-1`，先恢复作业。
2. 核对 zone_attr_v2 的行数和 zone_id 唯一性，以及目录里有没有杂文件，防止结果出错。
3. 执行 `ANALYZE TABLE`，并把它加进上游建表流程。

如果你能贴一下 `SELECT count(*), count(DISTINCT zone_id) FROM ocean.zone_attr_v2`(和旧表各一份)，以及 `aws s3 ls --recursive` 的逐文件列表，我可以帮你进一步判断 1.8 GiB 是数据本身就这么大，还是目录有问题。
