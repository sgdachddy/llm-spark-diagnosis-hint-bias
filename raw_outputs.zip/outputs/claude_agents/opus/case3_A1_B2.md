你的判断大方向是对的：**zone_attr_v2 被当成小表广播了，但它实际上并不小**，这基本就是这次 OOM 的原因。不过材料里有一处对不上的地方，我建议先确认清楚再改配置，不然可能只解决了一半。

## 一、能确定的部分

**1. 它确实走了广播**
- 附 3 的物理计划是 `BroadcastHashJoin Inner BuildRight`，build 端是 `BroadcastExchange ← Scan parquet zone_attr_v2`。
- 附 1 的 OOM 栈落在 `BroadcastExchangeExec → HashedRelationBroadcastMode.transform → UnsafeHashedRelation.apply`，也就是正在把被广播的表构建成哈希表时内存不够。
- 附 2 中 Spill(Disk) 全是 0。这和广播哈希 join 吻合：build 端的哈希表必须整个放进内存，放不下也不会溢写，只会直接 OOM。

**2. 优化器用的大小估计严重偏小**
- 附 4：优化器估算 `sizeInBytes=8.2 MiB`，低于阈值 `autoBroadcastJoinThreshold=10MB`，所以选了广播。
- 附 6：存储上的实际数据是 **1.8 GiB**（6 个对象，平均每个约 300 MB），而且这还是压缩后的 Parquet。有 `geom_wkt` 这种 WKT 几何字符串列，解压并构建成 `UnsafeHashedRelation` 后，内存占用通常会是磁盘大小的好几倍。
- 每个 executor 16 GB，统一内存大约是 (16 GB − 300 MB) × 0.6 ≈ 9.4 GB。driver 侧构建一份、每个 executor 再各持有一份，几 GB 甚至十几 GB 的哈希表肯定装不下。

**3. 不是数据倾斜**
- 已完成的 61 个 task 的 Input Size 分布在 118–131 MB，非常均匀，Duration 也比较集中。这不像倾斜。
- 另外，`spark.sql.adaptive.skewJoin.enabled` 只对 sort-merge join 和 shuffled hash join 生效，**管不了广播 join**。
- AQE 在这里也帮不上忙。广播 exchange 本身就是一个要先物化的 query stage，在 AQE 拿到运行时统计、能重新规划之前，它就已经因为构建这张表而 OOM 了。
- GC Time 中位数 14 s，占 Duration 中位数 52 s 的约 27%，说明 executor 已经处在明显的内存压力下。

## 二、对不上的地方（建议先查清）

**8.2 MiB 这个估计值是从哪来的？** 附 5 显示这张表**没有 Statistics 行**，也就是没跑过 ANALYZE。这种情况下，Spark 对 Parquet 数据源表一般会用文件索引里的文件总大小来估算，按理应该接近 1.8 GiB，而不是 8.2 MiB。几种可能：

1. **EXPLAIN 不是在作业失败那一刻的状态下跑的。** 表是昨天 23:41 创建的，上游脚本可能分几步写入，或者先写了个小版本再覆盖。会话里缓存的文件列表可能还是旧的，需要 `REFRESH TABLE`。
2. **S3 目录下有不属于这张表的文件。** 比如上游脚本留下的临时目录、旧版本数据或未注册的子目录。这些会被 `aws s3 ls --recursive` 统计进去，Spark 却不一定读。这时 1.8 GiB 未必是真实的读取量，OOM 可能另有原因。
3. 脱敏或节选过程中数字被混在了一起。

另外，附 1 的 Reason 写的是 `Executor heartbeat timed out / java.lang.OutOfMemoryError`，把两种原因合在了一行。`BroadcastExchangeExec` 构建 relation 通常在 **driver** 上执行，但失败信息又指向 executor 9。建议把 **executor 9 的 stderr 日志**和 **driver 日志**分开看，确认 OOM 到底发生在哪一端。这会影响调参方向：如果是 driver OOM，还需要关注 `spark.driver.memory`。

**建议跑这几条命令确认：**

```sql
REFRESH TABLE ocean.zone_attr_v2;
ANALYZE TABLE ocean.zone_attr_v2 COMPUTE STATISTICS;
DESCRIBE TABLE EXTENDED ocean.zone_attr_v2;      -- 看现在的 Statistics

SELECT count(*), count(DISTINCT zone_id) FROM ocean.zone_attr_v2;   -- 见下文第 4 条
```
```bash
aws s3 ls s3://<bucket>/warehouse/ocean.db/zone_attr_v2/ --recursive --human-readable   # 看 6 个文件分别是什么、在哪个子目录
```

再到 Spark UI 的 **SQL 标签页**打开失败那次作业的计划，看 BroadcastExchange 节点上的 `data size` 指标，那才是这次运行实际的广播量。

## 三、怎么修

**止血（让作业今天先跑过）：** 对这个作业禁用自动广播，改走 sort-merge join：

```
spark.sql.autoBroadcastJoinThreshold=-1
spark.sql.adaptive.autoBroadcastJoinThreshold=-1   # AQE 也有自己的广播阈值，一并关掉更稳
```

或者只针对这张表加 hint，不影响作业里的其他 join：

```sql
SELECT /*+ MERGE(z) */ ...
FROM ais_points p JOIN ocean.zone_attr_v2 z ON p.zone_id = z.zone_id
```

改走 SMJ 以后，AQE 的 skew join 拆分也能起作用了。

**根治：**
1. **让统计信息准确。** 在上游脚本生成表之后加一步 `ANALYZE TABLE ... COMPUTE STATISTICS`。否则下次换表还会出同样的问题。
2. **只带需要的列进 join。** 如果统计进出港事件用不到 `geom_wkt`，就在 join 前显式只 select `zone_id` 和需要的属性列。这样 build 端可能会小到真的适合广播，作业也能保持昨天约 12 分钟的速度。
3. **和上游确认 v2 为什么比旧表大这么多。** 旧的 zone_attr 能被稳定广播，说明它很小。v2 是多了几何列、多了港区，还是数据重复了？
4. **重点检查 zone_id 是否唯一。** 如果 v2 里 `count(*)` 明显大于 `count(DISTINCT zone_id)`，说明同一个 zone_id 有多行。这时不光哈希表会变大，join 结果也会成倍膨胀，进出港事件的统计会**算错**。这比作业失败更隐蔽，换成 SMJ 后作业"跑通了"也不代表结果是对的。

## 总结

- **基本可以确定**：zone_attr_v2 因为大小估计偏小被广播，实际体量远超内存，所以在构建广播哈希表时 OOM。
- **需要你确认**：8.2 MiB 和 1.8 GiB 为什么差这么多，以及 OOM 发生在 driver 还是 executor。
- **今天先恢复**：关掉广播或加 `MERGE` hint。
- **长期修复**：补上统计信息、裁剪 join 列，并核对 v2 的 zone_id 是否唯一。

如果你把 SQL 标签页里 BroadcastExchange 节点的指标、`count` 那条查询的结果和 executor 9 的日志贴过来，我可以帮你把结论再收紧一些。
