你的判断基本是对的：主因就是内存不够。具体说，是 executor 内存从 16g 降到 4g 以后，Stage 2 的排序放不进执行内存，开始大量 spill，GC 也跟着变重。另外 800m 的 memoryOverhead 太小，容器会被 YARN 杀掉。数据倾斜、新分区目录和 +2% 的数据量都不是主因。下面是依据和改法。

## 一、为什么说是内存，而不是倾斜

**1. Stage 2 的 task 很均匀，没有倾斜**
- Shuffle Read Size 从 168 MB 到 197 MB，最大值只比中位数多约 9%。Records 是 190 万到 221 万，Duration 是 2.6 到 4.5 min，同样很集中。
- 附 3 里各 executor 的读数也差不多。
- 所以不是某几艘船（mmsi）数据特别多拖慢了整体，而是每个 task 都一样慢。另外，`skewJoin` 只处理 join 里的倾斜分区，这个作业的计划是 Exchange → Sort → Window，没有 join，这项配置本来也用不上。broadcast 阈值同样跟它无关。

**2. 算一下每个 task 能分到多少执行内存**
- 4g 堆：统一内存约为 (4096 − 300) MB × 0.6 ≈ 2.2 GB。4 个核同时跑 4 个 task，每个 task 最多约 570 MB。几个 task 互相争抢时，每个只保证约 285 MB。
- 一个 task 在内存里需要排序的数据量：Spill (Memory) 中位数约 1.4 GB，这是反序列化后的大小，比 181 MB 的 shuffle 压缩数据大得多。
- 1.4 GB 需求对 ≤570 MB 可用，只能反复 spill。日志里的 "spilling … (7 times / 9 times so far)" 和 "Failed to allocate a page (64 MB)" 说的就是这个。
- 对照上周的 16g 堆：(16384 − 300) MB × 0.6 ≈ 9.6 GB，每个 task 约 2.4 GB，比 1.4 GB 宽裕，所以上周 Spill 全是 0。两周的读数完全对得上。

**3. GC 和总耗时也对得上**
- 堆小了，对象又多，GC 占比从 3% 升到 19%。task 中位 GC 时间是 39 s，占 3.4 min 的约 19%。CPU 83% 的利用率里，有不少花在了 GC 和 spill 的序列化/归并上，不是有效计算。
- Stage 2 的 600 个 task 用 64 个 slot 跑，大约 9.4 轮。每轮 3.4 min，Stage 2 约 32 min；上周每轮 1.1 min，约 10 min。光这一个 stage 就多了 20 多分钟，再加上 executor 被杀后的重跑，从 20 min 到 58 min 是说得通的。

**4. executor 被杀，是 overhead 不够，不是堆不够**
- "4.9 GB of 4.8 GB physical memory used"，4.8 GB 正好是 4g 堆加 800m overhead。超的是堆外部分，包括 netty shuffle 缓冲、spill 时的 IO 缓冲、JVM 本身的元空间和线程栈等。频繁 spill 会让这部分用量更大。

**5. 另外两项改动的影响**
- 新分区目录：数据内容没变，而 Stage 2 的输入来自 shuffle，分区数固定为 600，不受读取目录影响。它最多影响 Stage 1 扫描时的 task 数。可以顺手在 Spark UI 里对比一下两周 Stage 1 的耗时确认，但它解释不了 Stage 2 的 spill。
- 数据量 +2%：太小，可以忽略。

## 二、怎么改（按推荐顺序）

**方案 A：给这个作业单独把内存调回去（最直接）**
不改课题组的默认模板，只在这个作业的提交参数里覆盖：
```
spark.executor.memory=12g        # 或恢复 16g
spark.executor.memoryOverhead=2g
```
按上面的算法，12g 堆每个 task 约 1.7 GB，基本能放下 1.4 GB 的排序数据；16g 就和上周一样，完全不 spill。如果运维要控成本，可以说明这个作业是排序密集型的，属于例外。

**方案 B：内存保持 4g，把数据切得更细**
让每个 task 的数据量降到它能分到的内存以内：
```
spark.sql.shuffle.partitions=2400   # 约为现在的 4 倍，每个 task 排序数据约 350 MB
spark.executor.memoryOverhead=1200m # 至少要提，避免被 YARN 杀
```
- 按 mmsi 做 hash 分区，单艘船一天的轨迹点不多，分得更细也不会破坏"同一艘船在同一个分区"的语义。
- 注意 AQE：开了 AQE 时，分区合并（coalescePartitions）默认会把小分区合并到约 64 MB 的目标大小。2400 个分区每个约 45 MB，可能被合成几百个，但每个仍比现在的 181 MB 小得多，效果依然明显。如果想严格保持细分，可以调小 `spark.sql.adaptive.advisoryPartitionSizeInBytes`，或者关掉 `spark.sql.adaptive.coalescePartitions.enabled`。
- 这个方案还会剩一些 spill 和 GC，能明显改善，但未必能回到 20 min。

**方案 C：折中**
例如 8g 堆、1.5g overhead、1200 个分区，每个 task 约 1.1 GB 可用内存，对应约 700 MB 排序数据。成本和速度都比较平衡。

**次要调整（可选）**
- 作业没有 cache/persist 的话，可以把 `spark.memory.fraction` 调到 0.7 到 0.75，给执行内存多留一些。收益不大，不建议单独依赖它。
- 不建议用减少 `executor.cores` 的办法换内存，那样并行度会直接减半。

## 三、改完后怎么确认

在 Spark UI 的 Stage 2 里看这几项：
- Spill (Memory/Disk) 应该降到 0 或接近 0
- GC Time 应该回到 task 时间的 5% 以下
- Duration 中位数应该接近 1 min 左右（方案 A），或明显低于现在的 3.4 min（方案 B/C）
- 日志里不再出现 "Container killed by YARN for exceeding physical memory limits"

如果 spill 消失了但作业还是比 20 min 慢很多，再回头对比 Stage 1，看新分区目录是不是导致了小文件过多、扫描 task 数暴增。

说明：以上计算用的是 Spark 统一内存模型的近似公式，实际每个 task 分到的执行内存会随并发情况浮动，具体数字以改完后 UI 上的实测为准。配置项的含义请以你提供的 4.0.0 官方配置文档为准。
