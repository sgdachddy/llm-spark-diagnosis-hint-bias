## 结论

变慢主要是本周新加的 `feat.persist(StorageLevel.MEMORY_AND_DISK)` 造成的。h3 升级和数据量 +3% 基本可以排除。最快的修复是**先去掉这个 persist**，作业应该能回到约 18 min。

## 时间去哪了

| | 本周 | 上周 | 差值 |
|---|---|---|---|
| Job 0：feat.count()（物化缓存） | 9.5 min | 没有这个 job | +9.5 |
| Job 1–3 合计 | 21.5 min | 17.9 min | +3.6 |
| 总计 | ~31 min | ~18 min | +13 |

- 多出来的 13 min 里，约 **9.5 min 是缓存物化本身**，这是一笔新增的开销。
- 加缓存的目的是让后面三个 job 变快，但它们**每个反而慢了 0.9–1.8 min**。所以这个缓存既有成本，又没有收益。

## 为什么缓存起了反作用

**1. 缓存大部分落在本地磁盘上**
Storage 页显示：内存里 10.2 GB，磁盘上 29.8 GB。也就是说缓存的大头在 executor 本地盘，后续三个 job 主要在读本地盘。这和集群读数对得上：IO wait 从 5% 涨到 28%，CPU 利用率只有 34%，作业已经受 IO 限制，不再受计算限制。

**2. 缓存的是全部列，下游失去了列裁剪**
看附 5 的 ReadSchema，缓存里存了全部 8 列（mmsi、ts、lon、lat、sog、cog、h3_r7、nav_status）。不加缓存时，每个特征 job 直接读 parquet，只扫自己要用的列，过滤条件也能下推（PushedFilters 已经在用）。加了缓存后，三个 job 都从 InMemoryTableScan 读完整宽表，列裁剪的好处没了。

**3. 本周出现了 shuffle spill，上周没有**
Job 2 聚合 stage 每个 task 溢写约 1.0 GB（内存口径）和 0.35 GB（磁盘口径），上周全是 0。我的推断是缓存块和聚合争用 executor 的统一内存。估算：(24 GB − 300 MB) × 0.6 ≈ 14.2 GB，8 个并发 task 平均每个不到 1.8 GB。另外，从磁盘读出的 MEMORY_AND_DISK 块可能被重新放回内存。挤压之后，聚合就溢写到本地盘，而这块盘本来就在被缓存读写占用，IO 压力叠在一起。这一点是推断，需要按后面的方法验证。

## 可以排除的因素

- **h3 升级**：代码注释说 h3_r7 由上游预先算好写进 parquet，执行计划里也没有 Python UDF 节点（没有 BatchEvalPython / ArrowEvalPython）。本作业运行时根本不调用 h3。
- **数据量 +3%**：最多解释几十秒，不可能让作业慢 70%。
- **数据倾斜**：Job 2 的 task 很均匀，shuffle read 在 92–121 MB 之间，耗时中位数 1.2 min、最大 1.9 min。所以 skewJoin 一类配置和这次问题无关（执行计划里也没有 join）。
- **GC**：只占 6%，不是瓶颈。

## 建议操作（按优先级）

1. **去掉 `persist` 和 `feat.count()` 重跑一次**。预期回到约 18 min，Job 2 的 spill 回到 0。这一步同时验证了上面的判断。
2. **如果确实想复用 feat**，先只选三个 job 用到的列，再缓存，例如 `feat.select("mmsi", "ts", "lon", "lat", "sog", "h3_r7", "nav_status").persist(...)`（以实际用到的列为准）。然后和"不缓存"的版本对比总时长。只有当"物化时间 + 三个 job 时间"小于不缓存的总时长时，缓存才值得留。按上周数据，每个 job 直接读 parquet 也就 6 min 左右，缓存的收益空间不大。
3. **如果去掉缓存后 spill 还在**，再考虑调高 `spark.sql.shuffle.partitions`（比如 320 → 640），减小每个 task 的聚合内存。按上周 spill 为 0 的情况看，大概率不需要。

## 需要验证的话，看这几处

- 本周作业运行时，Spark UI 的 **Executors 页 Storage Memory 列**：看 Job 2 期间存储内存是否明显上涨，用来确认内存争用的推断。
- **Job 1–3 的 stage 详情**，上周和本周对比 Input 大小和读取来源：上周应该是 parquet 小列集，本周是缓存的全量列。
- 去掉 persist 后，**IO wait** 是否回到 5% 左右。

如果第 1 步重跑后时间没有回来，请把重跑后的 Jobs 概览和 Job 2 的 Summary Metrics 发给我，再往下查。
