看了你给的材料，我认为根因不是"内存不够"。更像是：**Spark 把一张实际很大的表当成小表做了广播**。直接加内存多半治标不治本，甚至可能还是会挂。下面是推理过程和建议。

## 一、核心矛盾：估算大小和实际大小差了约 200 倍

- 附 4（EXPLAIN COST）：优化器认为 `zone_attr_v2` 只有 **8.2 MiB**
- 附 6（S3 目录）：这张表实际有 **1.8 GiB**（parquet 压缩后的大小）
- 附 7：`spark.sql.autoBroadcastJoinThreshold=10MB`

8.2 MiB < 10MB，所以优化器选了 **BroadcastHashJoin**（附 3 的 `BroadcastHashJoin ... BuildRight` + `BroadcastExchange (4)` 下面就是 `zone_attr_v2`）。

附 1 的报错栈也对得上：OOM 发生在 `HashedRelationBroadcastMode.transform` → `UnsafeHashedRelation.apply`，也就是**构建广播哈希表**的时候。1.8 GiB 的 parquet 解压、反序列化后放进内存，体积通常比磁盘上大好几倍。何况表里有 `geom_wkt` 这种 WKT 几何文本列，膨胀会更明显。每个 executor 都要持有一份完整副本，16 GB 的堆（execution + storage 只占 (16G−300MB)×0.6 ≈ 9.4 GB）放不下，这很正常。

这也解释了"昨天正常、今天失败、代码没改"：唯一的变化就是 `zone_attr` 换成了 `zone_attr_v2`。

## 二、其他现象也支持这个判断

- **附 2：没有数据倾斜。** 已完成 task 的 Input Size 很均匀（118–131 MB），Duration 也很集中，所以不是"某个分区特别大"的问题。另外，`spark.sql.adaptive.skewJoin.enabled` 只对 sort-merge / shuffled hash join 生效，管不了广播 join，指望 AQE 自动兜底是没用的。
- **GC 时间偏高。** GC 中位数 14 s，Duration 中位数 52 s，大约 1/4 的时间在 GC，说明堆一直处在高压状态，和"每个 executor 都背着一份巨大的广播表"吻合。
- **Spill 全是 0。** 广播哈希表必须整块放进内存，不会溢写到磁盘。所以不会先 spill 再慢慢跑完，而是直接 OOM。
- 报错里的"heartbeat timed out"可以理解为长时间 Full GC / OOM 带来的连锁反应，不是独立的问题。

## 三、8.2 MiB 这个错误估算是从哪来的？（需要你确认）

附 5 里 `DESCRIBE TABLE EXTENDED` 没有 Statistics 行，说明这张表**没跑过 `ANALYZE TABLE`**。那 8.2 MiB 的来源就比较可疑。仅凭现有材料我没法确定，常见的可能有：

1. 上游脚本建表时写入了旧的或错误的表属性（例如 metastore 里的 `totalSize` / `rawDataSize`），可以用 `SHOW TBLPROPERTIES ocean.zone_attr_v2` 查看；
2. 表是"先建好、后写数据"或被覆盖写过，Spark 或 metastore 里缓存的文件列表/元数据过期了（建表时间是昨晚 23:41，和上游替换时间吻合）；
3. 其他统计信息来源（例如上游用别的引擎写表时带上的统计）。

建议跑一下这几条，看估算会不会变：

```sql
SHOW TBLPROPERTIES ocean.zone_attr_v2;
REFRESH TABLE ocean.zone_attr_v2;
ANALYZE TABLE ocean.zone_attr_v2 COMPUTE STATISTICS;
EXPLAIN COST SELECT * FROM ocean.zone_attr_v2;   -- 看 sizeInBytes 是否变成 GB 级
```

## 四、更值得警惕的问题：港区属性表为什么有 1.8 GiB？

港区属性表通常不大，原来的 `zone_attr` 能被广播、作业 12 分钟跑完，说明旧表应该很小。新表到了 1.8 GiB，建议先查一下上游脚本是不是出了问题：

```sql
SELECT COUNT(*), COUNT(DISTINCT zone_id) FROM ocean.zone_attr_v2;
-- 和旧表 zone_attr 对比同样两个数
```

- 如果 `COUNT(*)` 远大于 `COUNT(DISTINCT zone_id)`，说明 **zone_id 有重复**。那就算作业跑通了，join 结果也会被放大，**进出港事件会重复计数，结果是错的**。这比作业失败更严重。
- 如果确实是业务需要（比如 `geom_wkt` 换成了高精度几何），那就要从作业侧调整 join 策略（见下文）。

## 五、建议的处理顺序

**1. 先止血，让今天的作业跑过去（任选其一）：**
- 只对这个作业关掉自动广播：`spark.sql.autoBroadcastJoinThreshold=-1`
- 或者在 SQL 里对这个 join 加 hint，强制走 shuffle：`/*+ MERGE(z) */` 或 `/*+ SHUFFLE_HASH(z) */`（z 是 zone_attr_v2 的别名）

  改成 sort-merge join 以后，AQE 的倾斜处理和 spill 机制都能起作用，不会再整表塞进每个 executor 的内存。

**2. 修正统计信息：** 按第三节执行 `REFRESH` / `ANALYZE`，确认 `EXPLAIN COST` 显示的是真实大小。以后上游每次重建这张表，最好都在写完后跑一次 `ANALYZE TABLE`。

**3. 核查上游数据：** 按第四节检查 zone_id 是否重复、表为什么变大。如果是上游 bug，修好后表变回小表，广播 join 就又是最快的方案。

**4. 不建议优先加 executor 内存。** 广播表的实际内存占用可能远超 1.8 GiB，加内存未必够用，还掩盖了统计错误和可能存在的数据质量问题。

## 需要说明的不确定点

- 报错栈是节选，"heartbeat timed out / OOM" 写在同一行，我是按 OOM 为主因来理解的；
- 我没看到旧表 `zone_attr` 的大小和行数，"新表异常变大"是推断，需要你对比确认；
- 8.2 MiB 的具体来源需要按第三节的命令去确认。

如果方便，可以把 `SHOW TBLPROPERTIES` 的输出和第四节两条计数的结果发给我，我再帮你判断具体是哪一种情况。
