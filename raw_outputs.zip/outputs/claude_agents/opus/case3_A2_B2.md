从你给的材料看，"zone_attr_v2 被广播了"这一点，执行计划已经能直接证实。真正要查的是：它为什么会被广播，以及广播之后为什么会把内存撑爆。下面按你的要求分三部分写，先不下结论。

---

## ① 现象和关键读数

**发生了什么**
- 作业代码没改，唯一的变化是港区属性表从 zone_attr 换成了上游昨晚 23:41 新生成的 zone_attr_v2。昨天约 12 分钟跑完，今天在 join 所在的 stage 4 失败。
- 多个 executor 先后退出。Task 37 失败 4 次后整个作业终止。报错是 `OutOfMemoryError: Java heap space`，栈停在 `UnsafeHashedRelation` / `HashedRelationBroadcastMode` / `BroadcastExchangeExec`，也就是**在为广播表构建哈希表时内存不够**。

**关键读数**

| 来源 | 读数 | 含义 |
|---|---|---|
| 附 3 执行计划 | `BroadcastHashJoin BuildRight`，右侧是 `BroadcastExchange ← zone_attr_v2` | zone_attr_v2 确实被选为广播表 |
| 附 4 EXPLAIN COST | `sizeInBytes=8.2 MiB` | 优化器估计这张表只有 8.2 MiB，略低于 10MB 的广播阈值 |
| 附 5 DESCRIBE | 没有 Statistics 行 | 这张表没跑过 ANALYZE，估算不是来自 catalog 统计 |
| 附 6 S3 列表 | 6 个对象，共 **1.8 GiB** | 存储上的实际大小是估算值的 **约 225 倍** |
| 附 7 配置 | 阈值 10MB，AQE 开启，executor 16g | 都是默认值或常规值，本次没有改动 |
| 附 2 Stage 4 | 每个 task 输入约 126 MB，分布很均匀（118–131 MB）；GC 中位数 14 s，约占耗时的 27%；Spill 全为 0 | 没有数据倾斜的迹象；GC 占比偏高，说明堆内存吃紧 |

**最突出的矛盾**：优化器以为这张表是 8.2 MiB，存储上却有 1.8 GiB。另外有两点值得注意：
- 附 1 那段报错把 "heartbeat timed out" 和 "OOM" 放在了同一行，可能是脱敏或节选时合并的。最好到 executor 9 的 stderr 里确认一下，OOM 的第一现场到底在哪。
- AQE 的 skewJoin 只处理 sort-merge 和 shuffled hash join，对广播 join 不起作用。所以"AQE 开着应该能兜住"这条路在这里不成立。

---

## ② 可能的原因假设（按可能性从高到低）

**假设 1：大小估算严重偏低，一张约 GB 级的表被误判成小表拿去广播了**
没有 catalog 统计时，Spark 按文件索引里列出的文件大小来估算。8.2 MiB 和 1.8 GiB 差了两个数量级，说明优化器"看到"的文件和 S3 上实际有的文件可能不一致。可能的原因有：上游写表时有覆盖或追加，计划用的是更早一刻的文件列表或缓存；或者目录里混进了其他文件。如果真按 1.8 GiB 广播，每个 executor 都要放一份完整的哈希表，16g 的堆在扣掉 300MB 预留和 0.6 的 memory.fraction 之后，执行内存不到 10g。解压后的 GB 级数据很容易撑爆它，这和 OOM 的位置以及 GC 偏高都对得上。

**假设 2：zone_id 在新表里不再唯一，重复键让哈希表和 join 输出都膨胀了**
新表由上游脚本生成，如果它按"一个 zone 多条记录"输出（比如多个版本、按时间切片、一个港区拆成多个多边形），哈希表里同一个键会挂很多行，join 后的行数也会成倍增长。这条可以和假设 1 同时成立，也可以单独成立。

**假设 3：单行变"胖"了，磁盘上压缩得很小，读进内存后却很大**
列里有 `geom_wkt`（WKT 文本几何）和 `attrs`。如果 v2 的多边形精度更高、顶点更多，或者 attrs 变成了大的嵌套结构，Parquet 压缩后看着不大，展开成 UnsafeRow 后可能放大好几倍到几十倍。这种情况下，即使估算的 8.2 MiB 本身准确，广播到内存里也会远超预期。

---

## ③ 每个假设的验证动作（均为只读）

**验证假设 1：核对优化器实际读到的文件和大小**
在 spark-shell 或 notebook 里只读地执行：
```scala
val files = spark.table("ocean.zone_attr_v2").inputFiles
files.foreach(println)   // 看列出的文件数和文件名
```
再对照附 6 的 S3 列表，逐个比较文件名、数量和大小（`aws s3 ls` 不加 `--summarize`，看每个对象的明细）。同时打开 Spark UI 里失败那次查询的 SQL 页，看 `BroadcastExchange` 节点的 "data size" 指标。如果它远大于 8.2 MiB，或者 inputFiles 和 S3 上的文件对不上，假设 1 就基本成立。

**验证假设 2：查 zone_id 是否唯一**
```sql
SELECT count(*) AS rows, count(DISTINCT zone_id) AS keys
FROM ocean.zone_attr_v2;

SELECT zone_id, count(*) AS c
FROM ocean.zone_attr_v2
GROUP BY zone_id HAVING c > 1
ORDER BY c DESC LIMIT 20;
```
然后在旧表 zone_attr 上跑同样的语句做对比。如果 rows 远大于 keys，或者某些 zone_id 重复上百上千次，假设 2 就成立。

**验证假设 3：比较新旧表的单行体量**
```sql
SELECT count(*),
       avg(length(geom_wkt)), max(length(geom_wkt)),
       avg(length(to_json(attrs))), max(length(to_json(attrs)))
FROM ocean.zone_attr_v2;
```
在旧表上跑同样的语句。如果 v2 的平均或最大 WKT 长度明显变大（例如从几 KB 涨到几百 KB），就说明内存放大很可能来自行内容本身。（如果 attrs 不是 struct 或 map 类型，把 `to_json` 去掉即可。）

---

**建议的先后顺序**：先做假设 1 的验证，它直接对应目前最大的矛盾（8.2 MiB 和 1.8 GiB），而且只要看文件列表和 UI 指标，成本最低。另外两个查询都是对一张小维表做聚合，也很便宜，可以顺手一起跑。三组结果出来后，基本就能判断是"估错了大小"、"键重复了"还是"行变胖了"，或者几种同时存在。到时候再讨论怎么修（比如补统计信息、用 hint 控制 join 策略、让上游修数据），会更有依据。如果方便，把这几条的输出贴回来，我帮你一起看。
