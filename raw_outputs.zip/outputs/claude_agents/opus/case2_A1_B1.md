看完你给的材料，我的判断是：**变慢主要是本周加的 `persist(MEMORY_AND_DISK)` 造成的，h3 升级基本可以排除。** 下面是推理过程和验证办法。

## 一、为什么不像是 h3 的问题

1. **这个作业根本没有调用 h3。** 代码注释写着 `h3_r7` 列由上游预先算好写进 parquet，Job 2 的物理计划里也只有 `Scan parquet → Filter → InMemoryTableScan → Project → HashAggregate`，没有 `BatchEvalPython` / `ArrowEvalPython` 这类 Python UDF 节点。h3 是 Python 库，只有在 UDF 里被调用才会影响本作业的性能。
2. **资源特征也对不上。** 如果是 h3 新版本变慢，应该表现为 CPU 密集（Python worker 跑满）。实际 CPU 利用率只有 34%，磁盘 IO wait 却从 5% 涨到 28%，GC 只占 6%。这说明作业卡在磁盘 IO 上，不是卡在计算上。
3. **数据量 +3% 也解释不了。** 总耗时从 18 min 涨到 31 min，涨了约 72%。

## 二、时间到底花在哪里

| | 本周 | 上周 |
|---|---|---|
| Job 0：feat.count()（物化缓存） | 9.5 min | 没有这一步 |
| Job 1–3 合计 | 21.5 min | 17.9 min |
| **总计** | **约 31 min** | **约 18 min** |

多出来的约 13 min 有两个来源：

- **约 9.5 min 是新增的缓存物化步骤**，这是加 persist 带来的直接成本。
- **约 3.6 min 来自三个下游 Job 都变慢了**，加了缓存后它们反而比之前慢。

## 三、缓存为什么帮了倒忙

**1. 缓存大部分落在磁盘上。** Storage 页显示 feat 缓存在内存里的只有 10.2 GB，在磁盘上有 29.8 GB，约 3/4 的分区在本地盘。所以三个下游 Job 每次都要从本地盘把这部分缓存读出来，再加上物化时写盘，磁盘 IO wait 就上去了。

**2. 原来的读法本来就很便宜。** 之前不加缓存时，每个 Job 直接读 parquet：过滤条件已经下推（`PushedFilters: [IsNotNull(sog), GreaterThan(sog,0.5)]`），列式格式只读需要的列。从 S3 重读三次未必比"先物化 40 GB 缓存（大部分落盘）再读三遍"慢。从结果看，确实是后者更慢。

**3. 缓存挤占了执行内存，聚合开始 spill。** 按你的配置估算：
- 每个 executor 的统一内存 ≈ (24 GB − 300 MB) × 0.6 ≈ 14.2 GB
- 其中 storage 受保护部分 ≈ 14.2 × 0.5 ≈ 7.1 GB，执行内存不能把它驱逐
- 每个 executor 8 个并发 task，每个 task 最多大约分到 1.7 GB 执行内存

Job 2 的聚合 Stage 中位数 spill(memory) 约 1.0 GB，而上周同一 Stage 完全没有 spill。说明这个聚合原本就接近内存上限，缓存块占掉一部分统一内存后，它就开始往盘上溢写（每个 task 约 0.35 GB）。这又加重了磁盘压力。

另外，Job 2 各 task 的 shuffle read 分布很均匀（92–121 MB），时长也比较集中（58 s – 1.9 min），**不存在数据倾斜**。所以文档里提到的 `skewJoin`、`autoBroadcastJoinThreshold` 跟这次问题无关（计划里也没有 join）。

## 四、建议怎么做

**第一步：做对照实验，确认原因（最重要）。** 保留新版 h3，只去掉 `persist` 和 `feat.count()` 跑一次。如果耗时回到 18 min 左右，就确认是缓存的问题。如果你还不放心 h3，可以再把 h3 退回旧版、保留 persist 跑一次做反向对照，不过根据上面的证据，我预计这一项不会有差别。

**第二步：根据结果选方案。**

- **方案 A（推荐）：直接去掉 persist。** 对"读 parquet + 简单过滤"这种上游，Spark 重读的成本本来就低，上周的 18 min 就是证据。
- **方案 B：如果确实想复用中间结果，先裁剪列再缓存。** 只 `select` 三组特征实际用到的列，减小缓存体积，争取让它完全放进内存：
  ```python
  feat = (spark.read.parquet(...)
          .filter("sog IS NOT NULL AND sog > 0.5")
          .select("mmsi", "ts", "sog", "h3_r7", ...))  # 只保留下游需要的列
  ```
  然后看 Storage 页里 Size on Disk 是否降到 0、聚合 Stage 是否不再 spill。如果还有 spill，就不值得缓存。
- 用完记得 `feat.unpersist()`，避免后面的 Job 一直被缓存占着内存。

**第三步：顺带核实两件事。**
1. 我只看到了 Job 2 的计划。请也看一下 Job 1 和 Job 3（尤其是航线密度 `lane_density`）的 EXPLAIN，确认里面没有调用 h3 的 Python UDF。如果有，h3 才有可能是因素之一。
2. h3 虽然不太可能影响本作业的性能，但 **`h3_r7` 是上游用 h3 算出来的**。如果上游作业也升级了 h3，建议抽查一下本周 `h3_r7` 的取值是否和上周一致。这是数据正确性问题，会影响航线密度特征的结果，和速度无关，但值得确认一下。

如果你把对照实验的结果，或者 Job 1/3 的执行计划发给我，我可以帮你进一步确认。
