材料很全，我按你的要求来：先复述，再给假设和验证动作，不改任何配置，也不下定论。

## ① 现象和关键读数

**一句话：** 昨天还正常（约 12 分钟）的作业，换了新表 `zone_attr_v2`、代码没动，今天在 join 阶段反复 OOM，重试 4 次后终止。

关键读数：

- **报错位置：** OOM（`Java heap space`）出在 `UnsafeHashedRelation` → `HashedRelationBroadcastMode` → `BroadcastExchangeExec`。也就是说，**是在把 `zone_attr_v2` 建成广播哈希表时内存不够**，不是 shuffle 或排序阶段出的问题。同时伴随 executor 心跳超时，说明 executor 在长时间 Full GC 中卡住或死掉了。
- **执行计划：** `BroadcastHashJoin Inner BuildRight`，被广播的一侧（build side）是 `zone_attr_v2`。
- **优化器的估算和实际存储对不上：**
  - EXPLAIN COST 里 `zone_attr_v2` 的估算是 **8.2 MiB**，低于 `autoBroadcastJoinThreshold=10MB`，所以优化器选了广播；
  - 但 S3 上这个目录有 **6 个对象，共 1.8 GiB**，比估算大约 200 倍；
  - `DESCRIBE TABLE EXTENDED` 里**没有 Statistics 行**，说明这张新表没有收集过统计信息。8.2 MiB 这个数到底怎么来的，目前还说不清。
- **Stage 4 已完成的 61 个 task：** 每个 task 读约 126 MB，耗时约 52 秒，其中 GC 约 14 秒（**占 25%–30%，偏高**），没有落盘（Spill = 0）。各 task 之间很均匀，**看不出数据倾斜**。
- **资源：** 12 个 executor × 8 核 × 16 GB。按默认 `memory.fraction=0.6`，每个 executor 统一内存池大约 9.4 GB，由 8 个并发 task 共用，而且每个 executor 都得在堆里放一份完整的广播表。
- **补充一点：** `skewJoin` 只对 sort-merge / shuffled hash join 生效，管不到 broadcast join。所以 AQE 虽然开着，这里也帮不上忙。

## ② 可能的原因假设（按可能性从高到低）

**假设 1（最可能）：`zone_attr_v2` 的大小被严重低估，被误判成小表广播了，实际在内存里远超 executor 能承受的量。**
新表没有统计信息，估算的 8.2 MiB 和存储上的 1.8 GiB 差了两个数量级。另外，Parquet 是压缩格式，`geom_wkt` 这种长文本几何列解压、建成哈希表后，通常会比磁盘上大好几倍。旧表 `zone_attr` 可能确实小到能广播，所以昨天没出事。

**假设 2：`zone_attr_v2` 里的 `zone_id` 不再唯一（上游脚本生成时出现重复或展开），导致哈希表和 join 结果一起膨胀。**
新表是上游脚本昨天才生成的，如果没去重，或者把一个港区拆成了多行（比如多边形被拆开、多版本属性并存），广播表会变大，每个 AIS 点 join 出来的行数也会成倍增加。这会和假设 1 叠加起作用。

**假设 3：Executor 本来就处在内存紧张的边缘，新表只是压垮它的最后一根稻草。**
GC 占 task 时间 25%–30%，说明昨天之前可能就已经很吃紧了。8 个并发 task 共用 16 GB 堆，再加一份整表广播副本，只要广播表稍微变大，就可能越过 OOM 的临界点。这一条更像"放大因素"，不太像根因。

## ③ 每个假设对应的验证动作（都是只读操作）

**验证假设 1：看清楚 `zone_attr_v2` 实际有多大、8.2 MiB 是怎么来的。**
先跑一次 `aws s3 ls --recursive s3://<bucket>/warehouse/ocean.db/zone_attr_v2/`（不加 `--summarize`），逐个看这 6 个对象的文件名和大小，重点检查有没有 `_temporary/`、`.` 或 `_` 开头的隐藏文件、残留的 staging 目录（Spark 读表时会跳过这些，它们可能占了大部分体积，也可能正好解释估算偏差）。然后在小资源会话里跑一个只读聚合，估算解压后的真实体量：

```sql
SELECT count(*), sum(length(geom_wkt)), max(length(geom_wkt)), avg(length(geom_wkt))
FROM ocean.zone_attr_v2;
```

如果有昨天成功那次的记录，可以去 Spark UI 的 SQL 页签，对比 `BroadcastExchange` 节点的 "data size" 指标。
注意：`ANALYZE TABLE ... COMPUTE STATISTICS` 会把统计信息写进 metastore，**不算只读**，这一步先别做。

**验证假设 2：检查 `zone_id` 是否唯一，并和旧表对比。**

```sql
SELECT count(*) AS rows, count(DISTINCT zone_id) AS keys FROM ocean.zone_attr_v2;
SELECT zone_id, count(*) c FROM ocean.zone_attr_v2 GROUP BY zone_id ORDER BY c DESC LIMIT 20;
```

对旧表 `ocean.zone_attr` 跑同样两条，对比行数和键数。如果 `rows` 明显大于 `keys`，或者比旧表多出很多，这个假设就成立。

**验证假设 3：确认 executor 在失败前的内存和 GC 状况。**
打开 Spark UI 的 Executors 页签（或 History Server 里这次的应用），看各 executor 的 Peak JVM Heap / On-heap Memory 和 GC Time，再拉 executor 9 的 stderr 日志，看 OOM 前有没有连续 Full GC。然后找昨天成功那次的 Stage 指标（同一个 stage 的 GC Time 中位数）做对比：如果昨天 GC 占比也有 25% 左右，说明是长期存在的余量不足；如果昨天明显更低，那问题主要出在新表上。

## ④ 说明

- 上面只是排序后的假设，**还没有下结论**，等你跑完验证动作把结果发我，我们再定位。
- 我没有建议你改任何配置。等原因确认后，再一起讨论该怎么处理（比如补统计信息、对新表去重、调整广播策略等）。
- 还有一个小疑点：报错栈表头写的是 executor 9 上的 task 失败，但调用链里有 `BroadcastExchangeExec`，这一般是在 driver 端构建广播的路径。可能是节选时把几段栈拼在了一起。方便的话，把 executor 9 和 driver 各自完整的第一个 `Caused by` 发我看看，有助于确认 OOM 到底发生在哪一端。
