你的判断基本是对的：变慢主要是新加的 `persist` 造成的。不过更准确的说法是，这里根本不需要缓存，而不是缓存参数配错了。下面按证据说明，最后给出改法和验证方法。

## 结论

`feat` 只是"读 parquet + 一个简单过滤"，重新计算的成本很低。缓存它反而多出一次完整物化（9.5 min），而且约 3/4 的缓存落在了本地磁盘上。后面三个 Job 从本地磁盘读缓存，比直接扫 parquet 更慢，同时聚合阶段开始 spill。去掉 `persist` 和 `count()` 后，预计能回到 18 min 左右（输入多 3%，可能多几十秒）。

## 证据链

**1. 时间账对得上**

| | 上周 | 本周 | 差值 |
|---|---|---|---|
| Job 0 物化缓存 | — | 9.5 min | +9.5 |
| Job 1/2/3 合计 | 17.9 min | 21.5 min | +3.6 |
| 合计 | ≈18 min | ≈31 min | +13 |

缓存的目的是让后续 Job 变快，但三个下游 Job 都变慢了（各慢 0.9–1.8 min），还额外付了 9.5 min 物化成本。这是净亏损，不是"缓存没调好所以收益小"。

**2. 缓存大部分在磁盘上**

Storage 页：内存 10.2 GB，磁盘 29.8 GB，也就是约 75% 的分区是从 executor 本地磁盘读回来再反序列化的。这和集群读数一致：IO wait 从 5% 涨到 28%，CPU 利用率只有 34%，作业是 IO 受限，不是算力不够。

**3. 缓存还破坏了列裁剪**

附 5 的 `ReadSchema` 包含全部 8 列，因为缓存要服务三个下游，只能把所有列都存下来。不缓存时，每个 Job 扫 parquet 只读自己需要的列，还能用上谓词下推（`PushedFilters` 已经生效）。磁盘上的缓存块要整块读出，享受不到这种裁剪。

**4. 聚合阶段开始 spill**

Job 2 聚合 Stage 上周 spill 为 0，本周每个 task 的 Spill (Disk) 中位数约 0.35 GB，320 个 task 合计约 100 GB 的磁盘写读，这也推高了 IO wait。最可能的原因是缓存占用了统一内存池，压缩了 execution 可用的内存。

这里有一点要说明：按你的配置估算，每个 executor 统一内存约 (24 GB − 300 MB) × 0.6 ≈ 14 GB，而 Storage 页显示内存中缓存总共只有 10.2 GB（平均每个 executor 约 1 GB），单看这个数字不足以把 execution 内存挤到 spill。可能是 Storage 页截图和 Job 2 运行不在同一时刻，也可能还有别的缓存或内存占用。建议在 Job 2 运行时看一眼 Executors 页的 "Storage Memory" 列确认。不过这不影响主结论：去掉缓存后，这部分内存压力自然消失。

## 可以排除的方向

- **数据倾斜**：task 耗时 58 s – 1.9 min，Shuffle Read 92–121 MB，分布很均匀，没有倾斜。计划里也没有 join，所以版本说明里的 skewJoin、autoBroadcastJoinThreshold 都与此无关，不必调。
- **输入 +3%**：最多解释几十秒，解释不了 13 min，也解释不了 spill 从 0 变成每 task 约 1 GB。
- **h3 升级**：`h3_r7` 由上游预先算好写进 parquet，Job 2 的计划里也没有 Python UDF 节点（`BatchEvalPython` / `ArrowEvalPython`）。三个 Job 同步变慢，也更像共同原因（读缓存）。唯一没覆盖到的是 Job 1 和 Job 3 的计划，你没贴。如果 `speed_dist` 或 `lane_density` 里调用了 h3 的 Python UDF，建议也 EXPLAIN 一下确认。

## 建议改法

**首选：直接去掉缓存**

```python
feat = (spark.read.parquet("s3://<bucket>/ais_points/2026-11/")
        .filter("sog IS NOT NULL AND sog > 0.5"))
speed_dist(feat).write.parquet(out1)
berth_time(feat).write.parquet(out2)
lane_density(feat).write.parquet(out3)
```

上周就是这个形态，18 min，说明三次扫 S3 parquet 的成本完全可以接受。

**如果以后 feat 变复杂（例如加了 join、UDF、窗口），确实需要缓存**，可以这样改：

1. 缓存前先 `select` 三个下游真正用到的列，缩小缓存体积。
2. 去掉单独的 `feat.count()`，让第一个写出 Job 顺带物化缓存，省掉一次完整的扫描。
3. 用完调用 `feat.unpersist()`。
4. 先确认缓存能放进内存。如果放不进、大量落盘，就说明缓存不划算，不如重算或把中间结果写成 parquet。

不建议靠调 `spark.memory.fraction` / `storageFraction` 来"救"这个缓存，问题出在缓存本身没有收益，调参是在治标。

## 验证方法

去掉 persist 后跑一次，对照以下几点：

- 总时长回到约 18–19 min；
- Job 2 聚合 Stage 的 Spill 回到 0；
- 磁盘 IO wait 回到约 5%；
- Storage 页为空。

如果这几项都恢复，就可以确认根因。如果时长恢复了但 Job 1 或 Job 3 还偏慢，再去查它们是否用了 h3 的 Python UDF。
