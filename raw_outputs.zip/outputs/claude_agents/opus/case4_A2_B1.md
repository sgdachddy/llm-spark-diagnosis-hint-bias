先说我看完材料后的总体印象：**这批读数不太像典型的数据倾斜，更像"所有 task 一起变慢"**。下面按你的要求一步步来。结论我先不下，需要你按第三部分去验证。

---

## ① 用人话复述现象和关键读数

**现象**
- `ais_track_segments` 本周从约 20 分钟变成约 58 分钟，慢了将近 3 倍。
- 偶尔有 executor 被 YARN 杀掉，然后重跑。
- 本周有三处变化：executor 内存从 16g 降到 4g（运维改了模板）；输入目录换成新的按天分区结构（据说内容不变）；数据量多了 2%。

**关键读数**

| 方面 | 读数 | 我的解读 |
|---|---|---|
| 各 task 之间是否均匀 | Duration 最大 4.5 min，中位数 3.4 min，比值约 1.3；Shuffle Read 最大 197 MB，中位数 181 MB，比值约 1.09；记录数 190 万到 221 万 | 600 个 task 的数据量和耗时都很接近，**没有出现"少数 task 特别大、特别慢"的长尾** |
| 和上周比 | Stage 2 中位耗时 1.1 min → 3.4 min；Spill 从 0 变成每个 task 都有（内存 1.1–1.7 GB，磁盘 0.4–0.7 GB） | 是**整体变慢**，而且每个 task 都在往磁盘溢写 |
| GC | 占 task 时间从约 3% 涨到 19%；单个 task GC 21–58 s | JVM 堆明显吃紧 |
| executor 之间是否均匀 | 16 个 executor 的 Task Time 都在 2.2–2.4 h，Spill 也都差不多 | 不是某台机器或某个 executor 的问题 |
| 日志 | 排序数据被反复溢写到磁盘（同一线程溢写 7 次、9 次）；申请 64 MB 内存页失败；容器用了 4.9 GB 物理内存，上限 4.8 GB，被 YARN 杀掉 | 内存不够用，并且容器的**物理内存**超过了上限 |
| 执行计划 | Scan → Filter → 按 mmsi 哈希分到 600 个分区 → Sort → Window | 是 Window 算子，**不是 join** |

**几笔粗算（数量级参考，不是精确值）**
- 每个 executor 能用于计算和缓存的统一内存约为 (4096 MB − 300 MB) × 0.6 ≈ **2.2 GB**，4 个核同时跑 4 个 task 共用，每个 task 大约只能拿到 **550 MB**。上周 16g 时同样算下来，每个 task 约 **2.4 GB**。
- 每个 task 的 Spill (Memory) 中位数是 1.4 GB，也就是反序列化后要排序的数据量。这个值**放不进 550 MB，但放得进 2.4 GB**，正好对得上"上周 Spill 为 0，本周人人都 Spill"。
- 容器上限 = 4g + 800m overhead ≈ 4.8 GB，和日志里的 "4.8 GB physical memory limit" 一致。
- 时间账：600 个 task ÷ 64 个并行槽 ≈ 9.4 轮。本周每轮约 3.4 min，Stage 2 约 32 min；上周每轮约 1.1 min，约 10 min。**单这一个 Stage 就多出大约 20 多分钟**，剩下的差距可能来自重跑和其他 Stage，这一点还要核实。

**关于"数据倾斜"的说明**：倾斜一般表现为少数分区的数据量是中位数的几倍甚至几十倍，对应的 task 拖成长尾。按 mmsi 哈希分区时，如果某条船当天的点特别多，它所在的那个分区会明显偏大，Max 一列会冒尖。目前 Max/Median 只有 1.09–1.3，所以**现有读数不太支持倾斜**。另外，你摘录的 `spark.sql.adaptive.skewJoin.enabled` 只对 sort-merge / shuffled hash **join** 起作用，这个作业的瓶颈在 Window + Sort，这项配置开不开影响不大。

---

## ② 可能的原因假设（按可能性从高到低，共 3 个）

### 假设 1（可能性最高）：executor 内存从 16g 降到 4g，排序阶段内存不够，导致全面溢写和高 GC

- 依据：时间上和内存下调同时发生；每个 task 都有 Spill，而上周为 0；GC 从 3% 涨到 19%；有申请内存页失败的日志；上面的粗算显示每个 task 可用内存从约 2.4 GB 降到约 550 MB，而需要排序的数据约 1.4 GB。
- 机制：Window 前的 Sort 要把每个分区按 mmsi + 时间排好序。内存放不下就反复溢写到磁盘再归并，同时小堆上频繁 GC，所以每个 task 都慢了约 3 倍。

### 假设 2：容器的非堆内存（overhead）不够，个别 executor 被 YARN 按物理内存超限杀掉，重跑又放大了总耗时

- 依据：日志明确写着 "4.9 GB of 4.8 GB physical memory used"，这是 YARN 按**整个进程的物理内存**（堆 + 堆外 + 直接内存 + 线程栈等）判定的，不是 JVM 堆 OOM。
- 机制：频繁溢写和 shuffle 读会用到较多堆外/直接内存（压缩缓冲、网络缓冲等），800m 的 overhead 可能不够。executor 被杀后，它上面正在跑的 task 要重跑，可能连带丢掉 shuffle 输出、触发上游重算，这部分会额外拉长墙钟时间。
- 说明：这个假设和假设 1 是同一次改动引出的，但机制不同（一个是堆内执行内存不够，一个是容器物理内存超限），验证方法也不同，所以单独列出。

### 假设 3（可能性较低）：新分区目录改变了读取行为，实际读入的数据或文件布局和上周不同

- 依据：本周确实改了输入目录结构。如果分区裁剪没有生效（比如分区列名或格式变了，过滤条件没有下推成 PartitionFilters），或者新目录下的文件数、文件大小和上周差别很大，Stage 1 的读取量和 Stage 2 的输入都可能受影响。
- 为什么排在最后：你提到数据内容不变、量只多 2%，而 Stage 2 的 shuffle 读入看上去也很均匀，这个假设能解释的现象不多。不过它是本周的变化之一，值得花几分钟排除。

---

## ③ 每个假设对应的验证动作（全部只读）

### 验证假设 1：在当前配置下做一次小样本试跑，看每个 task 的数据量变小后 Spill 和 GC 会不会消失

- 怎么做：**不改任何配置**，用和生产相同的参数，只把输入缩到约 1/4，例如加上 `WHERE pmod(mmsi, 4) = 0`，其余代码不变，`shuffle.partitions` 也保持 600。这样每个 task 的数据量大约降到原来的 1/4（反序列化后约 350 MB），能放进每个 task 约 550 MB 的执行内存里。
- 看什么：在 Spark UI 里看这次试跑的 Stage 2 Summary Metrics，重点是 Spill (Memory/Disk)、GC Time、Peak Execution Memory。
- 怎么判断：
  - Spill 基本归零、GC 占比明显回落、单个 task 的耗时下降得比数据量的缩减比例更多，就支持假设 1。
  - 数据量降到 1/4 后仍然大量 Spill、GC 依然很高，说明问题不只是"每个 task 分到的内存太少"，假设 1 要打折扣。
- 补充一个零成本的对照：在 History Server 打开**上周**那次运行，看 Environment 页里 `spark.executor.memory` 是否确实是 16g，以及当时 Stage 2 的 Peak Execution Memory 是否在 1.4 GB 左右。

### 验证假设 2：在 History Server 和 YARN 日志里统计"被杀次数 + 重跑代价 + 被杀时的内存构成"

- 怎么做：
  1. Spark UI / History Server 的 Stages 页：看 Stage 2（以及上游 Stage）有没有多个 attempt、Failed Tasks 有多少、有没有 FetchFailed 引起的上游重算；在 Event Timeline 里看 executor 3 被杀前后的空档和重跑耗时。
  2. Executors 页：看 executor 3 的 Peak JVM Heap、Peak Off-Heap / Direct Pool Memory 等 executor 级内存指标（Spark 3.0+ 有，具体能看到哪些取决于你们是否开启了相关 metrics），对比 4g 堆和 800m overhead。
  3. YARN 侧：`yarn logs -applicationId <appId>` 拉出 NodeManager 和 executor 3 的完整日志，确认被杀时间点前后是否正好在大量溢写或 shuffle fetch。
- 怎么判断：如果重跑累计多花了几分钟甚至十几分钟，而且被杀前堆外/直接内存明显偏高，就支持假设 2；如果只杀了一次、重跑代价很小，它对总耗时的贡献就有限，主要还是假设 1。

### 验证假设 3：对比本周和上周 Scan 节点的读取指标和完整执行计划

- 怎么做：
  1. 对新目录重新执行 `EXPLAIN FORMATTED`，这次看 **Scan parquet ais_points (1)** 节点的完整内容，重点是 `Location`、`PartitionFilters`、`PushedFilters`。确认按天过滤是作为 PartitionFilters 出现的，而不是只在后面的 Filter (2) 里。
  2. 在 History Server 里把本周和上周的 Stage 1（Scan 所在 Stage）放在一起比：number of files read、size of files read、number of output rows、task 数和耗时。
- 怎么判断：读入行数和文件大小与上周差不多（约 +2%），且分区过滤正常下推，就可以基本排除假设 3；如果读入量明显偏多、文件数激增（大量小文件），或分区过滤没有下推，就需要把它提上来重新考虑。

---

## 顺带一个对"倾斜"的快速确认（可选，也是只读）

如果你还是想彻底排除倾斜，可以在当天数据上跑一条只读查询：

```sql
SELECT mmsi, count(*) AS cnt
FROM ais_points
WHERE <当天分区条件>
GROUP BY mmsi
ORDER BY cnt DESC
LIMIT 20;
```

把 Top 20 船的点数和平均每条船的点数比一比。如果最大的一条船也只比平均值高几倍，而且总量不到单个分区（约 200 万条）的一小部分，就基本可以确认这次变慢不是倾斜造成的。

---

建议的顺序：**先做假设 1 的小样本试跑和上周运行的对照**（最可能、成本也最低），同时把假设 2 的被杀和重跑情况统计出来，最后用几分钟排除假设 3。拿到这几组读数后发给我，我们再一起判断要不要找运维讨论内存模板的事。
