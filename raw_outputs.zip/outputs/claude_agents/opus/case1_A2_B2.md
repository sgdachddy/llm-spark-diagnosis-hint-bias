你说是数据倾斜，这个方向是对的：读数显示 Stage 3 卡在单个分区上，不是整体资源不够。不过"倾斜"只说明了它是怎么慢的，还没回答为什么昨天 5 分钟、今天 45 分钟。下面按你的四点要求来写。

---

## ① 现象和关键读数

**一句话：** 400 个 task 里有 399 个在 6–9 秒内跑完，只有 1 个（task 287，在 executor 7 上）跑了 45 分钟。整个 Stage 3 都在等这一个 task。

关键读数：

| 观察 | 读数 | 说明什么 |
|---|---|---|
| Task 时长 | 中位数 8 s，最大 45 min | 一个极端的慢 task，整体分布本身没问题 |
| Shuffle Read | 中位数 21 MB，最大 8.4 GB（约 400 倍） | 一个分区拿到的数据比其他分区多得多 |
| Shuffle Records | 中位数 30 万，最大 1.2 亿 | 同上，按记录数看也一样 |
| Spill | 只有这一个 task 溢写：内存 96 GB，磁盘 38 GB | 这个 task 的数据远超它能分到的内存，排序时反复写盘（日志里至少 12 次，每次约 4 GB） |
| 各 executor | 9 个 executor 读约 0.83 GB；executor 7 读 9.2 GB | 问题只在一个分区上，不是某台机器有问题（其他 39 个 task 在 executor 7 上也只用 16 s） |
| CPU 12%、GC 3%、网络正常 | 集群大部分时间是空闲的 | 不是资源不足；这段时间基本只有一个线程在干活 |
| 推测执行 | 推测副本 287.1 在 executor 3 上启动，后来被 kill | 副本处理的是同一份倾斜数据，所以帮不上忙 |
| 执行计划 | SortMergeJoin，两边都按 `h3_r7` 做 hashpartitioning(400) | 同一个 `h3_r7` 的所有行都会进同一个分区 |
| 配置 | `spark.sql.adaptive.enabled=false`（官方默认是 true） | AQE 被关掉了，所以 skew join 自动拆分也一起失效 |

粗算内存：64 GB 堆内存 × 0.6 ≈ 38 GB 统一内存，由 30 个并发 task 共享，每个 task 约 1.3 GB。要处理 8.4 GB 的 shuffle 数据，大量溢写是必然的。

另外，输入只多了 4%，这个量解释不了 9 倍的耗时增长。

---

## ② 可能的原因（按可能性从高到低）

**假设 A：新模板 job_template_v3.conf 把 AQE 关掉了，于是原本就有的倾斜不再被自动处理。**
Spark 4.0 默认开启 AQE 和 `skewJoin.enabled`，会在运行时把过大的分区拆开。如果昨天的作业还在用旧模板（AQE 开着），这个热点分区可能一直存在，只是被悄悄拆开了，所以只用 5 分钟。今天换成 v3，`adaptive.enabled=false` 明确写在模板里，倾斜就直接暴露出来了。这个假设成立有一个前提：模板切换刚好发生在昨天和今天的两次运行之间。这一点需要核实。

**假设 B：今天出现了一个新的热点 `h3_r7`（或者 key 是空值/哨兵值），数据大量集中到一个格子上。**
例如港口或锚地船舶扎堆，某条船/某台设备高频重复上报，或者有一批坐标异常的点被编码成同一个 h3 值（比如 0、默认值，或者 NULL 被转换后的值）。如果模板在昨天之前就已经换了，这个假设的可能性会排到第一。

**假设 C：join 策略或右表有变化，放大了热点 key 的数据量。**
两种情况：(1) `zone_attr` 本来小于 10 MB 会走广播 join，现在超过阈值（或者 AQE 关闭后没法在运行时转成广播）变成了 SortMergeJoin，热点才开始起作用；(2) `zone_attr` 里热点 `h3_r7` 有重复行，join 之后记录数成倍增加，排序和聚合压力更大。

---

## ③ 验证方法（都是只读操作）

**验证 A：在 Spark History Server 里对比昨天和今天两次运行的 Environment 页。**
看昨天的 `spark.sql.adaptive.enabled`、`spark.sql.adaptive.skewJoin.enabled`，以及是否用了 v3 模板。同时看昨天 Stage 3 的 SQL 页：如果计划里有 `AQEShuffleRead` 或者 skew split 的标记，而且 task 数多于 400，就能说明昨天确实是 AQE 在帮忙拆分。

**验证 B：用小样本只读查询找出热点 key，并和昨天对比。**
```sql
-- 今天和昨天分别跑一次，对比 Top 20
SELECT h3_r7, count(*) AS n
FROM ais_points
WHERE dt = '<今天>'          -- 按你的分区字段改
GROUP BY h3_r7
ORDER BY n DESC
LIMIT 20;

-- 确认哪些 key 落进了 287 号分区（Spark 的 hashpartitioning 用的是 murmur3 hash）
SELECT h3_r7, count(*) AS n
FROM ais_points
WHERE dt = '<今天>' AND pmod(hash(h3_r7), 400) = 287
GROUP BY h3_r7 ORDER BY n DESC LIMIT 10;
```
如果 Top 1 的 key 有接近 1 亿条记录，就再看它是不是 NULL/0 之类的异常值，以及这些记录集中在哪些 `mmsi` 上。

**验证 C：对比两天的物理计划，并检查右表。**
在 History Server 的 SQL 页看昨天的 join 是 `BroadcastHashJoin` 还是 `SortMergeJoin`。再对 `zone_attr` 跑 `SELECT count(*), count(DISTINCT h3_r7) FROM zone_attr`（两个数不相等就说明有重复 key），并看它的文件大小是否超过 10 MB。

---

## ④ 说明

以上都是根据你给的材料提出的假设，**还不是结论**。我没有建议改任何配置。等 A/B/C 的验证结果出来，再决定是恢复 AQE、处理热点 key，还是调整 join 策略。建议先做验证 A，它只需要在 UI 上看两页，最快能把 A 和 B 的排序定下来。你把结果发给我，我们再往下看。
