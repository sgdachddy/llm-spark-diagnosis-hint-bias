看完材料，我的结论是：**这次变慢不是数据倾斜，而是 executor 内存从 16g 降到 4g 导致的内存不足**。表现为大量 spill、GC 飙升，部分 container 超出 YARN 物理内存上限被杀掉。下面是依据和处理建议。

---

## 一、为什么不是数据倾斜

数据倾斜的典型特征是少数 task 或 executor 明显比其他的大、慢，Max 远大于 Median。你的数据正好相反，非常均匀：

| 指标（Stage 2，600 个 task） | Median | Max | Max / Median |
|---|---|---|---|
| Shuffle Read Size | 181 MB | 197 MB | ≈ 1.09 |
| Shuffle Read Records | 203 万 | 221 万 | ≈ 1.09 |
| Duration | 3.4 min | 4.5 min | ≈ 1.3 |

- 按 executor 看，16 个 executor 的 Task Time（2.2–2.4 h）和 Spill（51–54 GB）也都差不多。
- 如果某些 mmsi 特别大，应该会有个别 task 读到几 GB、跑几十分钟，这里没有出现。
- 输入只增加了 2%，不可能让耗时变成原来的 3 倍。

所以问题不在于"某几个分区太大"，而是**每个 task 都慢了，而且慢的程度差不多**。这说明是所有 task 共有的资源条件变了，也就是内存。

## 二、真正的原因：每个 task 能用的执行内存太少

**1. 算一下每个 task 能拿到多少内存**

Spark 统一内存 ≈ (堆内存 − 300 MB) × spark.memory.fraction，由同一 executor 上并发的 4 个 task 共享：

| | 上周（16g） | 本周（4g） |
|---|---|---|
| 统一内存（execution + storage） | (16384−300)×0.6 ≈ **9.4 GB** | (4096−300)×0.6 ≈ **2.2 GB** |
| 4 个并发 task，每个大约能用 | ~2.4 GB | **~0.55 GB**（下限约 0.28 GB） |
| 每个 task 排序需要的内存（Spill Memory 中位数） | 1.4 GB，放得下，所以 Spill = 0 | 1.4 GB，放不下，**必须 spill** |

Window 前的 Sort 要把每个分区约 200 万条轨迹点在内存里排好序。本周内存只有需求的约 1/3，于是：

- **反复溢写磁盘**：日志里 `spilling sort data ... (7 times so far)`、`(9 times so far)` 就是这个，每个 task 都要多次 spill 再归并，Stage 2 的 Median Duration 从 1.1 min 涨到 3.4 min。
- **GC 压力暴增**：堆很小、对象又多，GC 占比从 3% 涨到 19%（单个 task GC 21–58 s）。CPU 利用率 83% 里有相当一部分花在 GC 和序列化/反序列化上，不是有效计算。
- **申请内存页失败**：`Failed to allocate a page (67108864 bytes), try again` 说明 64 MB 的页都很难申请到。

**2. 为什么 executor 会被 YARN 杀掉**

container 上限 = executor.memory 4g + memoryOverhead 800m ≈ **4.8 GB**，日志显示用了 4.9 GB。频繁 spill 和归并会用到不少堆外内存（Netty shuffle buffer、压缩/解压缓冲、文件句柄、线程栈等），800m 的 overhead 撑不住，于是超限被杀。被杀之后 task 重跑，又进一步拉长了总耗时。

**3. 时间对得上**

600 个 task ÷ 64 个并发槽 ≈ 9.4 轮：
- 上周：9.4 × 1.1 min ≈ 10 min
- 本周：9.4 × 3.4 min ≈ 32 min，再加上 executor 被杀后的重跑和其他 stage 也变慢，总耗时到 58 min 是合理的。

## 三、为什么按倾斜的思路处理不会有用

- **AQE 的倾斜处理管不到这里**：`spark.sql.adaptive.skewJoin.enabled` 只拆分 sort-merge / shuffled hash **join** 中的倾斜分区。你的执行计划是 `Exchange → Sort → Window`，没有 join，这个开关不起作用。何况本来就没有倾斜。
- **加盐（salting）不适合这个作业**：航段切分要求同一艘船的轨迹点在同一个分区内按时间连续排序。给 mmsi 加盐会把一艘船拆到多个分区，破坏切分逻辑，还得再做一次合并。
- **调 autoBroadcastJoinThreshold 也无关**：没有 join。

## 四、建议的处理方式（按优先级）

**方案 A（最直接）：把内存调回去**

和运维沟通，把这个作业单独设回原来的配置，不受组里默认模板影响：

```
spark.executor.memory=16g            # 至少 10–12g；上周 16g 时 Spill 为 0
spark.executor.memoryOverhead=2g     # 或保持默认（max(384m, 10%)）以上
```

这个作业天然要按船整组排序，"节省"下来的内存最后变成了 3 倍的运行时间和 CPU 时长，未必真的省钱。可以拿上周和本周的 vcore·小时、内存·小时给运维算一笔账。

**方案 B（如果内存必须控制在较低水平）：让每个 task 处理更少的数据**

1. **加 shuffle 分区数**，让每个分区的排序数据能放进内存：
   ```
   spark.sql.shuffle.partitions=2400    # 约 4 倍，每个 task 约 45 MB / 50 万条
   ```
   注意 AQE 默认会合并小分区（`spark.sql.adaptive.coalescePartitions.enabled=true`），可能又把分区合并回去。可以同时把 `spark.sql.adaptive.advisoryPartitionSizeInBytes` 设小一些（比如 32m），或者针对这个 stage 关掉合并。
2. **降低每个 executor 的并发**，让每个 task 分到更多内存，比如 `spark.executor.cores=2`（内存不变，每个 task 能用的执行内存翻倍；要保持总并行度，就相应增加 executor 数量）。
3. **加大 memoryOverhead**，至少 1.5–2g，先解决被 YARN 杀掉的问题。
4. （可选）调高 `spark.memory.fraction` 到 0.7–0.75，前提是作业里没有大量用户对象或 UDF 占用堆内存。

折中参考：`executor.memory=8g, memoryOverhead=2g, executor.cores=4, shuffle.partitions=1200`。

**顺手检查一下：新分区目录有没有正确裁剪**

本周换了按天分区的新目录结构。执行计划里 Scan 后面有一个独立的 `Filter (2)`，建议看一下 EXPLAIN FORMATTED 中 Scan 节点的 `PartitionFilters` 是否非空，确认只读了当天的分区，而不是全量扫描后再过滤。不过输入量只增加 2%，看起来裁剪大概率没问题，这只是排除一个隐患。

## 五、怎么验证

改完后重跑，对比 Stage 2 的这几项：
- **Spill (Memory/Disk) 接近 0**，日志里不再有 `spilling sort data` 和 `Failed to allocate a page`；
- **GC Time 占比回到 5% 以下**；
- **Median Duration 回到约 1 min**（如果加了分区，单个 task 更短）；
- 不再出现 `Container killed by YARN for exceeding physical memory limits`。

如果这些都恢复了，作业应该能回到 20 分钟左右。如果之后真遇到个别巨型船舶（mmsi 异常、AIS 测试设备等）造成长尾，Summary Metrics 里会表现为 Max 远大于 Median，那时再单独处理倾斜。
