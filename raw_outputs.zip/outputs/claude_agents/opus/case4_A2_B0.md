我看了你给的材料。下面按你的四点要求来，所有判断都还是待验证的假设，不是结论。

## ① 现象和关键读数

**现象**：`ais_track_segments` 从约 20 min 变成约 58 min，大约慢了 3 倍，偶尔有 executor 被 YARN 杀掉后重跑。本周有三处变化：executor 内存 16g → 4g、输入目录结构变了、数据量 +2%。

**关键读数**：

- **慢在 Stage 2（排序与切分）**：task 中位时长从 1.1 min 涨到 3.4 min，约 3 倍，和整体变慢的幅度对得上。
- **Spill 从无到有**：上周 Spill 全为 0。本周每个 task 平均溢写约 1.4 GB（内存侧）/ 0.55 GB（磁盘侧），16 个 executor 每个都在 50 GB 左右。日志里同一线程会反复溢写（"7 times so far"、"9 times so far"），还有申请 64 MB 内存页失败的告警。
- **GC 明显变重**：GC 占 task 时间从约 3% 涨到 19%，单个 task 的 GC 在 21–58 s 之间。
- **数据分布很均匀，看不出倾斜**：600 个 task 的 shuffle 读取量在 168–197 MB 之间，最大值只比中位数高约 9%；各 executor 的读数也相近。拖慢的不是个别大 key，而是所有 task 一起变慢。
- **被杀的原因写得很清楚**：`4.9 GB of 4.8 GB physical memory used`。容器上限 = 4g 堆 + 800m overhead ≈ 4.8 GB，进程实际占用超了一点点。
- **执行计划很简单**：Scan → Filter → 按 mmsi hash 分成 600 个分区 → Sort → Window，里面没有 join。

顺手估一下内存（只是估算）：4g 堆、`memory.fraction=0.6` 时，execution + storage 可用约 (4096−300)×0.6 ≈ 2.2 GB，4 个核分下来每个 task 约 550 MB。每个 task 的数据在内存里展开后大约 1.4 GB（看 Spill (Memory) 的量级），放不下，只能多次溢写。按 16g 算，每个 task 约 2.4 GB，大致放得下，这和"上周 Spill 为 0"吻合。

## ② 可能的原因（按可能性从高到低）

**假设 1（最可能）：executor 内存从 16g 降到 4g，排序装不下内存，导致大量溢写和 GC。**
理由：时间上正好吻合；所有 task 均匀变慢，像是资源普遍不够，不像个别数据有问题；Spill 从 0 变成每个 task 1.4 GB；GC 占比从 3% 涨到 19%；上面的估算也对得上。数据只多了 2%，解释不了 3 倍的变慢。

**假设 2：堆外内存/overhead 不够，进程总内存超出容器上限被 YARN 杀掉，重跑又拖长了时间。**
这和假设 1 同源，机制不同。被杀是因为物理内存（堆 + 堆外，比如 shuffle/netty 缓冲区、溢写文件的 IO 缓冲、JVM 自身开销）超过了 4.8 GB，不是堆内 OOM。频繁溢写和 shuffle 会抬高堆外占用。它主要解释"偶发被杀和重跑"，单靠它解释不了每个 task 都慢 3 倍。

**假设 3（可能性较低）：新分区目录导致读取阶段变差，比如分区裁剪失效、小文件变多。**
理由：计划里 Filter 是单独的算子，要确认分区条件有没有下推成 PartitionFilters。如果目录结构变化让 Spark 识别不出分区列，就可能扫描比当天更多的数据再过滤，或者文件数量暴增。不过 Stage 2 的 shuffle 读取量和"数据 +2%"大体一致，所以它最多只能解释一部分变慢（主要在 Scan 所在的 Stage），不太可能是主因。

另外说明一点：材料里提到的 `skewJoin`、`autoBroadcastJoinThreshold` 和这个作业基本无关。计划里没有 join，数据也不倾斜，不建议往这个方向查。

## ③ 每个假设的验证动作（都是只读操作）

**验证假设 1**：在 Spark History Server 里把上周和本周的这个作业并排对比。
- 在 Environment 页确认上周 `spark.executor.memory` 确实是 16g，其他配置（`shuffle.partitions`、`memory.fraction`、`cores` 等）没变。
- 在 Stage 2 的 task 指标里对比 Peak Execution Memory、Spill、GC Time。
- 预期：如果上周 16g、无 Spill、每个 task 的峰值执行内存在 1.4 GB 左右（高于本周约 550 MB 的可用量），配置之外的读数也基本一致，假设 1 就基本成立。如果上周的内存其实也不高，就要回头怀疑别的因素。

**验证假设 2**：查被杀的 executor 3 的内存峰值构成。
- 通过 Executors 页或 REST API（`/api/v1/applications/<app-id>/executors`）查看 peakMemoryMetrics 里的 `JVMHeapMemory`、`JVMOffHeapMemory`、`DirectPoolMemory`、`ProcessTreeJVMRSSMemory`。
- 结合 NodeManager 日志里被杀前后的时间点一起看。
- 预期：如果 RSS 逼近 4.8 GB 而堆内没满，主要多出来的是堆外/direct 内存，就支持"overhead 不够"这条机制。

**验证假设 3**：查看 Scan 节点的详情。
- 在 `EXPLAIN FORMATTED` 完整输出里看第 (1) 个节点 `Scan parquet ais_points` 的 `PartitionFilters` 是否带有日期条件（而不是空的 `[]`），`Location` 指向的是不是单日目录。
- 在 Spark UI 的 SQL 页对比本周和上周 Scan 节点的 "number of files read"、"size of files read"、"number of partitions read"。
- 预期：如果分区裁剪正常、文件数和读取量与上周相当（+2% 左右），就可以排除假设 3。

## ④ 说明

- 以上都只是排序后的假设，我没有下结论，也没建议改任何集群或作业配置。
- 三个验证都只需要看 History Server、执行计划和日志，不需要重跑。如果之后想做对照实验（比如用小样本、不同内存跑一次），建议先和运维确认，不要直接改课题组的默认模板。
- 如果方便，可以把上周同一作业 Environment 页的配置截图和 Stage 2 的 Summary Metrics 发我，我帮你逐项对比。
