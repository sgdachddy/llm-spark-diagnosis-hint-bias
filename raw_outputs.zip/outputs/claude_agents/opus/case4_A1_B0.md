先说结论：这次变慢不是数据倾斜，也不是数据量变化。根因是 executor 内存从 16g 降到 4g，排序阶段每个 task 分到的执行内存太少，于是大量 spill 到磁盘，GC 也跟着变重。被 YARN 杀掉是同一件事的另一面：容器总内存（4g 堆 + 800m overhead）不够用。

## 一、逐项排除

**1. 数据倾斜：可以排除**
- Stage 2 的 600 个 task 分布非常均匀：Shuffle Read 从 168 MB 到 197 MB，Max/Median 约 1.09；记录数 190 万到 221 万；Duration 2.6 到 4.5 min。真有倾斜的话，Max 通常是中位数的几倍甚至几十倍。
- 各 executor 的 Task Time 和 Spill 也很接近（2.2 到 2.4 h，51 到 54 GB），不存在某台机器特别慢。
- 所以 `spark.sql.adaptive.skewJoin.enabled` 帮不上忙。另外它只处理 sort-merge / shuffled hash join 里的倾斜分区，你的计划是 `Exchange -> Sort -> Window`，没有 join，本来就用不到。`autoBroadcastJoinThreshold` 同理，和本作业无关。

**2. 输入量 +2%：可以排除**
2% 的数据增长解释不了 3 倍的耗时，也解释不了 spill 从 0 变成每个 task 0.55 GB。

**3. 新分区目录：大概率无关，但建议花一分钟确认**
你说数据内容不变。可以对比一下上周和本周 Stage 1（Scan）的 Input Size / Records，确认分区裁剪生效、没有多读其他日期的目录。只要两周的数字接近，这项就可以排除。

## 二、根因：内存从 16g 降到 4g

**算一下每个 task 实际能用多少执行内存**（统一内存 = (堆 - 300MB) × `spark.memory.fraction`）：

| | 16g（上周） | 4g（本周） |
|---|---|---|
| 统一内存 (execution + storage) | (16384 - 300) × 0.6 ≈ 9.4 GB | (4096 - 300) × 0.6 ≈ 2.2 GB |
| 4 个并发 task，每个约 | ≈ 2.4 GB | ≈ 550 MB |

再看每个 task 要排多少数据：Spill (Memory) 中位数 1.4 GB，也就是 181 MB 压缩后的 shuffle 数据反序列化到内存里大约 1.4 GB。

- 上周每个 task 有约 2.4 GB，1.4 GB 放得下，所以 Spill = 0，中位时长 1.1 min。
- 本周只有约 550 MB，放不下，只能反复溢写再归并。日志里的 `spilling sort data of 412.0 MB to disk (7 times so far)` 正好对应：每攒到约 400 MB（就是这个 task 能拿到的份额）就溢写一次。`Failed to allocate a page (64MB)` 也说明执行内存已经抢不到了。
- 堆这么小、对象这么多，GC 占比从 3% 升到 19%，也就顺理成章了。

**被 YARN 杀掉的原因：**
`Container killed ... 4.9 GB of 4.8 GB physical memory used`。容器上限 = 4g 堆 + 800m overhead = 4.8 GB。频繁 spill 和归并会占用额外的堆外内存（shuffle 的 Netty 缓冲区、溢写文件 I/O 缓冲、JVM 元空间和线程栈等），800m 的 overhead 顶不住，偶尔就超限被杀。被杀之后 task 要重跑，耗时又被拉长一截。

**整条因果链：**
4g 内存 → 每个 task 执行内存约 550 MB < 需要的约 1.4 GB → 大量 spill + GC 升高 → Stage 2 单个 task 从 1.1 min 变成 3.4 min → 作业从 20 min 变成 58 min；同时堆外压力大 → 偶发被 YARN 杀 → 重跑，进一步变慢。

## 三、怎么修（按推荐顺序）

**方案 A（最简单，推荐）：在这个作业里单独把内存调回去**
不用改课题组模板，在作业的提交参数里覆盖：
```
spark.executor.memory=12g        # 每个 task 约 1.75 GB，已能装下约 1.4 GB；16g 更稳
spark.executor.memoryOverhead=1536m
```
从成本上看，4g 跑 58 min 不一定比 16g 跑 20 min 省钱：CPU 核被占用的时间是原来的 3 倍，内存·时间也只省了约 30%，再算上重跑，省下的很有限。可以拿这组数字和运维沟通，给这类排序/窗口型作业留个例外。

**方案 B：必须守住 4g 的话，就让每个 task 处理的数据变少**
```
spark.sql.shuffle.partitions=2400              # 每个 task 约 45 MB shuffle 数据，内存中约 350 MB，可落在约 550 MB 份额内
spark.executor.memoryOverhead=1536m            # 必须加，否则仍可能被 YARN 杀
spark.sql.adaptive.advisoryPartitionSizeInBytes=32m   # 防止 AQE 把小分区又合并回大分区
```
注意：AQE 默认开启分区合并（coalescePartitions），目标大小默认 64 MB，可能把你拆小的分区又合回去。所以要么像上面这样调低 advisory 大小，要么对这个作业关掉 `spark.sql.adaptive.coalescePartitions.enabled`。

**方案 C：降低每个 executor 的并发**
`spark.executor.cores=2`（实例数相应翻倍到 32，总核数不变），每个 task 分到的内存翻倍到约 1.1 GB。可以和方案 B 组合使用。

**不建议的做法：**
- 调大 `spark.memory.fraction`：4g 堆里本来就没有多少余量，调大后用户对象和 JVM 本身更紧张，GC 可能更糟。
- 开启或调整 skew 相关参数：没有倾斜，也没有 join，用不上。

## 四、验证方法

改完重跑，在 Spark UI 的 Stage 2 里看三项：
1. Spill (Memory / Disk) 回到 0 或接近 0；
2. GC Time 占比回到 5% 以下；
3. Duration 中位数回到约 1 min 左右，并且不再出现 YARN kill 日志。

三项都恢复，作业整体耗时应该能回到 20 min 左右。如果改完仍有少量 spill，按同样的思路再加一点内存或再多切一些分区即可。
