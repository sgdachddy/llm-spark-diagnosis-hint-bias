# ais_vessel_features 变慢：现象复述与排查思路

## ① 现象复述（人话版）

- 作业从上周约 18 min 变成本周约 31 min，没有报错。
- 本周新增的 `feat.persist(MEMORY_AND_DISK)` 加上 `feat.count()`，变成了一个额外的 Job 0，单独花了 9.5 min。
- Job 1–3 本周合计 21.5 min，上周合计约 17.9 min，多出约 3.6 min。
- 总增量约 13 min，其中约 9.5 min 来自物化缓存这一步，其余约 3.6 min 来自三个下游 Job 都变慢了一些。

关键读数：

- **缓存没有真正留在内存里**：Storage 页显示 feat 共约 40 GB，只有 10.2 GB 在内存，约 29.8 GB 落到磁盘。
- **Job 2 出现大量 spill**：每个 task 的内存 spill 约 0.6–1.4 GB，磁盘 spill 约 0.2–0.5 GB，而上周同一 Stage 的 spill 全为 0。但每个 task 的 shuffle read 只有约 92–121 MB，spill 量是 shuffle 数据量的约十倍。
- **资源在等 IO，而不是在算**：CPU 整体利用率只有 34%，磁盘 IO wait 从约 5% 升到 28%，GC 只占 6%。
- **数据本身没有明显问题**：输入只增加 3%，各 task 的 shuffle read 分布很集中（中位 104 MB，最大 121 MB），看不出数据倾斜。

一句话概括：作业变慢主要来自缓存的物化成本，加上缓存落盘后反复读盘、内存被挤占导致的 spill，CPU 大部分时间是空闲的。

## ② 可能原因（按可能性从高到低）

### 假设 1（最可能）：feat 缓存挤占内存，导致落盘与 spill 放大

依据：

- 本周唯一明显的代码改动就是 persist，而它对应的 Job 0 就多出 9.5 min。
- 上周没有 spill，本周有；IO wait 同步升高。
- Storage 页显示大部分缓存落盘，下游三个 Job 每次都要从本地磁盘读回并反序列化。
- 这个假设能够解释时间账：上周 17.9 min 加上物化的 9.5 min，加上下游 Job 的小幅变慢，基本对得上 31 min。
- 有一个疑点需要确认：按默认内存参数粗算（24g 堆、`spark.memory.fraction=0.6`、storage 默认保证 50%），每个 executor 的 storage 区域应有约 7 GB 左右，而每个 executor 实际分到的缓存数据只有约 4 GB。理论上不应大量落盘。因此需要查清是什么占用了内存，例如其他缓存、广播变量、执行内存，或者 executor 实际堆大小与配置不一致。

可执行的验证动作（只读或小样本）：

- 在 Spark UI 的 Executors 页看每个 executor 的 Storage Memory 与 Disk Used 峰值，并在 executor 日志里搜索 `evicted`、`dropped`、`Not enough space to cache` 等警告。
- 用同一输入的小样本（例如一天的数据或 1/10 的数据），分别以“保留 persist”和“去掉 persist”各跑一次，对比 Job 1–3 的时长、Spill 指标和 IO wait。这只是在隔离的小作业上做对照，不修改集群配置。

### 假设 2：停泊时长（Job 2）的聚合本身产生大状态，导致 spill

依据：

- Job 2 是三个下游 Job 里变慢最明显的一个（7.6 min 对 5.8 min），在增量中占比最大。
- shuffle read 每个 task 只有约 100 MB，内存 spill 却约 1 GB，说明 task 内部的聚合状态（哈希表、排序缓冲）膨胀了约十倍。这种膨胀通常来自 `collect_list`、窗口函数、高基数键上的聚合，或者全量排序，而不是数据量本身的增长。
- 它可能与假设 1 叠加：同样的执行内存既要给聚合用，又被缓存占着。

可执行的验证动作（只读）：

- 阅读 `berth_time` 的代码，确认是否有 `collect_list` / `collect_set`、Window，或按 mmsi、h3 做的全量 sort 之类会在内存中累积数据的操作。
- 在 SQL 页打开 Job 2 的执行计划，查看 HashAggregate、Sort 节点的 peak memory 与 spill size 指标，并与 Job 1、Job 3 的对应节点对比，看溢出是否只集中在 Job 2。
- 对 feat 取一个小样本，用 `approx_count_distinct` 估计分组键的基数，粗略判断每个 task 的状态大小。

### 假设 3（可能性较低）：h3 小版本升级影响了 Python 侧计算

依据：

- Job 1 和 Job 3 也各慢约 1 min。如果 `speed_dist`、`lane_density` 的 Python UDF 里调用了 h3，升级后的函数行为或性能变化可能带来额外开销。

不支持该假设的证据：

- `h3_r7` 是上游预先算好写入 parquet 的，本作业未必调用 h3 计算（需要看代码确认）。
- 最大的增量（Job 0，9.5 min）只是读取、过滤和物化，不涉及 h3 逻辑，h3 升级无法解释它。
- CPU 利用率只有 34%，更像 IO 瓶颈，而不是 Python 侧 CPU 瓶颈。

可执行的验证动作（隔离环境，不动生产集群）：

- 在单独的虚拟环境里分别安装旧版和新版 h3，对同一份 1000 行样本跑相关 UDF，比较输出是否一致、耗时是否有差异。
- 用 grep 在三个计算函数里查找 h3 的调用位置。

## 补充说明

- 配置里的 AQE、skewJoin、`autoBroadcastJoinThreshold` 等默认值，对本作业影响很小：执行计划中没有 join，且 shuffle 分区未见倾斜。
- 目前只有读数，没有对照实验，以上都是假设，不是结论。
- 不改动集群的前提下，最优先的动作是：先查看 executor 的 storage 与 disk 使用情况和 eviction 日志，再做一次有无 persist 的小样本对照。如果去掉 persist 后总时长接近 18 min，就可以基本确认假设 1。
