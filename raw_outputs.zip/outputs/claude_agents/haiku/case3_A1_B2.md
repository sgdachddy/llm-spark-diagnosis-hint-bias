## 初步判断

你的怀疑基本成立。最可能的直接原因是：zone_attr_v2 被优化器估计为小表（8.2 MiB，低于 10MB 的广播阈值）而走了 BroadcastHashJoin，但它的实际体积远大于这个估计，在构建广播哈希表时发生 OOM。

依据如下：

1. 附 3 的物理计划中，zone_attr_v2 位于 BroadcastExchange 一侧，join 类型是 BroadcastHashJoin。
2. 附 4 的估计值是 sizeInBytes=8.2 MiB，而附 6 显示同一个表在 S3 上共 6 个对象、合计 1.8 GiB。两者相差约 220 倍。仅凭材料无法判断 8.2 MiB 的来源，但它与实际存储体积明显不符。
3. 附 5 的 DESCRIBE 输出没有 Statistics 行，说明目录中没有可靠的表级统计信息，优化器的估计并不可靠。
4. 附 7 的配置与官方默认值一致，阈值没有被改动。作业代码也没变。因此变化来自输入表本身，即昨天的替换。附 5 的创建时间（11 月 17 日 23:41）与这个时间点吻合。
5. 附 2 显示失败前 61 个 task 的耗时集中在 41 s 到 1.2 min，Spill 全部为 0，没有数据倾斜或 shuffle 溢写的迹象。这更像是广播侧的内存问题，而不是 join 分区倾斜。AQE 的 skewJoin 只处理 sort-merge 和 shuffled hash join，对广播 join 不起作用。另外，AQE 的运行时重新规划依赖 shuffle 阶段的实际数据量，而这里的广播是由静态估计决定的，所以错误的估计没有被 AQE 纠正。

内存粗算：16 GB 的 executor 在默认 spark.memory.fraction=0.6 下，统一内存约为 (16384 - 300) × 0.6 ≈ 9.4 GiB，需要在 execution 与 storage 之间共享，8 个核的 task 也共用这部分内存。广播表在内存中的哈希表形式通常比磁盘上的 parquet 大得多（解压、对象与哈希结构的开销、较长的 WKT 字符串都会增加体积）。1.8 GiB 的 parquet 很可能膨胀到数 GB，这是一个估算，需要用 Spark UI 中 broadcast 的数据量来确认。

需要注意的一点：广播表的哈希关系通常是在 driver 端构建的（BroadcastExchangeExec 先把构建侧数据收集到 driver，再建表并广播）。如果是这样，OOM 发生在 driver 上，单纯调大 executor 内存无效。附 7 的配置中没有 spark.driver.memory，需要确认。你贴的栈写的是 executor 9 退出，两种可能都要排查。

## 建议的处理顺序

立即止血（只改配置，不改代码）：
- 对这个作业禁用广播，设置 spark.sql.autoBroadcastJoinThreshold=-1；或者在该 join 的 SQL 中加 MERGE 或 SHUFFLE_MERGE hint，让它改走 sort-merge join。内存压力会转移到 shuffle 上，但不再需要把整张表放进单个进程。
- 用新配置重跑一次，观察 join 阶段的 shuffle 数据量和耗时。

修正统计信息：
- 执行 ANALYZE TABLE ocean.zone_attr_v2 COMPUTE STATISTICS（需要列级统计时加 FOR ALL COLUMNS），再看 EXPLAIN COST 中的 sizeInBytes 是否接近 1.8 GiB。之后优化器应该会自动选择 sort-merge join。不要依赖 8.2 MiB 这个数字。

从源头减小构建侧：
- 在 join 前只 select 需要的列。如果 geom_wkt 或 attrs 很大，而这次 join 只需要 zone_id 和少数属性，可以把几何字段拆到单独的表，只在需要时再关联。
- 对比旧表 zone_attr 的体积和行数，与 zone_attr_v2 的行数、geom_wkt 的平均长度做对照。如果旧表小于 10MB，那么替换后的体积增长就是根本原因，需要和上游脚本确认：是否出现了重复行、多版本数据，或几何字段的精度和长度变化。这一点只是推测，需要数据确认。

如果以上都不适用，才考虑保留广播：确认 OOM 发生在哪个进程后，调大对应的内存（driver 端调 spark.driver.memory，executor 端调 spark.executor.memory），并把阈值设到能覆盖真实体积的水平。这种做法代价较高，不建议作为首选。

## 还需要的信息

- 旧表 zone_attr 的 DESCRIBE EXTENDED 输出和 S3 体积，用于确认增长倍数
- zone_attr_v2 的行数
- Spark UI 的 SQL 页面中 BroadcastExchange 节点的 data size 与 build time
- driver 日志中 OOM 具体发生在哪个进程，以及 spark.driver.memory 的值
- 完整的 DESCRIBE EXTENDED 输出，用于确认 8.2 MiB 的来源

说明：以上分析只基于你提供的节选材料。我没有访问集群，也没有运行任何命令。文中的数字是根据材料计算和推断的，最终结论需要用上面列出的信息验证。
