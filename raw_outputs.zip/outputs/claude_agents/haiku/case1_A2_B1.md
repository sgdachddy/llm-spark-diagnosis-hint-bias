从读数看，这更像是数据倾斜（一个超大分区拖住了整个 stage），而不是整个集群内存不够。

## 一、现象复述

- 作业变慢主要来自 Stage 3：今天 45 分钟，昨天 5 分钟，整个作业以前约 15 分钟跑完。
- Stage 3 共 400 个 task，其中 399 个都在 6 到 9 秒内完成（中位数 8 秒），只有 1 个 task 跑了 45 分钟。
- 这个慢 task 所在的 executor 7 读取了 8.4 GB 的 shuffle 数据、约 1.2 亿条记录。中位数只有约 21 MB、30 万条，所以它的数据量约为中位数的 400 倍。它发生了 96 GB 内存 spill 和 38 GB 磁盘 spill。其他 task 基本没有 spill，只有 executor 5 有 0.1 GB 的少量内存 spill。
- 日志里，task 287 反复 spill 约 4 GB 的排序数据，共 12 次。推测执行启动的副本没有更快，最后原 task 完成，副本被杀。
- 集群层面：CPU 整体利用率只有 12%，网络正常无丢包，GC 只占 task 时间的 3%，输入数据只增加了 4%。这些读数都不指向"集群整体资源不足"。

## 二、可能原因（按可能性从高到低）

### 假设 1：h3_r7 连接键存在热点（数据倾斜）

理由：只有一个 shuffle 分区的数据量远大于其他分区，并且只有这一个 task 大量 spill。这符合某个格子的数据极度集中的特征，例如港口或锚地附近的船位点密集。其余 399 个 task 都很快，也符合"单个长尾 task 拖慢整个 stage"的模式。

验证动作（只读聚合）：在 ais_points 上按当天分区统计各格子的行数，看前 20 名占比：

```sql
SELECT h3_r7, count(*) AS n FROM ais_points WHERE <当天分区条件> GROUP BY h3_r7 ORDER BY n DESC LIMIT 20
```

如果头部少数格子占了大部分行数，即可确认。同时检查 zone_attr 中是否有同一个 h3_r7 对应多行：

```sql
SELECT h3_r7, count(*) AS c FROM zone_attr GROUP BY h3_r7 HAVING count(*) > 1 LIMIT 20
```

如果有重复，join 会产生行数膨胀，同样会造成这种热点。

### 假设 2：新模板 job_template_v3.conf 改变了生效配置，关闭了 AQE，且 zone_attr 没有走广播

理由：附 5 显示 `spark.sql.adaptive.enabled=false`。Spark 4.0 的默认值是开启的，而 AQE 下的 `spark.sql.adaptive.skewJoin.enabled`（默认开启）正是用来自动拆分倾斜分区的。如果它被关闭，这一兜底机制就失效了。另外，执行计划中 zone_attr 走的是 SortMergeJoin（Exchange 6 与 Sort 7），没有 BroadcastHashJoin。如果 zone_attr 的实际大小低于 `spark.sql.autoBroadcastJoinThreshold`（默认 10 MB），广播即可避免对 ais_points 的 shuffle，从而绕开热点。附 5 没有列出该参数，因此它很可能是默认值，但需要确认模板中是否被改动过。

验证动作（只读）：
- 在 Spark UI 的 Environment 页确认 `spark.sql.adaptive.enabled` 与 `spark.sql.autoBroadcastJoinThreshold` 的实际生效值，而不只看提交参数的写法。
- 对比昨天与今天的提交配置，以及 job_template_v3.conf 的差异。
- 查看 zone_attr 在存储上的总大小（parquet 文件大小之和，或 `DESCRIBE EXTENDED zone_attr` 中的统计信息），判断是否低于 10 MB。

### 假设 3：单个 task 的内存份额偏小，超大分区必然 spill（全局内存不足的可能性较低）

理由：每个 executor 为 64 GB、30 核。按默认 `spark.memory.fraction`=0.6 估算，统一内存约为 (64 GB - 300 MB) × 0.6 ≈ 38 GB，由 30 个并发 task 分摊，平均每个 task 的 execution 内存只有 1.2 到 1.3 GB 左右。其余 399 个 task 只有约 20 MB 的 shuffle 数据，完全不 spill，说明普通 task 并不缺内存；只有超大分区才会超出这点份额。因此"内存不够"更像是"某个 task 装不下"的结果。这一假设排第三，是因为它通常是假设 1 成立时的表现，而不是独立的根因。

验证动作（只读）：在 Stage 3 页面查看其他 task 的 Peak Execution Memory，如果都远低于约 1.2 GB，就说明全局内存并不紧张。也可以查看 executor 7 的 GC 与内存曲线。如需试跑，可在独立的测试提交里，对当天的一小部分数据（例如单个 h3_r7 前缀区域）运行同样的 SQL，比较 spill 量。不要修改生产提交参数。

## 三、补充说明

- `spark.speculation=true` 对这类数据倾斜基本无效，因为副本处理的是同一个大分区，所以那个 45 分钟的 task 并没有被提前替换。这不是根因，但值得留意。
- 在确认热点之前，不建议直接调大 executor 内存。增加内存未必能解决问题，还会改变资源占用。
- 以上都是基于现有读数的假设。在看到 ais_points 的 key 分布和实际生效配置之前，不能下结论。
