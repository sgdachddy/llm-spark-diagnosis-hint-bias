# Spark 作业 ais_port_events 失败排查

## ① 现象与关键读数（人话版）

- 今天的作业在 join 阶段失败：多个 executor 先后退出，重试 4 次后整个作业被终止。昨天同一作业约 12 分钟跑完。
- 唯一的已知改动是上游把 zone_attr 换成了 zone_attr_v2，作业代码没有动。
- 报错落在 BroadcastHashJoin 的广播构建路径上（HashedRelation、BroadcastExchange），写的是 Java heap space OOM，同时也写了心跳超时。心跳超时通常是 GC 长停顿的后果，不一定是独立原因。
- 失败前已完成的 61 个 task 看起来正常：每个 task 输入约 118 到 131 MB，耗时中位数 52 秒，没有 spill。这说明 ais_points 的大部分数据本身并不是明显问题。
- 有几个读数互相矛盾，值得重点核对：
  - 优化器估计 zone_attr_v2 只有 8.2 MiB（附 4），低于 autoBroadcastJoinThreshold=10MB，所以选择了广播。
  - 但 S3 上这张表的实际大小是 1.8 GiB、6 个对象（附 6），与估计值相差约 225 倍。
  - DESCRIBE 输出里没有 Statistics 行（附 5），说明 8.2 MiB 并不是来自元数据统计。这个数字的来源目前不清楚。

所以"内存不够"更像是症状。更具体的说法是：一张估计上很小、实际上很大的表被当成了广播表。

## ② 可能原因（按可能性从高到低）

1. **广播表实际远大于优化器的估计（最可能）**
   优化器认为 zone_attr_v2 不到 10 MB，于是选用 BroadcastHashJoin。1.8 GiB 的 parquet 在内存中展开成哈希表后会更大，在 executor 上构建时就 OOM。附 3 的计划和附 1 的 HashedRelation 调用栈与这一解释吻合。AQE 的 skewJoin 只作用于 sort-merge 和 shuffled hash join 的倾斜分区，对广播 join 不起作用，所以 AQE 不会自动兜底。
   验证动作（只读）：执行 `SELECT count(*), count(DISTINCT zone_id), avg(length(geom_wkt)), max(length(geom_wkt)) FROM ocean.zone_attr_v2`，再用 `aws s3 ls --summarize --recursive` 对比旧表 zone_attr 的大小和行数。如果新表的行数或 geom_wkt 体积明显大于旧表，就支持这个假设。请不要执行 `ANALYZE TABLE ... COMPUTE STATISTICS`，它会改写元数据，属于变更操作。

2. **zone_id 重复（一对多）导致广播表和 join 输出膨胀**
   如果新表里同一个 zone_id 有多行（例如上游脚本合并了多个版本，或者 attrs 被按行展开），广播表本身会变大，每个 AIS 点也会被复制多份，后续 HashAggregate 的输入随之放大。这和"个别 task 爆掉、其余正常"的现象相符，但目前没有直接证据。
   验证动作（只读）：执行 `SELECT zone_id, count(*) AS c FROM ocean.zone_attr_v2 GROUP BY zone_id HAVING count(*) > 1 ORDER BY c DESC LIMIT 20`。再从 ais_points 抽取一个小样本（例如一天中的几千条），在单个会话里做一次 join，比较 join 前后的行数。

3. **执行器内存配置与广播规模不匹配（与假设 1 可能叠加）**
   即使表的大小合理，spark.executor.cores=8 配 16g 内存也意味着每个核只有约 2 GB。按官方默认值 spark.memory.fraction=0.6 估算，(16g − 300MB) × 0.6 约 9.4 GB 由执行与存储共用，而广播表要在同一个 executor 里为 8 个并发任务保存一份。如果表确实有 1.8 GiB，这个预算就很紧。这种情况下 OOM 不一定意味着数据有错，可能只是配置装不下。
   验证动作（只读或小样本）：查看失败的 executor 9 的 stderr 日志，确认第一条 OOM 出现的时间点是否早于心跳超时；在 Spark UI 的 Executors 页查看 executor 9 失败前的峰值内存。另外，可以在单个会话里设置 `spark.sql.autoBroadcastJoinThreshold=-1`，用小样本 ais_points 试跑，只观察计划是否改为 SortMergeJoin。这只改会话级设置，不改集群配置。

## ④ 说明

- 以上都是假设，我没有修改任何集群或配置，也没有下结论。
- 我没有看到 executor 9 的完整日志、新旧表的行数，也不知道 8.2 MiB 估计值的来源，所以排序是基于现有材料的判断，需要用上面的只读动作来验证。
- 如果验证结果支持假设 1，最直接的处理方向通常是让这张表不参与广播，或者核对上游生成的表是否有异常膨胀。具体改法等验证结果出来后再定。
