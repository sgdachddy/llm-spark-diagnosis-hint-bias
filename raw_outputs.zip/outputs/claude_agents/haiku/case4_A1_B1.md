## 结论：这更像是内存不足，不是数据倾斜

附 2 的数据不支持数据倾斜的判断。数据倾斜的典型特征是少数 task 的 shuffle 读取量远大于中位数，但本作业的各项指标都很均匀：

| 指标 | 最大值 / 中位数 |
|---|---|
| Shuffle Read Size | 197 MB / 181 MB，约 1.09 倍 |
| Shuffle Read Records | 221 万 / 203 万，约 1.09 倍 |
| Duration | 4.5 min / 3.4 min，约 1.3 倍 |

所有 task 的 Spill 都在 1.1 到 1.7 GB 之间，上周 Spill 为 0。这种"每个 task 都均匀地溢出"的模式说明每个 task 可用的执行内存不够，与某个 key 特别大无关。

## 根因：executor 内存从 16g 降到 4g

Spark 统一内存的计算方式如下：

- **4g 配置**：`(4096 - 300) × 0.6 ≈ 2.2 GB` 的执行内存，由 4 个并发 task 共享。每个 task 能拿到的份额大约在 280 MB 到 570 MB 之间（按 Spark 的 1/(2N) 到 1/N 规则估算），而单个 task 的排序数据约 1.4 GB，必然反复溢出。
- **16g 配置**：约 9.7 GB 执行内存，每个 task 约 1.2 到 2.4 GB，基本够用，所以上周 Spill 为 0。

其他现象也能对上：

- GC 占比从 3% 升到 19%，是堆内压力大的表现。
- 附 5 中 YARN 报 "4.9 GB of 4.8 GB"：堆 4g 加 overhead 800m 合计 4.8 GB，排序缓冲申请内存失败后仍超限，executor 被杀。
- 数据量只增加 2%，不能解释 3 倍的变慢。

## 关于"省成本"的一点说明

粗算 executor 内存乘以时长：原来 16 × 16g × 20 min ≈ 5120 GB·min，现在 16 × 4g × 58 min ≈ 3712 GB·min。按内存时长计，现在确实省了约 27%，但代价是延迟约 3 倍、出现 executor 被杀后重跑。所以这个改动并不是只有坏处，问题在于 4g 和 4 核的组合对这个作业来说太紧了。

## 建议

1. **先做 A/B 验证**：保持数据和代码不变，只改内存。可试 `spark.executor.memory=12g`、`spark.executor.memoryOverhead=1.5g`、`executor.cores=4`，看 Spill 是否归零、GC 是否回落。这些数值是按上面的公式估算的，需要实测确认。
2. **不要指望 AQE 的 skewJoin 解决这个问题**：附 6 的说明里已写明它只处理 join 中的倾斜分区，而本作业是 Window 和 Sort，不会生效。
3. **若想保留 4g，可尝试加大分区数**，例如 `spark.sql.shuffle.partitions=1200`，让每个 task 的数据量减半。这只是缓解手段，单独使用未必够。
4. **核实倾斜假设**：在 `ais_points` 上执行 `groupBy("mmsi").count().orderBy(desc("count")).show(20)`，确认是否存在个别超大船舶。
5. **排查新目录结构的影响**：附件里只有 Stage 2 的数据。新的按天分区目录可能导致小文件变多、扫描阶段变慢。请补充 Stage 0 和 Stage 1 的 Duration，以区分 Scan 阶段和 Stage 2 的各自贡献。

## 需要你补充的信息

- Stage 0 和 Stage 1 的耗时对比（上周与本周）。
- 新目录下的文件数量和平均文件大小。
- `mmsi` 计数的前 20 名分布（用来排除热点 key）。
