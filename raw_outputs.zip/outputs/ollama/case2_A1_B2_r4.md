<!-- {"file": "case2_A1_B2_r4.md", "prompt": "case2_A1_B2", "rep": 4, "seed": 20261526, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1246, "eval_count": 826, "total_duration_s": 29.9, "done_reason": "stop"} -->

从你提供的信息来看，缓存策略的调整似乎对你的作业产生了影响。下面从多个角度来分析和优化：

### 1. 缓存策略分析
- **缓存级别设置**：你选择了 `MEMORY_AND_DISK`，这意味着数据首先会存储在内存中，当内存不足时，才会溢出到磁盘。由于 `feat` 的大小（10.2GB）超过了单个 executor 的内存（24GB），因此数据确实会溢出到磁盘。
- **缓存效率**：从 Spark UI 可以看到，`feat` 表已经完全被缓存（100% cached），但作业的执行时间却增加了。这可能表明缓存并没有带来预期的性能提升。

### 2. 作业性能瓶颈分析
- **磁盘 I/O 增加**：从附1的集群读数可以看到，磁盘 I/O wait 占用增加了，这表明大量数据在磁盘上进行I/O操作。磁盘 I/O 是 Spark 的性能瓶颈之一，特别是当数据量增加或缓存策略不当时。
- **Spill 记录**：附4的聚合 Stage 总是有一些数据溢出到磁盘，这表明部分数据无法完全存储在内存中，因此需要磁盘作为溢出区。
- **数据倾斜**：从 EXPLAIN FORMATTED 可以看到，数据过滤后的 `feat` 仍然较大，但没有明显的数据倾斜信息。可以考虑对 `feat` 进行更细致的过滤或使用广播变量以减少数据规模。

### 3. 优化建议
1. **减少数据规模**：
   - 重新审视 `feat` 的生成逻辑，看看是否可以进一步过滤或减小数据规模。
   - 考虑是否可以使用广播变量（`spark.sql.adaptive.skewJoin.enabled` 和 `spark.sql.autoBroadcastJoinThreshold`）来优化小表的连接操作。

2. **优化缓存策略**：
   - 从 `feat` 的大小来看，24GB 的内存可能不足以完全存储数据。考虑减少缓存级别，例如使用 `MEMORY_ONLY` 或 `MEMORY_ONLY_SER`，但这可能会牺牲一些性能。
   - 可以调整 `spark.memory.fraction` 和 `spark.memory.storageFraction`，以更好地平衡内存使用。

3. **调整 Spark 配置**：
   - 考虑增加 `spark.sql.shuffle.partitions` 的值，以便更好地管理 shuffle 作业，但这可能需要更多的内存。
   - 确保 `spark.sql.adaptive.enabled` 为 `true`，利用自适应查询执行（AQE）来动态调整执行计划。

4. **监控和调优**：
   - 使用 `Spark UI` 的 `Storage` 和 `Jobs` 页来监控缓存和任务执行情况。
   - 通过 `EXPLAIN FORMATTED` 分析查询计划，确保没有明显的优化点未被利用。

5. **数据预处理**：
   - 如果数据量持续增加，考虑对输入数据进行预处理，例如使用更高效的数据格式（如 ORC）或减少不必要的列。

### 4. 示例代码调整
```python
feat = (spark.read.parquet("s3://<bucket>/ais_points/2026-11/")
        .filter("sog IS NOT NULL AND sog > 0.5"))
feat = feat.coalesce(200)  # 调整分区数量
feat.persist(StorageLevel.MEMORY_ONLY)
feat.count()
speed_dist(feat).write.parquet(out1)
berth_time(feat).write.parquet(out2)
lane_density(feat).write.parquet(out3)
```

通过以上调整，可以更好地平衡内存使用和 I/O 性能，从而提高作业的执行效率。希望这些建议对你有所帮助！
