<!-- {"file": "case3_A2_B1_r5.md", "prompt": "case3_A2_B1", "rep": 5, "seed": 20261634, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1227, "eval_count": 748, "total_duration_s": 27.5, "done_reason": "stop"} -->

### 复述现象和关键读数

**现象：**
- `ais_port_events` 作业今天失败了，昨天正常运行约 12 分钟。
- 失败发生在 join 阶段，多个 executor 先后退出。
- 作业重试了 4 次后终止。

**关键读数：**
- **失败原因：** `Task 37 in stage 4.0 failed 4 times, most recent failure: Lost task 37.3 in stage 4.0 (TID 611) (executor 9): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Executor heartbeat timed out / java.lang.OutOfMemoryError: Java heap space`
- **任务指标：** 
  - Duration: 41s 到 1.2min
  - GC Time: 9s 到 22s
  - Input Size: 118MB 到 131MB
  - Spill (Disk): 0
- **物理计划：** 采用了广播哈希连接。
- **表统计：** `zone_attr_v2` 表的大小约为 8.2MB，未提供具体统计信息。
- **存储目录：** `zone_attr_v2` 表的存储大小约为 1.8GiB。
- **配置：**
  - `spark.executor.instances=12`
  - `spark.executor.cores=8`
  - `spark.executor.memory=16g`
  - `spark.sql.adaptive.enabled=true`
  - `spark.sql.autoBroadcastJoinThreshold=10MB`
  - `spark.sql.shuffle.partitions=200`

### 可能的原因假设（按可能性从高到低排序）

1. **zone_attr_v2 表过大数据集导致内存不足：**
   - zone_attr_v2 表在今天有了显著增长，使得广播数据集过大，超过了每个 executor 的内存限制。
   
2. **广播哈希连接性能问题：**
   - 由于广播哈希连接在处理大表时可能会导致内存不足的问题，尤其是当 `zone_attr_v2` 表变大时，可能导致任务失败。
   
3. **Spark 的自动调整机制没有完全优化：**
   - Spark 的自动调整机制可能没有完全优化，导致资源分配不理想，尤其是在处理较大的数据集时。

### 验证动作

1. **验证 zone_attr_v2 表大小：**
   - **动作：** 查看 `zone_attr_v2` 表的最新统计信息或文件大小。
   - **验证方法：** 使用 `DESCRIBE TABLE EXTENDED ocean.zone_attr_v2` 查看表的统计信息，或使用 `hdfs dfs -du -h` 命令查看文件大小。

2. **验证广播哈希连接的性能：**
   - **动作：** 尝试在较小的数据集上运行相同的作业，以观察是否同样失败。
   - **验证方法：** 使用较小的数据集（例如，随机抽取一部分数据）重新运行作业，观察是否仍然失败。

3. **验证自动调整机制：**
   - **动作：** 查看 Spark UI 中的任务详细信息，检查自动调整机制是否在工作，以及资源分配是否合理。
   - **验证方法：** 查看 Spark UI 中的任务详细信息，检查是否任务分配和内存使用情况符合预期。

以上验证动作仅涉及只读操作，不会修改集群或配置。
