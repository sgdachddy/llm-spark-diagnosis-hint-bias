<!-- {"file": "case2_A1_B0_r3.md", "prompt": "case2_A1_B0", "rep": 3, "seed": 20261424, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1235, "eval_count": 801, "total_duration_s": 29.2, "done_reason": "stop"} -->

根据你提供的信息，作业 `ais_vessel_features` 在本周运行时间变慢，主要问题集中在 `feat` 中间表的缓存上。下面是一些可能的原因和优化建议：

### 1. 中间表 `feat` 的缓存问题
- **现象**: `feat` 中间表的缓存使用了磁盘存储（Disk Memory Deserialized 1x Replicated），导致读取和写入磁盘的时间增加。
- **优化建议**:
  - 尝试增加内存缓存的比例，以减少对磁盘的依赖。可以通过 `spark.sql.cacheEvictionStrategy` 或者调整 `spark.memory.storageFraction` 使得更多的数据能够保留在内存中。
  - 使用 `MemoryOnly` 或 `MemoryOnlyerialized` 缓存级别，但要确保集群有足够的内存来存储数据。

### 2. 垃圾回收（GC）的影响
- **现象**: GC time 占 task 时间的比例为 6%。
- **优化建议**:
  - 确保使用的 Spark 版本的 GC 性能优化较好，如 ZGC 或者 Shenandoah。
  - 可以调整 JVM 参数，例如增加堆大小（`spark.executor.memory`）或优化垃圾回收策略（如调整 `-XX:+UseG1GC` 参数）。

### 3. Shuffle 操作的影响
- **现象**: Shuffle 操作导致了内存溢出到磁盘。
- **优化建议**:
  - 调整 `spark.sql.shuffle.partitions` 的值，以平衡任务的并行度和数据倾斜。
  - 增加磁盘 I/O 处理能力，或者优化数据倾斜的处理策略。

### 4. 数据倾斜
- **现象**: 作业中存在数据倾斜，导致某些任务执行时间过长。
- **优化建议**:
  - 使用 `spark.sql.adaptive.skewJoin.enabled` 策略来处理数据倾斜。
  - 调整输入数据的分区策略，使数据均匀分布。

### 5. 代码优化
- **现象**: 代码中使用了 `persist` 指定缓存级别。
- **优化建议**:
  - 仔细检查是否需要 `feat` 的缓存，是否可以使用其他缓存策略。
  - 评估是否可以优化 `feat` 的读取和处理逻辑，减少数据处理的复杂度。

### 6. 资源配置
- **现象**: 作业的资源配置不变，但数据量增加了 3%。
- **优化建议**:
  - 确认 `spark.sql.shuffle.partitions` 是否需要调整，确保每个 task 的数据量在合理范围内。
  - 增加 executor 的资源（如内存和核心数），以支持更多的并行任务。

### 代码片段优化示例
```python
from pyspark.sql.functions import when, col

# 优化过滤条件，减少不必要的数据处理
feat = (spark.read.parquet("s3://<bucket>/ais_points/2026-11/")
        .filter(when(col("sog").isNotNull() & col("sog") > 0.5, 1).otherwise(0) == 1))
feat.cache()  # 使用 MemoryOnly 缓存级别
feat.count()
speed_dist(feat).write.parquet(out1)
berth_time(feat).write.parquet(out2)
lane_density(feat).write.parquet(out3)
```

### 总结
根据你提供的信息，主要的问题在于 `feat` 中间表的缓存策略和数据倾斜。通过调整缓存策略、优化数据处理逻辑和增加资源，可以有效提升作业的执行效率。希望这些建议对你有所帮助。
