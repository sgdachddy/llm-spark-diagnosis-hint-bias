<!-- {"file": "case3_A2_B2_r2.md", "prompt": "case3_A2_B2", "rep": 2, "seed": 20261335, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1232, "eval_count": 554, "total_duration_s": 20.4, "done_reason": "stop"} -->

### 复述现象和关键读数

**现象**：作业 `ais_port_events` 在今天的运行中失败，昨天则正常。具体在 join 阶段（`HashAggregate` 和 `BroadcastHashJoin` 阶段），多个执行器（executors）退出，作业重试 4 次后终止。

**关键读数**：
1. **错误日志**：多次尝试失败后，Executor 心跳超时并导致 `OutOfMemoryError: Java heap space`。
2. **Spark UI 状态指标**：作业时间、GC 时间、输入大小等在多次尝试中较为稳定，但无磁盘溢出情况。
3. **执行计划**：广播连接（`BroadcastHashJoin`）和哈希连接（`HashAggregate`）被广泛使用。
4. **表信息**：`zone_attr_v2` 表的数据量约为 1.8 GiB，且为新生成的表。
5. **配置**：涉及广播连接的阈值 (`autoBroadcastJoinThreshold`) 设置为 10MB，且使用了自适应查询执行（AQE）。

### 假设和验证动作

**假设 1：广播连接 (`BroadcastHashJoin`) 由于表的增加而导致内存不足**

- **验证动作**：检查 `zone_attr_v2` 表的新旧版本数据量及数据分布是否显著变化。可以通过 `DESCRIBE TABLE EXTENDED` 查看表的创建时间、大小和内容。还可以试运行一个仅包含 `zone_attr_v2` 表的简单查询，检查是否超过 `autoBroadcastJoinThreshold` 值，观察内存使用情况。

**假设 2：自适应查询执行（AQE）调整了计划，导致内存问题**

- **验证动作**：查看 `EXPLAIN FORMATTED` 详细计划，确认自适应查询执行是否改变了连接计划，尤其是 `BroadcastHashJoin` 和 `HashAggregate` 的使用情况。分析计划中是否有明显的变化，如增加更多的哈希连接或广播连接。

**假设 3：分区或数据倾斜导致内存溢出**

- **验证动作**：检查 `EXPLAIN FORMATTED` 中的 `Skew Join` 相关信息，确认是否有倾斜数据导致内存使用不均。可以查看 `EXPLAIN FORMATTED` 是否显示了任何提示或警告，如 `Skew Join` 部分。此外，通过查看作业的日志或执行计划中的统计信息来确认是否存在数据倾斜。

这些验证动作可以帮助你进一步了解问题的原因，并采取适当的措施来优化作业的执行。
