<!-- {"file": "case3_A2_B1_r1.md", "prompt": "case3_A2_B1", "rep": 1, "seed": 20261234, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1227, "eval_count": 615, "total_duration_s": 22.2, "done_reason": "stop"} -->

### 复述现象和关键读数

#### 现象
- 作业 `ais_port_events` 今天失败，昨天运行正常（大约 12 分钟）。
- 失败发生在 join 阶段，多个 executor 先后退出，作业重试 4 次后终止。
- 表现为内存溢出（`Java heap space`），推测可能是内存不足。

#### 关键读数
- 从报错栈中看到，任务 `Task 37` 失败是因为 `ExecutorLostFailure` 和 `OutOfMemoryError: Java heap space`。
- Spark UI 中，任务的执行时间、GC 时间、输入大小和溢出（溢出到磁盘）等关键指标均未显示出异常。
- 作业的详细执行计划显示了广播连接（BroadcastJoin）。
- `zone_attr_v2` 表的大小为 1.8 GiB，广播阈值设为 10MB，意味着该表会被广播到所有 executor。

### 可能的原因假设（按可能性从高到低排序）

1. **广播连接表太大，导致内存溢出**
   - 由于 `zone_attr_v2` 表较大，即使广播阈值为 10MB，它仍可能会被广播到所有 executor，导致内存不足。
   
2. **shuffle 分区过多，导致内存不足**
   - 作业的 shuffle 阶段（Exchange 和 HashAggregate）可能产生了过多的分区，导致每个 executor 的内存不足。

3. **数据倾斜或不均衡，导致内存不足**
   - 尽管未直接显示数据倾斜，但如果某些分区的数据量特别大，可能会导致内存不足。

### 验证动作

1. **验证广播连接表是否过大**
   - **验证动作**：查看 `zone_attr_v2` 表在广播到 executor 时的实际数据量，对比广播阈值。
   - **操作**：使用 SQL 查询或 Spark Shell 检查广播表的实际大小，并与阈值 10MB 比较。

2. **验证 shuffle 分区是否过多**
   - **验证动作**：检查作业的 shuffle 阶段是否有过多的分区。
   - **操作**：查看作业的详细执行计划（`EXPLAIN FORMATTED`），确保 shuffle 阶段的分区数合理，未超过某个合理的阈值（通常建议每个 executor 分配 2-3 个分区）。

3. **验证数据倾斜情况**
   - **验证动作**：检查是否有数据倾斜，导致某些 executor 负担过重。
   - **操作**：查看日志或使用 Spark 的数据倾斜检测工具（如 `org.apache.spark.sql.execution.shuffle.sort.ShuffleSortExec` 的日志输出）。

通过这些验证动作，可以逐步排查问题所在，而无需直接修改集群或配置。
