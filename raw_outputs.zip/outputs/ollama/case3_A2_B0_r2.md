<!-- {"file": "case3_A2_B0_r2.md", "prompt": "case3_A2_B0", "rep": 2, "seed": 20261333, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1222, "eval_count": 541, "total_duration_s": 19.8, "done_reason": "stop"} -->

### 复述现象和关键读数

**现象**：作业 `ais_port_events` 今天在 `join` 阶段失败了，失败发生在多个 `executor` 先后退出。作业总共重试了 4 次后终止。作业内容是将 AIS 船位点与港区属性表 `zone_attr_v2` 按 `zone_id` 做 `join`，再统计进出港事件。

**关键读数**：
- **报错栈**：失败任务 `task 37` 在 `executor 9` 上因 `Java heap space` 而退出。
- **Stage 4 总结**：61 个任务中，最大执行时间为 1.2 分钟，GC 时间为 22 秒。
- **EXPLAIN FORMATTED**：作业计划中显示 `BroadcastHashJoin Inner BuildRight`。
- **EXPLAIN COST**：`zone_attr_v2` 表的大小为 8.2 MiB。
- **描述表**：`zone_attr_v2` 表的大小为 1.8 GiB。

### 可能的原因假设（按可能性从高到低排序）

1. **内存不足导致的溢出**
2. **广播表的数据量超过预期，导致 `executor` 内存不足**
3. **倾斜数据导致 `join` 失败**

### 验证动作

1. **验证内存使用情况和广播表大小**：
   - **验证动作**：在 `Spark UI` 中查看 `Stage 4` 的内存使用情况，确认 `executor` 的内存使用是否接近或超过配置的 16 GB。可以通过 `spark.ui.view.stages` 查看详细的内存使用情况。
   - **验证动作**：检查广播表 `zone_attr_v2` 的实际大小是否超过 `autoBroadcastJoinThreshold`（默认 10MB）。

2. **检查倾斜数据的情况**：
   - **验证动作**：在 `Spark UI` 中查看 `Stage 4` 的详细计划，确认是否有倾斜数据的情况。可以通过 `spark.ui.view.stages` 查看详细计划。

3. **验证广播表的大小**：
   - **验证动作**：运行一个小样本的测试作业，检查 `zone_attr_v2` 表的实际大小和广播行为是否符合预期。可以通过运行一个简单的 `join` 作业来测试。

以上验证动作可以帮助进一步确认问题所在，但不会改变当前集群的配置或直接修改作业的运行环境。
