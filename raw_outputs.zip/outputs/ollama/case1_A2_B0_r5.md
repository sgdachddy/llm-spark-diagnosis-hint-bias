<!-- {"file": "case1_A2_B0_r5.md", "prompt": "case1_A2_B0", "rep": 5, "seed": 20261621, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1703, "eval_count": 520, "total_duration_s": 19.1, "done_reason": "stop"} -->

### 复述现象和关键读数

**现象**：夜间作业 `ais_daily_zone_stats` 变慢，特别是 `Stage 3` 用时明显增加。以前约15分钟完成，现在今天用时45分钟，昨天用时5分钟。作业内容是将AIS船位点（按h3_r7格子编码）与海区属性表 `zone_attr` 进行join操作，并按日统计。

**关键读数**：
- CPU整体利用率：12%
- 网络吞吐：正常，无丢包
- GC时间占任务时间：3%
- Duration：最小6秒，最大45分钟
- Shuffle Read Size：最大8.4GB
- Shuffle Read Records：最大1.2亿
- Spill (Memory)：最大96GB
- Spill (Disk)：最大38GB

### 原因假设

1. **外部数据集倾斜（skew in input data）**：数据倾斜可能会导致某些任务处理大量数据，而其他任务处理的数据量很少，从而导致整体任务的执行时间延长。
2. **外部shuffle数据量大**：数据量大可能意味着数据在执行过程中需要进行大量的shuffle操作，这可能导致数据溢出到磁盘，从而增加处理时间。
3. **Spark任务执行的不均衡**：任务分配和执行过程中可能存在不均衡情况，导致某些executor执行时间过长。

### 验证动作

1. **检查数据倾斜（验证是否是数据倾斜导致的问题）**：
   - **验证动作**：在Spark UI中查看具体的Task Duration和Shuffle Read Records等指标，重点关注是否有某些Task的处理记录明显超过其他Task。

2. **检查shuffle操作的数据量（验证是否是shuffle数据量大导致的问题）**：
   - **验证动作**：分析`EXPLAIN FORMATTED`的输出，检查Join操作的Shuffle Read Size和Shuffle Read Records，对比与之前是否有显著差异。

3. **检查任务执行的均衡性（验证是否是任务执行不均衡导致的问题）**：
   - **验证动作**：查看`Spark UI · Stage 3 · Aggregated Metrics by Executor`，检查各个Executor的任务执行时间、shuffle读取量和溢出情况，对比是否有较大差异。

以上三个验证动作均不会改变当前集群或配置，只是通过观察和分析现有数据来进一步缩小问题范围。
