<!-- {"file": "case3_A2_B0_r4.md", "prompt": "case3_A2_B0", "rep": 4, "seed": 20261533, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1222, "eval_count": 624, "total_duration_s": 22.6, "done_reason": "stop"} -->

### 现象与关键读数复述
**现象**：作业 `ais_port_events` 在使用 `zone_attr_v2` 表进行 `JOIN` 操作时失败，多个执行器退出，尝试了 4 次重试后作业终止。

**关键读数**：
1. 失败时，`Task 37` 在 `stage 4.0` 上失败了 4 次。
2. 最后一次失败的原因是 `ExecutorLostFailure`，具体原因是 `Executor heartbeat timed out` 以及 `Java heap space` 错误。
3. `Stage 4` 的任务时间分布显示了任务执行时间从 41 秒到 1 分 20 秒不等，存在一定的变异性。
4. `GC Time` 显示了 GC 消耗的时间，从 9 秒到 22 秒不等。
5. `Input Size` 每个任务的输入数据大小在 118 MB 到 131 MB 之间。
6. 作业使用的执行器配置是 12 个，每个执行器 8 核 16 GB 内存。
7. `zone_attr_v2` 表的数据大小约为 1.8 GB。
8. 作业使用了 Adaptive Query Execution (AQE) 和广播连接优化，但没有统计信息。

### 假设与验证动作
1. **假设 1**：作业中 `zone_attr_v2` 表的大小超过了广播连接的阈值，导致数据无法被有效广播，从而引发内存溢出。
   - **验证动作**：检查 `autoBroadcastJoinThreshold` 的配置值，并确认是否应该调整这个值。可以尝试减小 `autoBroadcastJoinThreshold` 以查看是否能改善性能。

2. **假设 2**：作业中的数据分布不均匀，导致某些任务加载了过多的数据，从而引发了内存溢出。
   - **验证动作**：检查 `zone_attr_v2` 表的数据分布情况，使用 `DESCRIBE TABLE EXTENDED` 看看是否有明显的倾斜，并且在 `EXPLAIN FORMATTED` 中查看是否有 `skew join` 警告。可以尝试调整 `shuffle partitions` 数量以改善数据分布。

3. **假设 3**：作业的 GC 压力过高，导致执行器的心跳超时。
   - **验证动作**：检查 `GC Time` 的分布情况，确认是否频繁发生 GC 操作。可以尝试增加 `executor.memory` 和 `spark.memory.fraction` 配置，以提供更多的内存给执行器。

### 注意事项
- 以上验证动作均为只读操作，无需修改集群或配置。
- 由于 `zone_attr_v2` 是最近生成的新表，建议在小样本数据上进行验证动作，以避免对生产环境造成不必要的影响。
