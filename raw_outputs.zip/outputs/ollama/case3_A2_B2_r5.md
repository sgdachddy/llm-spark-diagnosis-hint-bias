<!-- {"file": "case3_A2_B2_r5.md", "prompt": "case3_A2_B2", "rep": 5, "seed": 20261635, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1232, "eval_count": 591, "total_duration_s": 21.8, "done_reason": "stop"} -->

### 复述现象和关键读数

**现象：**
- 作业 `ais_port_events` 今天失败了，昨天正常运行。
- 失败发生在 `join` 阶段，多个 `executor` 先后退出，作业重试 4 次后终止。
- 作业内容是 AIS 船位点与港区属性表 `zone_attr_v2` 按 `zone_id` 做 `join`，再统计进出港事件。

**关键读数：**
- 失败发生在 `Task 37`，多次失败导致 `Executor` 退出。
- 最终的错误是 `Executor` 心跳超时或 `Java heap space` 越界。
- 作业 `Duration` 大约 41-120 秒，`GC Time` 大约 9-22 秒，`Input Size` 大约 118-131 MB，没有 `Spill` 发生。
- 作业计划显示 `BroadcastHashJoin` 被使用，因为 `zone_attr_v2` 被广播。
- `zone_attr_v2` 表的 `parquet` 存储大约 1.8 GiB。
- 作业配置中 `spark.sql.adaptive.enabled` 和 `spark.sql.autoBroadcastJoinThreshold` 均启用，`spark.executor.memory` 为 16 GB。

### 可能的原因假设（按可能性排序）

1. **`zone_attr_v2` 表的大小增加导致广播失败**
2. **Spark SQL 的 Adaptive Query Execution（AQE）未按预期工作，导致数据分区不合理**
3. **`executor` 内存不足导致 `Heap` 越界**

### 验证动作

1. **验证 `zone_attr_v2` 表的大小变化**
   - **动作：** 检查 `zone_attr_v2` 表的最新 `Created Time` 和存储大小，以及之前的版本大小。可以通过 `DESCRIBE TABLE EXTENDED` 获取信息，并与历史版本对比。

2. **检查 Adaptive Query Execution 的行为**
   - **动作：** 通过 `EXPLAIN FORMATTED` 查看具体的执行计划，确认 `AQE` 是否按预期拆分了数据。检查是否有 `skewJoin` 信息，确认是否正确处理了数据倾斜。

3. **验证 `executor` 内存使用情况**
   - **动作：** 查看 Spark UI 的 `Stage 4` 的 `Task` 详细信息，确认是否有内存溢出的详细记录。检查是否有其他任务在 `executor` 中使用大量内存的情况。

以上步骤将帮助进一步确认问题的原因，而不会对现有的集群或配置进行更改。
