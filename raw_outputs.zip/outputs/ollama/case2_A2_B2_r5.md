<!-- {"file": "case2_A2_B2_r5.md", "prompt": "case2_A2_B2", "rep": 5, "seed": 20261629, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1339, "eval_count": 1096, "total_duration_s": 40.2, "done_reason": "stop"} -->

好的，让我们先来复述一下现象和关键读数，然后分析可能的原因并提出验证方法。

### 复述现象和关键读数

**现象：**
- 作业 `ais_vessel_features` 的运行时间从上周的约 18 分钟增加到本周的约 31 分钟。
- 本周新增了对中间表 `feat` 的缓存操作 `feat.persist(StorageLevel.MEMORY_AND_DISK)`。

**关键读数：**
- 集群整体读数：
  - CPU 整体利用率：34%
  - 磁盘 IO wait：28%（上周约 5%）
  - GC time 占 task 时间：6%
- Spark UI · Storage 页：
  - `feat` 的缓存策略为 `Disk Memory Deserialized 1x Replicated`，缓存了 320 个分区，内存使用 10.2 GB，磁盘使用 29.8 GB。
- Spark UI · Jobs 概览：
  - `feat.count()` 用时显著增加至 9.5 分钟。
  - 其他任务用时变化不大，但 `feat.count()` 占用了大量时间。
- Spark UI · Job 2 聚合 Stage 的 Summary Metrics：
  - `Duration` 范围较上周增大，最大值为 1.9 分钟。
  - Shuffle Read Size 显著增加，最大值为 121 MB。
  - Spill（溢出）显著增加，内存和磁盘溢出分别从 0 到 1.4 GB 和 0 到 0.5 GB。

### 可能的原因假设

1. **缓存数据在内存中未充分利用**
   - `feat` 的缓存策略为 `Disk Memory Deserialized 1x Replicated`，意味着缓存主要存储在磁盘上，而没有充分利用内存。这可能导致每次访问 `feat` 时需要从磁盘读取数据，增加了 I/O 开销。

2. **缓存策略不当导致内存溢出**
   - `feat` 的缓存使用了 10.2 GB 的内存，这在 80 核 24 GB/核的集群中并不算大。但是，由于 Spark 的内存管理机制，可能是因为频繁的数据读取和写入导致内存碎片增加，从而增加了溢出的几率。

3. **数据倾斜或 Shuffle 操作导致性能下降**
   - 虽然 `feat` 的数据量增加了 3%，但 `feat.count()` 的执行时间显著增加，表明可能存在数据倾斜或 Shuffle 操作导致了性能下降。

### 验证动作

1. **验证缓存策略：检查缓存是否充分利用内存**
   - **验证动作**：在 `feat` 的缓存配置上添加 `StorageLevel.MEMORY_ONLY` 或 `MEMORY_ONLY_SER`，查看是否能减少 I/O 操作，提高执行速度。
   - **操作代码**：
     ```python
     feat = (spark.read.parquet("s3://<bucket>/ais_points/2026-11/")
             .filter("sog IS NOT NULL AND sog > 0.5"))
     feat = feat.persist(StorageLevel.MEMORY_ONLY)  # 尝试使用内存缓存
     feat.count()
     speed_dist(feat).write.parquet(out1)
     berth_time(feat).write.parquet(out2)
     lane_density(feat).write.parquet(out3)
     ```

2. **验证 Shuffle 操作是否高效**
   - **验证动作**：检查 Shuffle 操作的溢出情况，确认是否存在数据倾斜。
   - **操作代码**：
     ```python
     feat = (spark.read.parquet("s3://<bucket>/ais_points/2026-11/")
             .filter("sog IS NOT NULL AND sog > 0.5"))
     feat.persist(StorageLevel.MEMORY_AND_DISK)
     feat.count()  # 保持原样，不修改
     speed_dist(feat).write.parquet(out1)
     berth_time(feat).write.parquet(out2)
     lane_density(feat).write.parquet(out3)
     ```

3. **验证数据倾斜**
   - **验证动作**：在 `feat` 的过滤条件中添加更多的过滤条件或数据预处理步骤，以减少数据倾斜的可能性。
   - **操作代码**：
     ```python
     feat = (spark.read.parquet("s3://<bucket>/ais_points/2026-11/")
             .filter("sog IS NOT NULL AND sog > 0.5 AND mmsi > 1000000000"))
     feat.persist(StorageLevel.MEMORY_AND_DISK)
     feat.count()
     speed_dist(feat).write.parquet(out1)
     berth_time(feat).write.parquet(out2)
     lane_density(feat).write.parquet(out3)
     ```

通过以上验证动作，可以逐步排查问题所在，并确认是否需要调整缓存策略或数据处理逻辑。
