<!-- {"file": "case3_A2_B2_r3.md", "prompt": "case3_A2_B2", "rep": 3, "seed": 20261435, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1232, "eval_count": 603, "total_duration_s": 22.2, "done_reason": "stop"} -->

### 现象与关键读数复述

#### 现象
- 作业 `ais_port_events` 在今天运行时失败，昨天运行正常（约 12 分钟）。失败原因是在 `join` 阶段，多个执行器先后退出，作业重试 4 次后终止。
- 失败信息显示多个任务（例如 `Task 37`）因 `Lost task` 和 `ExecutorHeartbeat timed out` / `Java heap space` 错误退出。

#### 关键读数
- **报错栈**：多次提到 `ExecutorHeartbeat timed out` 和 `java.lang.OutOfMemoryError: Java heap space`，表明内存不足。
- **Spark UI - Stage 4 - Summary Metrics**：显示任务执行时间（41s - 1.2 min），垃圾回收时间（9s - 22s），输入大小（118MB - 131MB），无溢出到磁盘。
- **物理计划**：展示了广播连接操作。
- **统计信息**：作业代码未变，但新生成的 `zone_attr_v2` 表的大小增加到 1.8 GiB。
- **作业配置**：使用了 12 个 8 核 16GB 内存的执行器，启用了自适应查询执行（AQE）。

### 可能的原因假设
1. **广播表 `zone_attr_v2` 太大，导致内存溢出**。
2. **自适应查询执行（AQE）没有正确处理广播表**。
3. **输入数据大小增加，导致内存不足**。

### 验证动作
1. **假设1：广播表 `zone_attr_v2` 太大，导致内存溢出**。
    - **验证动作**：检查 `zone_attr_v2` 表的统计信息和大小，确认是否超过 `autoBroadcastJoinThreshold` 设置。可以通过调整 `spark.sql.autoBroadcastJoinThreshold` 配置为一个更小的值（例如 1MB），并重新运行作业观察是否仍然失败。

2. **假设2：自适应查询执行（AQE）没有正确处理广播表**。
    - **验证动作**：在 Spark UI 中查看 AQE 的详细计划，检查是否有异常的执行计划。可以尝试禁用 AQE（设置 `spark.sql.adaptive.enabled=false`），重新运行作业，观察是否仍然失败。

3. **假设3：输入数据大小增加，导致内存不足**。
    - **验证动作**：查看输入数据的统计信息，确认是否有大量数据。如果数据量增加明显，可以考虑增加执行器的内存或调整 `spark.sql.shuffle.partitions`。

这些验证动作可以帮助更准确地定位问题所在，而无需直接修改集群或配置。
