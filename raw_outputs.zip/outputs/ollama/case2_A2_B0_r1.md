<!-- {"file": "case2_A2_B0_r1.md", "prompt": "case2_A2_B0", "rep": 1, "seed": 20261227, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1328, "eval_count": 642, "total_duration_s": 24.4, "done_reason": "stop"} -->

### 复述现象和关键读数

**现象：**
- 作业 `ais_vessel_features` 的运行时间从之前的约18分钟增加到约31分钟。
- 虽然没有报错，但是输入数据量有所增加（+3%），这可能对性能有一定影响。
- 中间表 `feat` 增加了持久化操作 `persist(StorageLevel.MEMORY_AND_DISK)`。

**关键读数：**
- 集群整体读数：
  - CPU 整体利用率：34%
  - 磁盘 IO wait：28%（上周约5%）
  - GC time 占 task 时间：6%
- Spark UI · Storage 页：
  - `feat` 的存储方式为 `Disk Memory Deserialized 1x Replicated`，缓存了320个分区，大小在内存和磁盘上分别约为10.2GB和29.8GB。
- Spark UI · Jobs 概览：
  - `feat.count()` 用时显著增加至9.5分钟。
- Spark UI · Job 2 中聚合 Stage 的 Summary Metrics：
  - Shuffle读取大小在104MB到121MB之间，内存溢出在0.6GB到1.4GB之间，磁盘溢出在0.2GB到0.5GB之间。
- EXPLAIN FORMATTED 中可以看到作业的物理计划。
- 代码片段展示了数据处理流程。
- 本次作业生效的配置详细。

### 可能的原因假设

1. **缓存（持久化）策略影响了数据读取性能。**
2. **磁盘 I/O 增加导致整体性能下降。**
3. **Shuffle操作增加了额外的开销。**

### 验证动作

1. **缓存（持久化）策略影响了数据读取性能：**
   - **验证动作：** 检查 `feat` 的缓存策略是否合理，尝试调整缓存级别（例如，尝试 `MEMORY_ONLY` 而不是 `MEMORY_AND_DISK`），并在作业中观察是否有所改善。使用 `spark.sql.adaptive.enabled` 是否开启，若开启，可适当调整 `spark.sql.adaptive.shuffle.enabled`。

2. **磁盘 I/O 增加导致整体性能下降：**
   - **验证动作：** 查看是否有其他 I/O 高的作业或活动，以确定是否确实是因为 I/O 竞争导致性能下降。使用 `top` 或 `iotop` 工具监控系统资源使用情况，确认 I/O 是否是瓶颈。

3. **Shuffle操作增加了额外的开销：**
   - **验证动作：** 通过 `EXPLAIN FORMATTED` 分析作业计划，查看是否有不必要的 Shuffle 操作。尝试减少 `spark.sql.shuffle.partitions` 的值，看看是否可以减少 Shuffle 操作的数量并提高性能。

这些验证动作可以帮助你逐步排查问题所在，并针对性地进行优化。
