<!-- {"file": "case3_A2_B2_r4.md", "prompt": "case3_A2_B2", "rep": 4, "seed": 20261535, "model": "qwen2.5:7b", "num_ctx": 16384, "prompt_eval_count": 1232, "eval_count": 610, "total_duration_s": 22.2, "done_reason": "stop"} -->

### 人话复述现象和关键读数

**现象：**
- 作业 `ais_port_events` 在今天失败了，昨天却运行正常，持续约12分钟。
- 失败发生在 `join` 阶段，多个 executor 先后退出，作业重试4次后终止。
- 作业内容是将 `ais_points` 表与 `zone_attr_v2` 表按 `zone_id` 做 `join`，再进行统计。

**关键读数：**
- 失败任务信息：`Lost task 37.3 in stage 4.0 (TID 611) (executor 9)：ExecutorLostFailure`，提示 `Executor heartbeat timed out` 或 `java.lang.OutOfMemoryError: Java heap space`。
- `Spark UI` 中 `Stage 4` 总共完成61个任务，没有明显的错误提示。
- `EXPLAIN FORMATTED` 显示了 `BroadcastHashJoin`，说明 `zone_attr_v2` 表被广播。
- `EXPLAIN COST` 显示 `zone_attr_v2` 表的统计信息，大小为 8.2 MiB。
- `zone_attr_v2` 表大小为 1.8 GiB。
- `作业生效的配置` 中，`spark.sql.autoBroadcastJoinThreshold` 设置为 10MB，表明 `zone_attr_v2` 应该被广播。

### 假设及验证动作

**假设 1：`zone_attr_v2` 表过大，实际广播超过 `autoBroadcastJoinThreshold`**
- **验证动作：** 查看 `EXPLAIN FORMATTED` 中的 `BroadcastExchange` 任务详情，确认 `zone_attr_v2` 是否确实被广播。如果任务中 `zone_attr_v2` 的广播操作频繁失败或超时，可以进一步检查是否广播超过阈值。

**假设 2：`zone_attr_v2` 表数据分布不均，导致倾斜的分区**
- **验证动作：** 检查 `zone_attr_v2` 表的分区情况，确认是否存在数据倾斜。可以在 `Spark UI` 中查看 `zone_attr_v2` 的 `Shuffle Read` 任务详情，确认是否存在某些分区过大导致的倾斜。

**假设 3：`join` 操作内存消耗过高**
- **验证动作：** 查看 `Spark UI` 中 `Stage 4` 的 `Storage Memory` 和 `Execution Memory` 使用情况，确认是否超出配置的内存限制。如果发现执行内存使用过高，可以进一步检查是否需要调整 `spark.memory.fraction` 或 `spark.sql.adaptive.shuffle.memoryEstimation`.

### 结论
以上假设均未直接修改集群或配置，只需通过只读操作验证可能的问题所在。通过这些验证动作，可以进一步确定问题的具体原因。
