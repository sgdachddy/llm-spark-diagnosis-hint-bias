<!-- {"file": "case2_BLIND_B2_R2_r3", "case": 2, "rep": 3, "round": 2, "hint": "B2", "seed": 20261421, "prompt_eval_count": 1961, "eval_count": 797, "done_reason": "stop"} -->

### 分析与判断

根据你提供的材料和我的诊断，我们来具体分析一下你猜测的“缓存（persist）用得不对”是否为首要原因。

### 人话复述现象和关键读数

**现象：**
- 作业 `ais_vessel_features` 运行时间从以前的约 18 分钟增加到了本周的约 31 分钟。
- 没有报错，但是性能显著下降。

**关键读数：**
- 集群 CPU 利用率 34%，磁盘 IO wait 达到 28%（上周约 5%）。
- 中间表 `feat` 的存储级别是 `MEMORY_AND_DISK`，且缓存了 100%。
- 作业 0 (`feat.count()`) 用时增加了。
- 作业 2 (`航速分布`) 的聚合阶段 Spill 达到 0.6GB - 1.4GB，比上周显著增加。
- Spark UI 指示 Shuffle 数据量有所增加，任务执行时间延长。

### 分析与判断

1. **磁盘 I/O 等待增加的原因：**
   - 磁盘 IO wait 从上周的 5% 增加到了本周的 28%，这表明磁盘 I/O 成为了瓶颈。虽然 I/O 增加，但它不是直接由缓存（persist）引起的。

2. **中间表 `feat` 的 Spill 事件增多：**
   - `feat` 表的 Spill 从 0 增加到了 0.6GB - 1.4GB，表明内存不足，导致数据溢出到磁盘。这确实与缓存策略有关，因为缓存可能会导致内存使用增加，进而增加 Spill 事件。
   
3. **Spark 配置或数据量变化导致任务执行时间增加：**
   - 输入数据量比上周增加了 3%，这可能会导致部分任务执行时间变长。但通常，增加的数据量不会导致内存溢出到磁盘的程度。

### 最终结论

**最可能的首要原因：**
- **中间表 `feat` 的缓存策略导致内存溢出到磁盘。** 
  - `feat` 的缓存策略 `MEMORY_AND_DISK` 是一种默认策略，当内存不足时，数据会溢出到磁盘。由于本周数据量增加，内存压力增大，导致 Spill 事件增多。

### 验证动作

1. **验证中间表 `feat` 的 Spill 事件：**
   - **验证动作：** 查看其他任务是否有类似的 Spill 事件，确认 `feat` 的缓存策略是否导致内存不足。可以查看 Spark UI 中其他任务的 Spill 信息。

2. **调整缓存策略：**
   - **验证动作：** 考虑调整 `feat` 的缓存策略，例如尝试使用 `MEMORY_ONLY`，看是否能减少 Spill 事件。可以在代码中调整缓存策略，例如：
     ```python
     feat = (spark.read.parquet("s3://<bucket>/ais_points/2026-11/")
             .filter("sog IS NOT NULL AND sog > 0.5"))
     feat.cache()  # 使用 MEMORY_ONLY
     feat.count()
     speed_dist(feat).write.parquet(out1)
     berth_time(feat).write.parquet(out2)
     lane_density(feat).write.parquet(out3)
     ```

### 结论

最可能的首要原因是 **中间表 `feat` 的缓存策略导致内存溢出到磁盘**。通过调整缓存策略，可以减少内存压力，从而优化性能。
