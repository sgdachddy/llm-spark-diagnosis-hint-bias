<!-- {"file": "case3_BLIND_R1_r1", "case": 3, "rep": 1, "round": 1, "seed": 20261222, "prompt_eval_count": 1222, "eval_count": 672, "done_reason": "stop"} -->

### 复述现象和关键读数

**现象：**
- 作业 `ais_port_events` 今天失败，昨天运行正常。
- 失败发生在 join 阶段，多个 executor 先后退出，作业重试 4 次后终止。

**关键读数：**
- 任务 `37` 在 `stage 4.0` 中失败了 4 次，最近的失败原因是 `ExecutorLostFailure`，具体原因是 `Executor heartbeat timed out` 或 `Java heap space`。
- `Spark UI` 中 `Stage 4` 的 `Task Duration` 平均在 52 秒左右，内存使用为 `126 MB`，没有出现磁盘溢出。
- `EXPLAIN FORMATTED` 显示了作业的执行计划，包括广播连接和哈希连接。
- `EXPLAIN COST` 估计 `zone_attr_v2` 表的大小为 8.2 MiB。
- `zone_attr_v2` 表的数据量为 1.8 GiB，存储在 S3 中。
- 本次作业生效的配置包括 `spark.sql.adaptive.enabled=true` 和 `spark.sql.autoBroadcastJoinThreshold=10MB`。

### 假设与验证

**假设按可能性从高到低排序：**

1. **广播表 `zone_attr_v2` 未能成功广播，导致任务失败。**
2. **哈希连接溢出，导致 Executor 超时或内存溢出。**
3. **表 `zone_attr_v2` 的数据量增加，导致连接操作耗时和资源需求增加。**

**验证动作：**

1. **广播表 `zone_attr_v2` 未能成功广播，导致任务失败：**
   - **验证动作**：查看 `zone_attr_v2` 表的广播状态。在 `Spark UI` 中查看广播的 `zone_attr_v2` 任务的状态，确认是否成功广播以及广播后的大小。可以使用 `spark.sql("SELECT COUNT(*) FROM zone_attr_v2")` 进行小样本试跑，确认表的大小是否超出 `autoBroadcastJoinThreshold` 的限制。
   
2. **哈希连接溢出，导致 Executor 超时或内存溢出：**
   - **验证动作**：检查作业的执行计划，确认是否发生了哈希连接。查看 `EXPLAIN FORMATTED` 和 `EXPLAIN COST`，确认连接操作的资源需求。可以调整 `spark.sql.adaptive.shuffle.partitions` 参数，减少哈希分区数，查看是否能减少内存压力。
   
3. **表 `zone_attr_v2` 的数据量增加，导致连接操作耗时和资源需求增加：**
   - **验证动作**：确认 `zone_attr_v2` 表的数据量是否有显著增加。如果数据量确实增加了，可以尝试调整 `spark.sql.shuffle.partitions` 参数，增加分片数，以分散资源需求。可以进行小样本试跑，确认增加分片数是否能有效降低每个任务的资源消耗。

通过这些验证动作，可以逐步排除可能的原因，并找到最有可能导致问题的根源。
