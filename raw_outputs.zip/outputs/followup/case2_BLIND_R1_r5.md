<!-- {"file": "case2_BLIND_R1_r5", "case": 2, "rep": 5, "round": 1, "seed": 20261621, "prompt_eval_count": 1328, "eval_count": 570, "done_reason": "stop"} -->

### 复述现象和关键读数

**现象**：作业 `ais_vessel_features` 本周变得较慢，从之前的约 18 分钟变为约 31 分钟，没有报错。代码中给中间表 `feat` 加了 `persist` 操作，并且输入数据量比上周增加了 3%。

**关键读数**：
1. **集群整体读数**：
   - CPU 整体利用率：34%
   - 磁盘 IO wait：28%（上周约 5%）
   - GC time 占 task 时间：6%

2. **Spark UI · Storage 页**：
   - `feat` 的存储级别为 `Disk Memory Deserialized 1x Replicated`，缓存了 320 个分区，大小为 10.2 GB 在内存中，29.8 GB 在磁盘上。

3. **Spark UI · Jobs 概览**：
   - 物化缓存 `feat.count()` 用时增加了。
   - 其他阶段的用时有小幅增加。

4. **Spark UI · Job 2 中聚合 Stage 的 Summary Metrics**：
   - 任务运行时间范围：58 秒至 1.9 分钟。
   - Shuffle 读取大小：92 MB 至 121 MB。
   - Spill：内存溢出量从 0.6 GB 到 1.4 GB，磁盘溢出量从 0.2 GB 到 0.5 GB。

### 可能的原因假设及验证动作

1. **假设 1**：缓存数据的读取和写入操作消耗了较多资源。
   - **验证动作**：查看 `feat` 中间表的缓存状态，检查其大小是否与预期相符；尝试减少 `feat` 中间表的缓存大小，观察性能变化。

2. **假设 2**：磁盘 I/O 增加导致整体作业变慢。
   - **验证动作**：检查磁盘 I/O 等待时间的具体原因，尝试减少磁盘 I/O 使用的量，例如调整 `spark.sql.shuffle.partitions` 的值。

3. **假设 3**：Shuffle 操作溢出至磁盘导致性能降低。
   - **验证动作**：分析 Shuffle 操作的溢出情况，检查是否有过多的数据溢出到磁盘；尝试增加内存以减少 Shuffle 溢出。

### 不要修改集群或配置

在验证这些假设时，建议保持集群和配置不变，仅通过查看现有数据和运行小样本试跑来验证假设。
